# GridNetz Backend - Vollstaendige API/Route-Map

> Stand: 2026-03-11 | 96 Route-Dateien | Backend-Port: 3002
> Basis: `/var/www/gridnetz-backend/src/routes/`

---

## Inhaltsverzeichnis

1. [Auth & Session](#1-auth--session)
2. [User-Management](#2-user-management)
3. [Kunden](#3-kunden)
4. [Installations (Netzanmeldungen)](#4-installations-netzanmeldungen)
5. [Anlagen](#5-anlagen)
6. [Dokumente](#6-dokumente)
7. [Email-System](#7-email-system)
8. [NB-Kommunikation & Response](#8-nb-kommunikation--response)
9. [Rechnungen & Finanzen](#9-rechnungen--finanzen)
10. [Dashboard & Analytics](#10-dashboard--analytics)
11. [Factro Integration](#11-factro-integration)
12. [KI/AI-Services](#12-kiai-services)
13. [Produkte & Technik](#13-produkte--technik)
14. [Projekte](#14-projekte)
15. [Netzbetreiber & VNB](#15-netzbetreiber--vnb)
16. [Workflow & Ops](#16-workflow--ops)
17. [Handelsvertreter & Provisionen](#17-handelsvertreter--provisionen)
18. [Portal (Endkunden)](#18-portal-endkunden)
19. [Kalender & Termine](#19-kalender--termine)
20. [WhatsApp](#20-whatsapp)
21. [Admin & System](#21-admin--system)
22. [Sonstiges](#22-sonstiges)

---

## Legende

| Symbol | Bedeutung |
|--------|-----------|
| `[AUTH]` | `authenticate` Middleware |
| `[ADMIN]` | `requireAdmin` |
| `[STAFF]` | `requireStaff` (ADMIN + MITARBEITER) |
| `[MA]` | `requireMitarbeiter` (ADMIN + MITARBEITER) |
| `[HV]` | `requireHandelsvertreter` |
| `[AI-LIMIT]` | `aiLimiter` Rate-Limiter |
| `[PUBLIC]` | Kein Auth erforderlich |
| `[SESSION]` | `authenticateSession` (Cookie-basiert) |

---

## 1. Auth & Session

### auth.routes.ts
**Base-Path:** `/api/auth`, `/api/login`, `/api`
**Middleware:** Per-Route

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | `/login` | [PUBLIC] | Login (Email/Password + optionale 2FA) |
| POST | `/` | [PUBLIC] | Login-Alias |
| GET | `/me` | [AUTH] | Aktueller User mit WhiteLabel-Config |
| PATCH | `/me` | [AUTH] | Eigenes Profil (Name) aendern |
| PATCH | `/me/kunde` | [AUTH] | Eigene Kundendaten aendern |
| POST | `/refresh` | [PUBLIC] | Access-Token erneuern via Refresh-Token |
| POST | `/logout` | [AUTH] | Logout (Refresh-Token loeschen) |
| POST | `/change-password` | [AUTH] | Passwort aendern |
| POST | `/forgot-password` | [PUBLIC] | Passwort-Reset anfordern |
| GET | `/verify-reset-token/:token` | [PUBLIC] | Reset-Token validieren |
| POST | `/reset-password` | [PUBLIC] | Passwort zuruecksetzen |
| GET | `/verification-status` | [AUTH] | Email-Verifizierungsstatus |
| POST | `/send-verification-email` | [AUTH] | Verifizierungs-Email senden |
| GET | `/verify-email/:token` | [PUBLIC] | Email verifizieren |
| POST | `/push-token` | [AUTH] | Push-Notification Token speichern |

### auth.session.routes.ts
**Base-Path:** `/api/auth/v2`
**Middleware:** Per-Route (Session-basiert)

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | `/login` | [PUBLIC] | Session-basierter Login |
| POST | `/logout` | [SESSION] | Session beenden |
| POST | `/logout-all` | [SESSION] | Alle Sessions beenden |
| GET | `/me` | [SESSION] | Aktueller User |
| GET | `/sessions` | [SESSION] | Aktive Sessions auflisten |
| DELETE | `/sessions:sessionId` | [SESSION] | Einzelne Session loeschen |
| POST | `/change-password` | [SESSION] | Passwort aendern |
| GET | `/login-history` | [SESSION] | Login-Verlauf |
| POST | `/refresh-csrf` | [SESSION] | CSRF-Token erneuern |
| POST | `/impersonate` | [SESSION] | Als anderer User agieren |

### twoFactor.routes.ts
**Base-Path:** `/api/auth/2fa`
**Middleware:** Per-Route

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/status` | [AUTH] | 2FA-Status abfragen |
| POST | `/setup` | [AUTH] | 2FA einrichten (QR-Code generieren) |
| POST | `/verify` | [AUTH] | 2FA-Setup bestaetigen |
| POST | `/disable` | [AUTH] | 2FA deaktivieren |
| POST | `/validate` | [PUBLIC] | 2FA-Token bei Login validieren |
| GET | `/backup-codes` | [AUTH] | Backup-Codes anzeigen |
| POST | `/reset:userId` | [ADMIN] | 2FA fuer User zuruecksetzen |

---

## 2. User-Management

### user.routes.ts
**Base-Path:** `/api/users`
**Middleware:** Per-Route

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/` | [AUTH][ADMIN] | Alle Benutzer auflisten |
| GET | `/:id` | [AUTH] | Benutzer-Details (eigene oder Admin) |
| POST | `/` | [AUTH][ADMIN] | Neuen Benutzer anlegen |
| PUT | `/:id` | [AUTH] | Benutzer aktualisieren (Rolle/Status nur Admin) |
| DELETE | `/:id` | [AUTH][ADMIN] | Benutzer loeschen |

### me.routes.ts
**Base-Path:** `/api/me`
**Middleware:** Per-Route

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/` | [AUTH] | Eigenes Profil mit WhiteLabel |
| GET | `/company` | [AUTH] | Eigene Kundendaten |
| PUT | `/company` | [AUTH] | Eigene Kundendaten aendern |

### adminUsers.routes.ts
**Base-Path:** `/api/admin/users`
**Middleware:** Per-Route

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/simple` | [AUTH] | Vereinfachte User-Liste |
| GET | `/` | [AUTH] | Vollstaendige User-Liste |
| POST | `/` | [AUTH] | User anlegen (mit Validierung) |
| PATCH | `/:id` | [AUTH] | User aktualisieren |
| POST | `/:id/reset-password` | [AUTH] | Passwort zuruecksetzen |
| DELETE | `/:id` | [AUTH] | User loeschen |
| PATCH | `/:id/set-parent` | [AUTH][ADMIN] | Parent-User setzen (Subunternehmer) |
| POST | `/:id/block` | [AUTH][ADMIN] | User sperren |
| POST | `/:id/unblock` | [AUTH][ADMIN] | User entsperren |
| GET | `/:id/whatsapp` | [AUTH][ADMIN] | WhatsApp-Config eines Users |
| PATCH | `/:id/whatsapp` | [AUTH][ADMIN] | WhatsApp-Config aendern |
| POST | `/:id/whatsapp/verify` | [AUTH][ADMIN] | WhatsApp-Nummer verifizieren |
| POST | `/:id/whatsapp/confirm` | [AUTH][ADMIN] | WhatsApp-Verifizierung bestaetigen |
| DELETE | `/:id/whatsapp` | [AUTH][ADMIN] | WhatsApp-Config loeschen |

### preferences.routes.ts
**Base-Path:** `/api/me`
**Middleware:** `router.use(authenticateSession)`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| *Details via Session-Auth* | | [SESSION] | User Preferences, Views, Filters |

---

## 3. Kunden

### kunde.routes.ts
**Base-Path:** `/api/kunden`
**Middleware:** Per-Route

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/` | [AUTH][MA] | Kunden-Liste (paginiert, durchsuchbar) |
| GET | `/:id` | [AUTH] | Kunden-Details (Rollen-Check, SUB keine Rechnungen) |
| POST | `/` | [AUTH][MA] | Neuen Kunden anlegen |
| PUT | `/:id` | [AUTH][MA] | Kunden aktualisieren |
| DELETE | `/:id` | [AUTH][MA] | Kunden loeschen (nur wenn keine Anlagen/Vorgaenge) |

### kundePrices.routes.ts
**Base-Path:** `/api/admin/kunden`
**Middleware:** Per-Route

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/:kundeId/prices` | [AUTH] | Kundenspezifische Preise |
| PATCH | `/:kundeId/prices` | [AUTH] | Preise aktualisieren |
| DELETE | `/:kundeId/prices/:serviceKey` | [AUTH] | Einzelnen Preis loeschen |

---

## 4. Installations (Netzanmeldungen)

### installation.routes.ts
**Base-Path:** `/api/installations`
**Middleware:** Per-Route

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/` | [AUTH] | Installations-Liste (rollenbasiert, paginiert) |
| POST | `/` | [AUTH] | Neue Installation erstellen |
| POST | `/create-for-user` | [AUTH] | Installation fuer bestimmten User erstellen |
| GET | `/:id` | [AUTH] | Installations-Details (Access-Check) |
| PUT | `/:id` | [AUTH] | Installation aktualisieren |
| DELETE | `/:id` | [AUTH] | Installation loeschen |
| PATCH | `/:id/nb-tracking` | [AUTH] | NB-Tracking-Daten aktualisieren |
| PATCH | `/:id/nb-portal-credentials` | [AUTH] | NB-Portal-Zugangsdaten |
| POST | `/:id/alerts-toggle` | [AUTH] | Alert-Benachrichtigungen umschalten |
| PATCH | `/:id/assign` | [AUTH] | Installation zuweisen |
| POST | `/:id/confirm-mastr` | [AUTH] | MaStR-Eintrag bestaetigen |
| POST | `/:id/comments` | [AUTH] | Kommentar hinzufuegen (Legacy) |
| POST | `/:id/documents` | [AUTH] | Dokument hochladen |
| GET | `/:id/documents` | [AUTH] | Dokumente auflisten |

### netzanmeldungen.enterprise.routes.ts
**Base-Path:** `/api/installations` (wird VOR installation.routes gemountet)
**Middleware:** Per-Route

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/stats` | [AUTH] | Status-Statistiken |
| GET | `/sub-overview` | [AUTH] | Subunternehmer-Uebersicht |
| GET | `/grouped-by-nb` | [AUTH] | Nach Netzbetreiber gruppiert |
| GET | `/grouped-by-customer` | [AUTH] | Nach Kunde gruppiert |
| GET | `/list` | [AUTH] | Enterprise-Liste (erweitert) |
| GET | `/enterprise` | [AUTH] | Enterprise-Daten |
| GET | `/:id` | [AUTH] | Detail-Ansicht (Enterprise) |
| POST | `/:id/status` | [AUTH] | Status aendern (mit Workflow) |
| GET | `/:id/timeline` | [AUTH] | Zeitstrahl |
| POST | `/:id/timeline` | [AUTH] | Timeline-Eintrag hinzufuegen |
| GET | `/:id/checklist` | [AUTH] | Checkliste |
| PATCH | `/:id/checklist/:itemId` | [AUTH] | Checklisten-Element aktualisieren |
| PATCH | `/:id/customer` | [AUTH] | Kundendaten aktualisieren |
| POST | `/:id/grid-operator` | [AUTH] | Netzbetreiber zuweisen |
| POST | `/bulk/remove` | [AUTH] | Bulk-Loeschung |
| POST | `/bulk/status` | [AUTH] | Bulk-Status-Aenderung |
| POST | `/bulk/grid-operator` | [AUTH] | Bulk-NB-Zuweisung |
| GET | `/grid-operators` | [AUTH] | Netzbetreiber-Liste |
| GET | `/grid-operators/by-plz:plz` | [AUTH] | NB nach PLZ |
| GET | `/team` | [AUTH] | Team-Uebersicht |
| GET | `/analytics/dashboard` | [AUTH] | Analytics-Dashboard |
| GET | `/:id/emails` | [AUTH] | Zugehoerige Emails |
| PATCH | `/:id/nb-case-number` | [AUTH] | NB-Aktenzeichen setzen |
| PATCH | `/:id/nb-tracking` | [AUTH] | NB-Tracking |
| PATCH | `/:id/zaehlerwechsel` | [AUTH] | Zaehlerwechsel-Daten |
| GET | `/:id/tasks` | [AUTH] | Aufgaben auflisten |
| POST | `/:id/tasks` | [AUTH] | Aufgabe erstellen |
| PATCH | `/tasks:taskId` | [AUTH] | Aufgabe aktualisieren |
| POST | `/tasks:taskId/complete` | [AUTH] | Aufgabe abschliessen |
| DELETE | `/tasks:taskId` | [AUTH] | Aufgabe loeschen |

### installationsCustomer.routes.ts
**Base-Path:** `/api/installations`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | `/customer` | [AUTH] | Wizard-Finale: Installation + Anlage erstellen |

### installationWizard.routes.ts
**Base-Path:** `/api/installations`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | `/wizard/start` | [AUTH] | Wizard-Entwurf starten |

### installation.wizard.patch.ts
**Base-Path:** `/api/installations` (Sub-Router)

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| PATCH | `/:id/wizard` | [AUTH] | Wizard-Entwurf aktualisieren |

### installationsNbCase.routes.ts
**Base-Path:** `/api/installations`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| PATCH | `/:id/nb-case` | [AUTH] | NB-Aktenzeichen setzen/loeschen |

### installationsMeta.routes.ts
**Base-Path:** `/api/installations`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| PATCH | `/:id/nb-case` | [AUTH] | NB-Case-Daten aktualisieren |
| PATCH | `/:id` | [AUTH] | Meta-Daten aktualisieren |

### installationComments.routes.ts
**Base-Path:** `/api/installations`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/:id/comments` | [AUTH] | Kommentare auflisten (Access-Check) |
| POST | `/:id/comments` | [AUTH] | Kommentar erstellen (Permission-Check) |
| PATCH | `/:id/comments/:commentId` | [AUTH] | Kommentar bearbeiten |
| DELETE | `/:id/comments/:commentId` | [AUTH] | Kommentar loeschen |

### zaehlerwechselTermin.routes.ts
**Base-Path:** `/api`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | `/installations:id/zaehlerwechsel-termin` | [AUTH] | Termin erstellen |
| DELETE | `/installations:id/zaehlerwechsel-termin` | [AUTH] | Termin loeschen |
| GET | `/installations:id/zaehlerwechsel-termin` | [AUTH] | Termin anzeigen |
| GET | `/zaehlerwechsel-termine` | [AUTH] | Alle Termine |
| GET | `/public/confirm-termin:token` | [PUBLIC] | Termin oeffentlich bestaetigen |

---

## 5. Anlagen

### anlage.routes.ts
**Base-Path:** `/api/anlagen`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/` | [AUTH] | Anlagen-Liste (rollenbasiert) |
| GET | `/:id` | [AUTH] | Anlagen-Details |
| POST | `/` | [AUTH][MA] | Anlage erstellen |
| PUT | `/:id` | [AUTH][MA] | Anlage aktualisieren |
| DELETE | `/:id` | [AUTH][MA] | Anlage loeschen |

---

## 6. Dokumente

### document.routes.ts
**Base-Path:** `/api/documents`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/` | [AUTH] | Dokumente auflisten |
| GET | `/:id/download` | [AUTH] | Dokument herunterladen |
| POST | `/upload` | [AUTH] | Dokument hochladen |
| POST | `/upload:installationId` | [AUTH] | Dokument fuer Installation hochladen |
| GET | `/installation:installationId` | [AUTH] | Dokumente einer Installation |
| DELETE | `/:id` | [AUTH] | Dokument loeschen |
| POST | `/generate:installationId` | [AUTH] | Dokument generieren |

### documentType.routes.ts
**Base-Path:** `/api`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/document-types` | [AUTH] | Dokumenttypen auflisten |
| GET | `/installation/:id/document-status` | [AUTH] | Dokumenten-Vollstaendigkeit |
| GET | `/installation/:id/documents-by-category` | [AUTH] | Dokumente nach Kategorie |
| POST | `/documents/:id/detect-type` | [AUTH] | Dokumenttyp automatisch erkennen |
| PUT | `/documents/:id/type` | [AUTH] | Dokumenttyp manuell setzen |
| POST | `/installation/:id/check-missing-documents` | [AUTH] | Fehlende Dokumente pruefen |
| POST | `/document-types` | [AUTH][ADMIN] | Dokumenttyp erstellen |
| PUT | `/document-types/:id` | [AUTH][ADMIN] | Dokumenttyp aktualisieren |

### import-datasheets.routes.ts
**Base-Path:** `/api/documents`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | `/import-from-product-db` | [AUTH] | Datenblaetter aus Produkt-DB importieren |
| GET | `/available-datasheets:installationId` | [AUTH] | Verfuegbare Datenblaetter |

### upload.routes.ts
**Base-Path:** `/api/uploads`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | `/datenblatt` | [AUTH] | PDF-Datenblatt hochladen |
| GET | `/datenblaetter/:filename` | [AUTH] | Datenblatt herunterladen |

---

## 7. Email-System

### emails.routes.ts
**Base-Path:** `/api/emails`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/for-installation:id` | [AUTH] | Emails einer Installation |
| GET | `/unassigned` | [AUTH] | Nicht-zugewiesene Emails |
| GET | `/` | [AUTH] | Email-Liste |
| POST | `/auto-assign` | [AUTH] | Automatische Zuweisung |
| POST | `/:id/assign` | [AUTH] | Manuell zuweisen |
| POST | `/:id/unassign` | [AUTH] | Zuweisung aufheben |
| POST | `/:id/archive` | [AUTH] | Email archivieren |
| GET | `/:id` | [AUTH] | Email-Details |

### emailInbox.routes.ts
**Base-Path:** `/api/email-inbox`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/status` | [AUTH] | Inbox-Status |
| GET | `/mailboxes` | [AUTH] | Postfaecher auflisten |
| GET | `/customer-folders` | [AUTH] | Kunden-Ordner |
| GET | `/emails` | [AUTH] | Emails abrufen |
| POST | `/poll` | [AUTH] | Emails vom Server abrufen |
| GET | `/installation/:id` | [AUTH] | Emails zu Installation |
| GET | `/unassigned` | [AUTH] | Nicht-zugewiesene |
| POST | `/batch-archive` | [AUTH] | Batch-Archivierung |
| POST | `/batch-read` | [AUTH] | Batch als gelesen markieren |
| POST | `/batch-delete` | [AUTH] | Batch-Loeschung |
| POST | `/:id/assign` | [AUTH] | Email zuweisen |
| POST | `/:id/archive` | [AUTH] | Email archivieren |
| DELETE | `/:id` | [AUTH] | Email loeschen |
| GET | `/vnb-summary` | [AUTH] | VNB-Zusammenfassung |
| GET | `/escalations` | [AUTH] | Eskalationen |
| GET | `/search-installations` | [AUTH] | Installations-Suche fuer Zuweisung |
| GET | `/dashboard-stats` | [AUTH] | Dashboard-Statistiken |
| GET | `/:id` | [AUTH] | Email-Details |
| POST | `/:id/link-project` | [AUTH] | Mit Projekt verknuepfen |
| POST | `/:id/rematch` | [AUTH] | Erneut zuordnen |
| POST | `/escalations/:id/execute` | [AUTH] | Eskalation ausfuehren |
| POST | `/escalations/:id/skip` | [AUTH] | Eskalation ueberspringen |
| GET | `/:id/autoreply-draft` | [AUTH] | Auto-Reply-Entwurf |
| POST | `/:id/approve-autoreply` | [AUTH] | Auto-Reply genehmigen |
| POST | `/batch-rematch` | [AUTH] | Batch-Neuzuordnung |
| POST | `/analyze-batch` | [AUTH] | Batch-Analyse |
| POST | `/rematch` | [AUTH] | Neuzuordnung starten |
| GET | `/analyze-stats` | [AUTH] | Analyse-Statistiken |

### emailAdmin.routes.ts
**Base-Path:** `/api/email-center`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/stats` | [AUTH] | Email-System-Statistiken |
| GET | `/templates` | [AUTH] | Email-Templates auflisten |
| GET | `/templates/:id` | [AUTH] | Template-Details |
| POST | `/templates` | [AUTH] | Template erstellen |
| PATCH | `/templates/:id` | [AUTH] | Template aktualisieren |
| DELETE | `/templates/:id` | [AUTH] | Template loeschen |
| POST | `/templates/:id/preview` | [AUTH] | Template-Vorschau |
| GET | `/triggers` | [AUTH] | Email-Trigger auflisten |
| GET | `/triggers/events` | [AUTH] | Verfuegbare Events |
| POST | `/triggers` | [AUTH] | Trigger erstellen |
| PATCH | `/triggers/:id` | [AUTH] | Trigger aktualisieren |
| DELETE | `/triggers/:id` | [AUTH] | Trigger loeschen |
| POST | `/triggers/:id/toggle` | [AUTH] | Trigger an/aus |
| GET | `/queue` | [AUTH] | Email-Queue |
| POST | `/queue/:id/retry` | [AUTH] | Email erneut senden |
| POST | `/queue/:id/cancel` | [AUTH] | Email abbrechen |
| POST | `/queue/:id/approve` | [AUTH] | Email genehmigen |
| POST | `/queue/approve-all` | [AUTH] | Alle genehmigen |
| GET | `/logs` | [AUTH] | Email-Logs |
| GET | `/logs/:id` | [AUTH] | Log-Details |
| POST | `/send` | [AUTH] | Email direkt senden |
| GET | `/health` | [AUTH] | Email-System-Health |

### emailSend.routes.ts
**Base-Path:** `/api`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | `/installation/:id/send-email` | [AUTH] | Email fuer Installation senden |
| POST | `/installation/:id/reply-email` | [AUTH] | Auf Email antworten |
| GET | `/installation/:id/sent-emails` | [AUTH] | Gesendete Emails |
| GET | `/email-templates` | [AUTH] | Email-Templates |
| POST | `/email-templates/apply` | [AUTH] | Template anwenden |
| POST | `/email-templates` | [AUTH][ADMIN] | Template erstellen |

### emailLearning.routes.ts
**Base-Path:** `/api/email-learning`
**Middleware:** `router.use(authenticate, requireMitarbeiter)`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/classifications` | [AUTH][MA] | Klassifikationen auflisten |
| PATCH | `/classifications/:id/review` | [ADMIN] | Klassifikation reviewen |
| POST | `/classifications/:emailId/classify` | [ADMIN] | Email klassifizieren |
| POST | `/classifications/batch-classify` | [ADMIN] | Batch-Klassifikation |
| GET | `/rules` | [AUTH][MA] | Regeln auflisten |
| PUT | `/rules/:id` | [ADMIN] | Regel aktualisieren |
| POST | `/classifications/:id/reprocess` | [ADMIN] | Erneut verarbeiten |
| GET | `/model-comparison` | [AUTH][MA] | Modell-Vergleich (OpenAI vs. Ollama) |

---

## 8. NB-Kommunikation & Response

### nbCommunication.routes.ts
**Base-Path:** `/api/nb-communication`
**Middleware:** `router.use(authenticateSession)`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/installation:id` | [SESSION] | Kommunikation einer Installation |
| GET | `/stats` | [SESSION] | Kommunikations-Statistiken |
| POST | `/send` | [SESSION] | NB-Email senden |
| POST | `/send-erstanmeldung:installationId` | [SESSION] | Erstanmeldung senden |
| POST | `/send-nachfrage:installationId` | [SESSION] | Nachfrage senden |
| POST | `/response:correspondenceId` | [SESSION] | Antwort auf NB-Korrespondenz |
| POST | `/run-reminders` | [SESSION] | Erinnerungen ausfuehren |
| GET | `/pending` | [SESSION] | Offene Kommunikation |
| GET | `/netzbetreiber` | [SESSION] | NB-Liste fuer Kommunikation |
| PUT | `/netzbetreiber:id` | [SESSION] | NB-Daten aktualisieren |

### nbResponse.routes.ts
**Base-Path:** `/api/nb-response`
**Middleware:** `router.use(authenticate, requireMitarbeiter)`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/tasks` | [AUTH][MA] | NB-Response-Tasks auflisten |
| GET | `/tasks/:id` | [AUTH][MA] | Task-Details |
| POST | `/tasks/:id/approve` | [ADMIN] | Task genehmigen (Antwort senden) |
| PUT | `/tasks/:id/response` | [ADMIN] | Antwort-Text bearbeiten |
| POST | `/tasks/:id/request-customer` | [ADMIN] | Kundenrueckfrage |
| POST | `/tasks/:id/cancel` | [ADMIN] | Task abbrechen |
| POST | `/tasks/:id/refresh` | [AUTH][MA] | Task aktualisieren |
| POST | `/tasks/:id/re-resolve` | [ADMIN] | Erneut Auto-Resolve |
| GET | `/tasks/:id/comments` | [AUTH][MA] | Task-Kommentare |
| POST | `/tasks/:id/comments` | [ADMIN] | Kommentar hinzufuegen |
| GET | `/nb-patterns` | [AUTH][MA] | NB-Complaint-Patterns |
| GET | `/attachments` | [AUTH][MA] | Email-Anhaenge |
| GET | `/attachments/:id/download` | [AUTH][MA] | Anhang herunterladen |

### signatures.routes.ts
**Base-Path:** `/api/signatures`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | `/` | [AUTH][STAFF] | EFK-Unterschrift hochladen |
| GET | `/` | [AUTH][STAFF] | Alle Unterschriften |
| GET | `/default` | [AUTH][STAFF] | Standard-Unterschrift |
| GET | `/:id/image` | [AUTH][STAFF] | Unterschrift-Bild |
| PUT | `/:id` | [AUTH][STAFF] | Unterschrift aktualisieren |
| DELETE | `/:id` | [AUTH][STAFF] | Unterschrift loeschen |
| POST | `/draw` | [AUTH][STAFF] | Gezeichnete Unterschrift erstellen |
| PUT | `/:id/default` | [AUTH][STAFF] | Als Standard setzen |

---

## 9. Rechnungen & Finanzen

### rechnung.routes.ts
**Base-Path:** `/api/rechnungen`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/download-zip` | [AUTH] | Rechnungen als ZIP herunterladen |
| GET | `/` | [AUTH] | Rechnungen auflisten |
| GET | `/unbilled-installations` | [AUTH] | Nicht-abgerechnete Installationen |
| GET | `/billing-overview` | [AUTH] | Abrechnungs-Uebersicht |
| GET | `/abrechnung-overview` | [AUTH] | Detaillierte Abrechnungs-Uebersicht |
| GET | `/:id` | [AUTH] | Rechnungsdetails |
| POST | `/` | [AUTH] | Rechnung erstellen |
| POST | `/sammelrechnung` | [AUTH] | Sammelrechnung erstellen |
| POST | `/:id/finalize` | [AUTH] | Rechnung finalisieren |
| POST | `/:id/mark-paid` | [AUTH] | Als bezahlt markieren |
| POST | `/:id/set-status` | [AUTH] | Status aendern |
| POST | `/preview` | [AUTH] | Rechnungs-Vorschau |
| POST | `/:id/send` | [AUTH] | Rechnung per Email senden |
| GET | `/public:id/:token/pdf` | [PUBLIC] | Oeffentlicher PDF-Download |
| GET | `/:id/pdf` | [AUTH] | PDF herunterladen |
| GET | `/by-number:nummer/pdf` | [AUTH] | PDF nach Rechnungsnummer |
| DELETE | `/:id` | [AUTH] | Rechnung loeschen |
| POST | `/:id/storno` | [AUTH] | Storno-Rechnung erstellen |
| POST | `/batch-create` | [AUTH] | Batch-Erstellung |
| POST | `/installation:installationId/create-and-send` | [AUTH] | Erstellen und sofort senden |
| POST | `/:id/send-whatsapp` | [AUTH] | Per WhatsApp senden |

### mahnung.routes.ts
**Base-Path:** `/api/mahnungen`
**Middleware:** `router.use(authenticate)`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/settings` | [ADMIN] | Mahn-Einstellungen |
| PUT | `/settings` | [ADMIN] | Einstellungen aendern |
| GET | `/config` | [ADMIN] | Mahnstufen-Konfiguration |
| PUT | `/config/:stufe` | [ADMIN] | Mahnstufe konfigurieren |
| POST | `/run` | [ADMIN] | Mahnlauf starten |
| GET | `/preview` | [ADMIN] | Mahnlauf-Vorschau |
| GET | `/stats` | [AUTH][MA] | Mahn-Statistiken |
| GET | `/liste` | [AUTH][MA] | Mahnungen auflisten |
| GET | `/rechnung/:rechnungId` | [AUTH] | Mahnungen einer Rechnung |
| POST | `/:id/send` | [AUTH][MA] | Mahnung senden |
| GET | `/gesperrte` | [AUTH][MA] | Gesperrte Kunden |
| POST | `/kunde/:kundeId/sperren` | [ADMIN] | Kunden sperren |
| POST | `/kunde/:kundeId/entsperren` | [ADMIN] | Kunden entsperren |
| POST | `/rechnung/:rechnungId/sperre` | [AUTH][MA] | Rechnungssperre |
| PUT | `/kunde/:kundeId/einstellungen` | [ADMIN] | Kunden-Mahneinstellungen |

### bankintegration.routes.ts
**Base-Path:** `/api/bank`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/transactions` | [AUTH] | Bank-Transaktionen |
| POST | `/transactions/:id/match` | [AUTH] | Transaktion zuordnen |
| GET | `/stats` | [AUTH] | Bank-Statistiken |

### wise.routes.ts
**Base-Path:** `/api/wise`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/accounts` | [AUTH][ADMIN] | Wise-Konten |
| POST | `/accounts` | [AUTH][ADMIN] | Konto hinzufuegen |
| DELETE | `/accounts/:id` | [AUTH][ADMIN] | Konto entfernen |
| POST | `/sync` | [AUTH][ADMIN] | Alle synchronisieren |
| POST | `/accounts/:id/sync` | [AUTH][ADMIN] | Einzelnes Konto sync |
| GET | `/transactions` | [AUTH][MA] | Transaktionen |
| GET | `/transactions/unmatched` | [AUTH][MA] | Nicht-zugeordnete |
| POST | `/transactions/:id/match` | [AUTH][MA] | Zuordnen |
| GET | `/stats` | [AUTH][MA] | Statistiken |
| POST | `/payouts/:auszahlungId` | [AUTH][ADMIN] | Auszahlung ausfuehren |
| GET | `/payouts/:auszahlungId/status` | [AUTH][ADMIN] | Auszahlungs-Status |
| GET | `/balance` | [AUTH][ADMIN] | Kontostand |
| POST | `/recipients/:hvId` | [AUTH][ADMIN] | Empfaenger erstellen |
| POST | `/webhook/:accountId` | [PUBLIC] | Wise-Webhook (Server-to-Server) |

### paymentLink.routes.ts
**Base-Path:** `/api/payment-links`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | `/` | [AUTH][MA] | Payment-Link erstellen |
| GET | `/` | [AUTH][MA] | Links auflisten |
| GET | `/stats` | [AUTH][MA] | Statistiken |
| DELETE | `/:id` | [AUTH][MA] | Link loeschen |
| PATCH | `/:id/wise-url` | [AUTH][MA] | Wise-URL aktualisieren |
| GET | `/public/:token` | [PUBLIC] | Oeffentliche Zahlungsseite |
| POST | `/for-invoice/:rechnungId` | [AUTH] | Link fuer Rechnung erstellen |

### accounting.routes.ts
**Base-Path:** `/api/accounting`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/accounts` | [AUTH] | Kontenplan |
| GET | `/accounts:id` | [AUTH] | Konto-Details |
| POST | `/accounts` | [AUTH] | Konto erstellen |
| PUT | `/accounts:id` | [AUTH] | Konto aktualisieren |
| GET | `/accounts:id/ledger` | [AUTH] | Kontoblatt |
| GET | `/categories` | [AUTH] | Buchungskategorien |
| GET | `/journal` | [AUTH] | Journal-Eintraege |
| GET | `/journal:id` | [AUTH] | Journal-Detail |
| POST | `/journal` | [AUTH] | Buchung erstellen |
| POST | `/journal:id/post` | [AUTH] | Buchung buchen |
| POST | `/journal:id/reverse` | [AUTH] | Storno-Buchung |
| GET | `/expenses` | [AUTH] | Ausgaben |
| GET | `/expenses/stats` | [AUTH] | Ausgaben-Statistiken |
| GET | `/expenses/categories` | [AUTH] | Ausgaben-Kategorien |
| GET | `/expenses:id` | [AUTH] | Ausgabe-Detail |
| POST | `/expenses` | [AUTH] | Ausgabe erstellen |
| PUT | `/expenses:id` | [AUTH] | Ausgabe aktualisieren |
| POST | `/expenses:id/pay` | [AUTH] | Ausgabe als bezahlt |
| POST | `/expenses:id/void` | [AUTH] | Ausgabe stornieren |
| POST | `/expenses:id/upload` | [AUTH] | Beleg hochladen |
| POST | `/expenses/from-wise:transactionId` | [AUTH] | Aus Wise-Transaktion |
| GET | `/vendors` | [AUTH] | Lieferanten |
| GET | `/vendors/search` | [AUTH] | Lieferanten suchen |
| GET | `/vendors:id` | [AUTH] | Lieferant-Detail |
| POST | `/vendors` | [AUTH] | Lieferant erstellen |
| PUT | `/vendors:id` | [AUTH] | Lieferant aktualisieren |
| DELETE | `/vendors:id` | [AUTH] | Lieferant loeschen |
| GET | `/exchange-rates` | [AUTH] | Wechselkurse |
| GET | `/exchange-rates/current` | [AUTH] | Aktuelle Kurse |
| POST | `/exchange-rates/sync` | [AUTH] | Kurse synchronisieren |
| POST | `/exchange-rates` | [AUTH] | Kurs erstellen |
| GET | `/reports/trial-balance` | [AUTH] | Saldenbilanz |
| GET | `/reports/income-statement` | [AUTH] | GuV |
| GET | `/reports/balance-sheet` | [AUTH] | Bilanz |
| GET | `/reports/dashboard` | [AUTH] | Finanz-Dashboard |
| GET | `/reports/intercompany` | [AUTH] | Intercompany-Report |
| GET | `/reports/general-ledger` | [AUTH] | Hauptbuch |
| GET | `/fiscal-years` | [AUTH] | Geschaeftsjahre |
| POST | `/fiscal-years` | [AUTH] | Geschaeftsjahr erstellen |
| GET | `/year-end/validate:year` | [AUTH] | Jahresabschluss-Validierung |
| POST | `/year-end/close:year` | [AUTH] | Jahresabschluss |
| POST | `/year-end/tax-package:year` | [AUTH] | Steuerpaket erstellen |
| GET | `/year-end/tax-package:year/download` | [AUTH] | Steuerpaket herunterladen |
| GET | `/legal-entities` | [AUTH] | Rechtseinheiten |

### accountingAI.routes.ts
**Base-Path:** `/api/accounting/ai`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | `/extract-invoice` | [AUTH][MA] | KI: Rechnungsdaten extrahieren |
| GET | `/match-suggestions:transactionId` | [AUTH][MA] | KI: Zuordnungs-Vorschlaege |
| GET | `/unmatched-with-suggestions` | [AUTH][MA] | Nicht-zugeordnete mit Vorschlaegen |
| POST | `/auto-match` | [AUTH][MA] | KI: Auto-Zuordnung |
| GET | `/matching-stats` | [AUTH][MA] | Matching-Statistiken |
| GET | `/insights` | [AUTH][MA] | KI-Finanz-Insights |
| GET | `/anomalies` | [AUTH][MA] | Anomalien |
| POST | `/anomalies/detect` | [AUTH][ADMIN][AI-LIMIT] | Anomalie-Erkennung starten |
| POST | `/anomalies:id/resolve` | [AUTH][MA] | Anomalie bearbeiten |
| GET | `/top-expenses` | [AUTH][MA] | Top-Ausgaben |
| GET | `/top-customers` | [AUTH][MA] | Top-Kunden |
| POST | `/chat` | [AUTH][MA][AI-LIMIT] | KI-Chat fuer Buchhaltung |

### op.routes.ts
**Base-Path:** `/api/op`
**Middleware:** `router.use(authenticate, requireStaff)`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/dashboard` | [AUTH][STAFF] | OP-Dashboard |
| GET | `/offene-posten` | [AUTH][STAFF] | Offene Posten auflisten |
| GET | `/kunden-saldo` | [AUTH][STAFF] | Kunden-Salden |
| GET | `/kunden-saldo/:kundeId` | [AUTH][STAFF] | Einzelkunden-Saldo |
| GET | `/mahnwesen` | [AUTH][STAFF] | Mahnwesen-Uebersicht |

---

## 10. Dashboard & Analytics

### dashboard.routes.ts
**Base-Path:** `/api/dashboard`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/summary` | [AUTH] | Dashboard-Zusammenfassung |
| GET | `/kpis` | [AUTH] | Key Performance Indicators |
| GET | `/speed-stats` | [AUTH] | Bearbeitungsgeschwindigkeit |
| GET | `/activity-feed` | [AUTH] | Aktivitaets-Feed |
| GET | `/priorities` | [AUTH] | Prioritaeten |
| GET | *(weitere)* | [AUTH] | Weitere Dashboard-Widgets |

### analytics.routes.ts
**Base-Path:** `/api/analytics`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/` | [AUTH][STAFF] | Analytics-Daten |
| GET | `/export/pdf` | [AUTH][STAFF] | PDF-Export |
| GET | `/export/excel` | [AUTH][STAFF] | Excel-Export |

---

## 11. Factro Integration

### factro.routes.ts
**Base-Path:** `/api/factro`
**Middleware:** `router.use(authenticate)`, `router.use(requireFactroAccess)`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/projects` | [AUTH] | Factro-Projekte |
| GET | `/projects/stats` | [AUTH] | Projekt-Statistiken |
| GET | `/projects/:id` | [AUTH] | Projekt-Details |
| PATCH | `/projects/:id` | [AUTH] | Projekt aktualisieren |
| GET | `/templates/speicher` | [AUTH] | Speicher-Templates |
| GET | `/templates/speicher/:typ` | [AUTH] | Speicher-Template nach Typ |
| POST | `/projects/:id/create-installation` | [AUTH] | Installation aus Factro erstellen |
| GET | `/configs` | [AUTH] | Factro-Konfigurationen |
| POST | `/configs` | [ADMIN] | Config erstellen |
| PUT | `/configs/:id` | [ADMIN] | Config aktualisieren |
| DELETE | `/configs/:id` | [ADMIN] | Config loeschen |
| POST | `/configs/:id/test` | [ADMIN] | Config testen |
| POST | `/poll` | [AUTH] | Factro-Daten abrufen |
| POST | `/repair-descriptions` | [AUTH] | Beschreibungen reparieren |
| POST | `/import-all` | [ADMIN] | Alle Projekte importieren |
| GET | `/sync-logs` | [AUTH] | Sync-Logs |
| POST | `/import-documents` | [ADMIN] | Dokumente importieren |
| POST | `/projects/:id/import-documents` | [AUTH] | Projekt-Dokumente importieren |
| GET | `/projects/:id/documents` | [AUTH] | Projekt-Dokumente |
| GET | `/projects/:id/comments` | [AUTH] | Factro-Kommentare |
| POST | `/projects/:id/sync-comments` | [AUTH] | Kommentare synchronisieren |
| POST | `/sync-all-comments` | [ADMIN] | Alle Kommentare sync |
| GET | `/external-projects` | [ADMIN] | Externe Factro-Projekte |
| GET | `/external-projects/:id/packages` | [ADMIN] | Packages eines Projekts |
| GET | `/netzanfrage/batch/preview` | [AUTH] | Batch-Netzanfrage-Vorschau |
| POST | `/netzanfrage/batch/send` | [AUTH] | Batch-Netzanfrage senden |
| POST | `/netzanfrage/:projectId/send-reminder` | [AUTH] | Erinnerung senden |
| GET | `/netzanfrage/:projectId/reminder-count` | [AUTH] | Erinnerungs-Zaehler |
| GET | `/netzanfrage/:projectId/preview` | [AUTH] | Netzanfrage-Vorschau |
| POST | `/netzanfrage/:projectId/send` | [AUTH] | Netzanfrage senden |
| GET | `/projects/:id/emails` | [AUTH] | Projekt-Email-Verlauf |

### factroCommentActions.routes.ts
**Base-Path:** `/api/factro/comment-actions`
**Middleware:** `router.use(authenticate)`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/` | [AUTH] | Comment-Actions auflisten |
| GET | `/stats` | [AUTH] | Action-Statistiken |
| GET | `/projects/:id/comment-actions` | [AUTH] | Actions eines Projekts |
| POST | `/:id/execute` | [AUTH] | Action ausfuehren |
| POST | `/:id/dismiss` | [AUTH] | Action verwerfen |
| POST | `/analyze` | [ADMIN] | Analyse starten |
| POST | `/backfill` | [ADMIN] | Backfill starten |

---

## 12. KI/AI-Services

### ai.routes.ts
**Base-Path:** `/api/ai`
**Rate-Limiter:** `aiLimiter`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | `/chat` | [AUTH][AI-LIMIT] | KI-Chat (RAG-gestuetzt) |
| GET | `/quick/stats` | [AUTH] | Schnell-Statistiken |
| GET | `/quick/overdue` | [AUTH] | Ueberfaellige Vorgaenge |
| GET | `/quick/pending` | [AUTH] | Ausstehende Vorgaenge |
| POST | `/generate-email` | [AUTH][AI-LIMIT] | Email generieren |

### claudeAI.routes.ts
**Base-Path:** `/api/claude-ai`
**Rate-Limiter:** `aiLimiter`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | `/analyze-email:id` | [AUTH] | Email per Claude analysieren |
| POST | `/analyze-emails/batch` | [AUTH] | Batch-Email-Analyse |
| GET | `/installation:id/summary` | [AUTH] | Installations-Zusammenfassung |
| GET | `/installation:id/quality-check` | [AUTH] | Qualitaetspruefung |
| POST | `/generate-response` | [AUTH] | Antwort generieren |
| GET | `/alerts` | [AUTH] | KI-Alerts |
| GET | `/installation:id/alerts` | [AUTH] | Installation-Alerts |
| GET | `/status` | [AUTH] | Claude-Status |
| GET | `/dashboard` | [AUTH] | KI-Dashboard |
| POST | `/installation:id/assistant` | [AUTH] | KI-Assistent |
| GET | `/installation:id/insights` | [AUTH] | KI-Insights |

### aiAssistant.routes.ts
**Base-Path:** `/api/ai-assistant`
**Rate-Limiter:** `aiLimiter`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | `/email/analyze-rueckfrage` | [AUTH] | Rueckfrage analysieren |
| POST | `/email/generate-response` | [AUTH] | Antwort generieren |
| POST | `/email/suggest-template` | [AUTH] | Template vorschlagen |
| GET | `/email/quick-actions:installationId` | [AUTH] | Quick-Actions |
| GET | `/workflow/insights` | [AUTH] | Workflow-Insights |

### claudeCode.routes.ts
**Base-Path:** `/api/claude-code`
**Rate-Limiter:** `aiLimiter`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | *(9 Endpoints)* | [AUTH] | Claude Code CLI Integration |
| POST | *(mehrere)* | [AUTH] | Tasks, Queries, etc. |
| DELETE | *(1 Endpoint)* | [AUTH] | Task loeschen |

### openaiTest.routes.ts
**Base-Path:** `/api/openai-test`
**Middleware:** `router.use(authenticate, requireAdmin)`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | `/test/analyze-email` | [AUTH][ADMIN] | Test: Email analysieren |
| POST | `/test/analyze-and-alert` | [AUTH][ADMIN] | Test: Analyse + Alert |
| POST | `/test/detect-document` | [AUTH][ADMIN] | Test: Dokument erkennen |

### rag.routes.ts
**Base-Path:** `/api/rag`
**Middleware:** `router.use(authenticate)`, `router.use(requireAdmin)`
**Rate-Limiter:** `aiLimiter`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | `/index` | [AUTH][ADMIN] | RAG-Index erstellen |
| GET | `/index/:jobId` | [AUTH][ADMIN] | Index-Job-Status |
| GET | `/status` | [AUTH][ADMIN] | RAG-System-Status |
| POST | `/search` | [AUTH][ADMIN] | RAG-Suche |
| GET | `/categories` | [AUTH][ADMIN] | Verfuegbare Kategorien |
| POST | `/reindex` | [AUTH][ADMIN] | Reindex starten |
| GET | `/changes` | [AUTH][ADMIN] | Aenderungen seit letztem Index |
| GET | `/health` | [AUTH][ADMIN] | RAG-Health-Check |

### featureBuilder.routes.ts
**Base-Path:** `/api/feature-builder`
**Middleware:** `router.use(authenticate)`, `router.use(requireRole(ADMIN))`
**Rate-Limiter:** `aiLimiter`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | `/plan` | [AUTH][ADMIN] | Feature-Plan erstellen (KI) |
| GET | `/list` | [AUTH][ADMIN] | Feature-Plaene auflisten |
| GET | `/:id` | [AUTH][ADMIN] | Plan-Details |
| DELETE | `/:id` | [AUTH][ADMIN] | Plan loeschen |

---

## 13. Produkte & Technik

### produkte.routes.ts
**Base-Path:** `/api/produkte`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | `/smart-match` | [AUTH] | Smart-Produktzuordnung |
| GET | `/stats` | [AUTH] | Produkt-Statistiken |
| GET | `/hersteller` | [AUTH] | Hersteller auflisten |
| POST | `/hersteller` | [AUTH][MA] | Hersteller erstellen |
| PUT | `/hersteller/:id` | [AUTH][MA] | Hersteller aktualisieren |
| DELETE | `/hersteller/:id` | [AUTH][MA] | Hersteller loeschen |
| GET | `/wechselrichter` | [AUTH] | Wechselrichter auflisten |
| GET | `/wechselrichter/:id/kompatible-speicher` | [AUTH] | Kompatible Speicher |
| GET | `/wechselrichter/:id` | [AUTH] | Wechselrichter-Details |
| POST | `/wechselrichter` | [AUTH][MA] | Wechselrichter erstellen |
| PUT | `/wechselrichter/:id` | [AUTH][MA] | Wechselrichter aktualisieren |
| DELETE | `/wechselrichter/:id` | [AUTH][MA] | Wechselrichter loeschen |
| GET | `/speicher` | [AUTH] | Speicher auflisten |
| GET | `/speicher/:id` | [AUTH] | Speicher-Details |
| POST | `/speicher` | [AUTH][MA] | Speicher erstellen |
| PUT | `/speicher/:id` | [AUTH][MA] | Speicher aktualisieren |
| DELETE | `/speicher/:id` | [AUTH][MA] | Speicher loeschen |
| *(weitere ~30 CRUD-Endpoints)* | | [AUTH] | Module, Wallboxen, etc. |

### wizardLearning.routes.ts
**Base-Path:** `/api/wizard-learning`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | `/` | [AUTH] | Wizard-Konfiguration speichern |
| POST | `/suggestions` | [SESSION] | KI-Vorschlaege |
| GET | `/regional/:plzPrefix` | [AUTH] | Regionale Insights |
| GET | `/user-insights` | [AUTH] | User-Insights |
| POST | `/compatible-products` | [AUTH] | Kompatible Produkte suchen |
| POST | `/feedback` | [AUTH] | Feedback geben |
| GET | `/stats` | [AUTH] | Wizard-Statistiken |
| GET | `/tab-hints` | [SESSION] | Tab-Hints |

### zerez.routes.ts
**Base-Path:** `/api/zerez`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/categories` | [AUTH] | ZEREZ-Kategorien |
| GET | `/search` | [AUTH] | ZEREZ-Suche |
| GET | `/autocomplete` | [AUTH] | Autovervollstaendigung |
| GET | `/admin/stats` | [AUTH][ADMIN] | ZEREZ-Statistiken |
| POST | `/admin/import` | [AUTH][ADMIN] | ZEREZ-Import |
| POST | `/admin/fetch-and-import` | [AUTH][ADMIN] | Fetch + Import |
| DELETE | `/admin/all` | [AUTH][ADMIN] | Alle ZEREZ-Daten loeschen |
| GET | `/:zerezId` | [AUTH] | ZEREZ-Detail |

---

## 14. Projekte

### projekte.routes.ts
**Base-Path:** `/api/projekte`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/config/status` | [AUTH] | Status-Konfiguration |
| GET | `/config/typen` | [AUTH] | Projekttypen |
| GET | `/` | [AUTH] | Projekte auflisten |
| GET | `/stats` | [AUTH] | Projekt-Statistiken |
| GET | `/:id` | [AUTH] | Projekt-Details |
| POST | `/` | [AUTH] | Projekt erstellen |
| PATCH | `/:id` | [AUTH] | Projekt aktualisieren |
| DELETE | `/:id` | [AUTH] | Projekt loeschen |
| POST | `/:id/archivieren` | [AUTH] | Projekt archivieren |
| GET | `/:id/komponenten` | [AUTH] | Komponenten auflisten |
| POST | `/:id/komponenten` | [AUTH] | Komponente hinzufuegen |
| DELETE | `/:projektId/komponenten/:id` | [AUTH] | Komponente entfernen |
| GET | `/:id/timeline` | [AUTH] | Zeitstrahl |
| POST | `/:id/timeline` | [AUTH] | Timeline-Eintrag |
| GET | `/:id/aufgaben` | [AUTH] | Aufgaben |
| POST | `/:id/aufgaben` | [AUTH] | Aufgabe erstellen |
| PATCH | `/:projektId/aufgaben/:id` | [AUTH] | Aufgabe aktualisieren |
| DELETE | `/:projektId/aufgaben/:id` | [AUTH] | Aufgabe loeschen |
| GET | `/:id/dokumente` | [AUTH] | Dokumente |
| POST | `/:id/dokumente` | [AUTH] | Dokument hochladen |
| GET | `/:id/zahlungen` | [AUTH] | Zahlungen |
| POST | `/:id/zahlungen` | [AUTH] | Zahlung hinzufuegen |
| GET | `/:id/termine` | [AUTH] | Termine |
| POST | `/:id/termine` | [AUTH] | Termin erstellen |

---

## 15. Netzbetreiber & VNB

### netzbetreiber.routes.ts
**Base-Path:** `/api/netzbetreiber`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/` | [AUTH] | Netzbetreiber auflisten |
| POST | `/import` | [AUTH] | NB importieren |
| POST | `/import/preview` | [AUTH] | Import-Vorschau |
| GET | `/by-plz:plz` | [AUTH] | NB nach PLZ |
| GET | `/plz:plz` | [AUTH] | PLZ-Lookup |
| GET | `/debug-plz:plz` | [AUTH] | PLZ-Debug |
| POST | `/auto-assign` | [AUTH] | Auto-Zuweisung |
| GET | `/performance` | [AUTH] | NB-Performance |
| GET | `/stats/overview` | [AUTH] | NB-Statistiken |
| GET | `/export` | [AUTH] | NB-Export |
| POST | `/bulk` | [AUTH] | Bulk-Operationen |
| PATCH | `/:id/workflow` | [AUTH] | Workflow-Daten |
| GET | `/:id/few-shot-examples` | [AUTH] | Few-Shot-Beispiele |
| POST | `/:id/few-shot-examples` | [AUTH] | Beispiel hinzufuegen |
| PUT | `/:id/few-shot-examples/:exampleId` | [AUTH] | Beispiel aktualisieren |
| DELETE | `/:id/few-shot-examples/:exampleId` | [AUTH] | Beispiel loeschen |
| GET | `/:id` | [AUTH] | NB-Details |
| POST | `/` | [AUTH] | NB erstellen |
| PUT | `/:id` | [AUTH] | NB aktualisieren |
| PATCH | `/:id` | [AUTH] | NB-Teilupdate |
| DELETE | `/:id` | [AUTH] | NB loeschen |

### vnbdigital.routes.ts
**Base-Path:** `/api/vnbdigital`
**Middleware:** `router.use(authenticate)`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/lookup` | [AUTH] | VNB per PLZ suchen |
| GET | `/lookup-all` | [AUTH] | Alle VNBs per PLZ |
| POST | `/enrich-netzbetreiber` | [AUTH][ADMIN] | NB mit VNBdigital anreichern |
| POST | `/update-installations` | [AUTH][ADMIN] | Installationen aktualisieren |

### nbWissen.routes.ts
**Base-Path:** `/api/nb-wissen`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/` | [AUTH] | NB-Wissensdatenbank |
| POST | `/:nbId/tab-upload` | [AUTH] | Tab-Dokument hochladen |
| POST | `/:nbId/tab-analyze/:docId` | [AUTH] | Tab-Dokument analysieren |
| DELETE | `/:nbId/tab/:docId` | [AUTH] | Tab-Dokument loeschen |

### nbPortalConfig.routes.ts
**Base-Path:** `/api/nb-portal-config`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/` | [AUTH] | Portal-Konfigurationen |
| GET | `/:id` | [AUTH] | Config-Details |
| POST | `/` | [AUTH] | Config erstellen (Admin-Check inline) |
| PUT | `/:id` | [AUTH] | Config aktualisieren (Admin-Check inline) |
| POST | `/poll` | [AUTH] | Poll starten (Admin-Check inline) |
| GET | `/:netzbetreiberId/form-filler-status` | [AUTH] | Form-Filler-Status |

### nbPortalProxy.routes.ts
**Base-Path:** `/api/nb-proxy`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/portals` | [AUTH] | Portal-Liste |
| POST | `/session/start` | [AUTH] | Browser-Session starten |
| GET | `/session:sessionId` | [AUTH] | Session-Status |
| GET | `/:sessionId/page` | [AUTH] | Seite abrufen |
| GET | `/:sessionId/navigate` | [AUTH] | Navigieren |
| POST | `/:sessionId/click` | [AUTH] | Klick simulieren |
| POST | `/:sessionId/button` | [AUTH] | Button klicken |
| POST | `/:sessionId/fill` | [AUTH] | Formular fuellen |
| POST | `/:sessionId/submit` | [AUTH] | Formular absenden |
| GET | `/:sessionId/screenshot` | [AUTH] | Screenshot |
| POST | `/:sessionId/heartbeat` | [AUTH] | Heartbeat |
| POST | `/:sessionId/end` | [AUTH] | Session beenden |
| GET | `/admin/stats` | [AUTH] | Admin-Statistiken |
| GET | `/form-definition:portalId/:productId` | [AUTH] | Formular-Definition |
| POST | `/form-submit:portalId/:productId` | [AUTH] | Formular einreichen |
| POST | `/form-draft:portalId/:productId` | [AUTH] | Entwurf speichern |
| GET | `/submissions` | [AUTH] | Einreichungen |
| GET | `/submissions:submissionId` | [AUTH] | Einreichungs-Details |
| POST | `/form-upload:portalId/:productId` | [AUTH] | Datei-Upload |
| DELETE | `/form-upload:portalId/:productId/:fileId` | [AUTH] | Upload loeschen |
| GET | `/address-autocomplete:portalId` | [AUTH] | Adress-Autovervollstaendigung |
| POST | `/form-validate:portalId/:productId` | [AUTH] | Formular-Validierung |
| POST | `/stromnetz-berlin/session` | [AUTH] | Stromnetz Berlin: Session |
| POST | `/stromnetz-berlin:sessionId/heartbeat` | [AUTH] | SB: Heartbeat |
| POST | `/stromnetz-berlin:sessionId/end` | [AUTH] | SB: Session beenden |
| GET | `/stromnetz-berlin/asset/*` | [AUTH] | SB: Asset laden |
| GET | `/stromnetz-berlin:sessionId/*` | [AUTH] | SB: GET-Proxy |
| POST | `/stromnetz-berlin:sessionId/*` | [AUTH] | SB: POST-Proxy |
| GET | `/stromnetz-berlin/admin/stats` | [AUTH] | SB: Admin-Stats |

---

## 16. Workflow & Ops

### workflow.routes.ts
**Base-Path:** `/api/workflow`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/overview` | [AUTH] | Workflow-Uebersicht |
| POST | `/screenshot-sync` | [AUTH] | Screenshot-Sync starten |
| POST | `/screenshot-sync/apply` | [AUTH] | Screenshots anwenden |
| POST | `/:id/wiedervorlage` | [AUTH] | Wiedervorlage setzen |
| PATCH | `/task:taskId/complete` | [AUTH] | Task abschliessen |
| POST | `/:id/complete-work-item` | [AUTH] | Work-Item abschliessen |
| POST | `/:id/ai-suggest` | [AUTH] | KI-Vorschlag |
| POST | `/:id/mastr-auto-match` | [AUTH] | MaStR Auto-Match |
| POST | `/:id/smart-notes` | [AUTH] | Smart-Notes erstellen |
| POST | `/:id/smart-notes/apply` | [AUTH] | Smart-Notes anwenden |
| POST | `/:id/rueckfrage-response/approve` | [AUTH] | Rueckfrage genehmigen |
| POST | `/:id/rueckfrage-response/reject` | [AUTH] | Rueckfrage ablehnen |

### workflowV2.routes.ts
**Base-Path:** `/api/v2`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/inbox` | [AUTH] | V2-Inbox |
| POST | `/inbox:id/resolve` | [AUTH] | Item loesen |
| POST | `/inbox:id/action/:actionId` | [AUTH] | Action ausfuehren |
| GET | `/inbox/counts` | [AUTH] | Inbox-Zaehler |
| POST | `/inbox:id/snooze` | [AUTH] | Snooze |
| POST | `/inbox:id/unsnooze` | [AUTH] | Unsnooze |
| POST | `/inbox/backfill` | [AUTH] | Inbox-Backfill |
| GET | `/installations:id/timeline` | [AUTH] | Timeline |
| POST | `/installations:id/events` | [AUTH] | Event hinzufuegen |
| GET | `/pipeline` | [AUTH] | Pipeline-Ansicht |
| POST | `/installations:id/transition` | [AUTH] | Status-Transition |
| GET | `/deadlines` | [AUTH] | Deadlines |
| GET | `/installations:id/email-drafts` | [AUTH] | Email-Entwuerfe |
| POST | `/installations:id/email-drafts` | [AUTH] | Entwurf erstellen |
| PUT | `/email-drafts:id` | [AUTH] | Entwurf bearbeiten |
| POST | `/email-drafts:id/approve` | [AUTH] | Entwurf genehmigen |
| POST | `/email-drafts:id/reject` | [AUTH] | Entwurf ablehnen |
| POST | `/email-drafts:id/send` | [AUTH] | Entwurf senden |
| DELETE | `/email-drafts:id` | [AUTH] | Entwurf loeschen |
| GET | `/stats` | [AUTH] | V2-Statistiken |

### ops.routes.ts
**Base-Path:** `/api/ops`
**Middleware:** `router.use(authenticate, requireStaff)`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/cases` | [AUTH][STAFF] | NB-Reminder Cases |
| GET | `/stats` | [AUTH][STAFF] | Ops-Statistiken |
| POST | `/cases:id/remind` | [AUTH][STAFF] | Erinnerung senden |
| PATCH | `/cases:id` | [AUTH][STAFF] | Case aktualisieren |
| PATCH | `/cases:id/automation` | [AUTH][STAFF] | Automation-Einstellung |
| POST | `/cases:id/comments` | [AUTH][STAFF] | Case-Kommentar |
| GET | `/nb-directory` | [AUTH][STAFF] | NB-Verzeichnis |
| PATCH | `/nb:id` | [AUTH][STAFF] | NB-Daten aktualisieren |
| GET | `/log` | [AUTH][STAFF] | Ops-Log |
| GET | `/data-quality` | [AUTH][STAFF] | Datenqualitaet |

### automations.routes.ts
**Base-Path:** `/api`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | *(Endpoint 1)* | [AUTH] | Automation starten |
| GET | *(Endpoint 2)* | [AUTH] | Automations auflisten |
| POST | *(Endpoint 3)* | [AUTH] | Automation ausfuehren |
| POST | *(Endpoint 4)* | [AUTH] | Automation testen |
| GET | *(Endpoint 5)* | [AUTH] | Automation-Status |
| POST | *(Endpoint 6)* | [AUTH] | Automation-Aktion |
| GET | *(Endpoint 7)* | [AUTH] | Automation-Logs |

---

## 17. Handelsvertreter & Provisionen

### handelsvertreter.routes.ts
**Base-Path:** `/api/admin/hv`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/` | [AUTH] | HV-Liste |
| POST | `/` | [AUTH] | HV erstellen |
| GET | `/:id` | [AUTH] | HV-Details |
| PUT | `/:id` | [AUTH] | HV aktualisieren |
| DELETE | `/:id` | [AUTH] | HV loeschen |
| GET | `/:id/kunden` | [AUTH] | HV-Kunden |
| GET | `/:id/provisionen` | [AUTH] | HV-Provisionen |
| GET | `/:id/auszahlungen` | [AUTH] | HV-Auszahlungen |
| POST | `/:id/auszahlungen` | [AUTH] | Auszahlung erstellen |

### hv.routes.ts
**Base-Path:** `/api/hv`
**Middleware:** `router.use(authenticate, requireHandelsvertreter)`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/kunden-check` | [AUTH][HV] | Kunden-Berechtigung pruefen |
| GET | `/dashboard` | [AUTH][HV] | HV-Dashboard |
| GET | `/profil` | [AUTH][HV] | Eigenes Profil |
| PUT | `/profil` | [AUTH][HV] | Profil aktualisieren |
| GET | `/kunden` | [AUTH][HV] | Zugewiesene Kunden |
| POST | `/kunden` | [AUTH][HV] | Kunden hinzufuegen |
| GET | `/provisionen` | [AUTH][HV] | Eigene Provisionen |
| GET | `/provisionen/stats` | [AUTH][HV] | Provisions-Statistiken |
| GET | `/auszahlungen` | [AUTH][HV] | Eigene Auszahlungen |
| GET | `/benutzer` | [AUTH][HV] | Eigene Benutzer (Subs) |
| POST | `/benutzer/demo` | [AUTH][HV] | Demo-Account erstellen |
| POST | `/benutzer` | [AUTH][HV] | Sub-Benutzer erstellen |
| POST | `/demo-account` | [AUTH][HV] | Demo-Account (alternativ) |

### provisionen.routes.ts
**Base-Path:** `/api/admin/provisionen`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/` | [AUTH] | Provisionen auflisten |
| GET | `/summary` | [AUTH] | Provisions-Zusammenfassung |
| GET | `/verrechnung/preview` | [AUTH] | Verrechnungs-Vorschau |
| POST | `/verrechnung` | [AUTH] | Verrechnung durchfuehren |
| GET | `/:id` | [AUTH] | Provisions-Details |
| POST | `/batch-freigeben` | [AUTH] | Batch-Freigabe |
| POST | `/stornieren:id` | [AUTH] | Provision stornieren |

### auszahlungen.routes.ts
**Base-Path:** `/api/admin/auszahlungen`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| *(CRUD Endpoints)* | | [AUTH] | Auszahlungen verwalten |

### hvContract.routes.ts
**Base-Path:** `/api/hv/contract` (Self-Service), `/api/admin/hv-contracts` (Admin)

**hvSelfService:**

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/current` | [AUTH] | Aktueller Vertrag |
| GET | `/pdf` | [AUTH] | Vertrag als PDF |
| POST | `/accept` | [AUTH] | Vertrag akzeptieren |
| POST | `/audit` | [AUTH] | Audit-Log |
| GET | `/history` | [AUTH] | Vertrags-Historie |

**admin:**

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/` | [AUTH] | Alle Vertraege |
| POST | `/` | [AUTH] | Vertrag erstellen |
| PUT | `/:id/activate` | [AUTH] | Vertrag aktivieren |
| GET | `/:id/acceptances` | [AUTH] | Akzeptierungen |
| POST | `/acceptances:id/revoke` | [AUTH] | Akzeptierung widerrufen |
| GET | `/audit-log` | [AUTH] | Audit-Log |
| GET | `/status` | [AUTH] | Vertrags-Status |

### subcontractor.routes.ts
**Base-Path:** `/api/subcontractors`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/` | [AUTH] | Subunternehmer auflisten |
| POST | `/assign` | [AUTH] | Installation zuweisen |
| POST | `/bulk-assign` | [AUTH] | Bulk-Zuweisung |
| GET | `/:id/installations` | [AUTH] | Installationen eines Subs |
| PATCH | `/toggle-emails/:installationId` | [AUTH] | Email-Benachrichtigungen umschalten |

---

## 18. Portal (Endkunden)

### portal.routes.ts
**Base-Path:** `/api/portal`

**Endkunden-Bereich (Auth):**

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/installations` | [AUTH] | Eigene Installationen |
| GET | `/installation:id` | [AUTH] | Installations-Details |
| GET | `/installation:id/timeline` | [AUTH] | Zeitstrahl |
| GET | `/installation:id/documents` | [AUTH] | Dokumente |
| GET | `/installation:id/email/:emailId` | [AUTH] | Email-Detail |
| GET | `/onboarding/status` | [AUTH] | Onboarding-Status |
| POST | `/onboarding/consent` | [AUTH] | Consent geben |
| POST | `/onboarding/complete` | [AUTH] | Onboarding abschliessen |
| GET | `/installation:id/messages` | [AUTH] | Chat-Nachrichten |
| POST | `/installation:id/messages` | [AUTH] | Nachricht senden |
| GET | `/whatsapp/status` | [AUTH] | WhatsApp-Status |
| POST | `/whatsapp/request` | [AUTH] | WhatsApp anfordern |
| GET | `/settings` | [AUTH] | Einstellungen |
| POST | `/settings/password` | [AUTH] | Passwort aendern |
| POST | `/settings/whatsapp/remove` | [AUTH] | WhatsApp entfernen |
| GET | `/alerts` | [AUTH] | Alerts |
| GET | `/installation:id/alerts` | [AUTH] | Installation-Alerts |
| GET | `/notifications` | [AUTH] | Benachrichtigungen |
| GET | `/notifications/count` | [AUTH] | Ungelesene Anzahl |
| POST | `/notifications/read` | [AUTH] | Als gelesen markieren |
| POST | `/installation:id/kundenfreigabe/done` | [AUTH] | Kundenfreigabe abschliessen |

**Admin-Bereich:**

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | `/admin/installations:id/activate` | [AUTH] | Portal-Zugang aktivieren |
| POST | `/admin/installations:id/resend-welcome` | [AUTH] | Welcome-Mail erneut senden |
| GET | `/admin/installations:id/status` | [AUTH] | Portal-Status |
| POST | `/admin/installations:id/kundenfreigabe` | [AUTH] | Kundenfreigabe erstellen |
| POST | `/admin/installations:id/kundenfreigabe/erledigt` | [AUTH] | KF als erledigt markieren |
| POST | `/admin/alerts:alertId/notify-customer` | [AUTH] | Kunden benachrichtigen |
| POST | `/admin/alerts:alertId/resolve` | [AUTH] | Alert loesen |
| GET | `/admin/installations:id/alerts` | [AUTH] | Admin: Installation-Alerts |
| GET | `/admin/installations:id/chat` | [AUTH] | Admin: Chat anzeigen |
| POST | `/admin/installations:id/chat` | [AUTH] | Admin: Chat-Nachricht senden |
| GET | `/admin/installations:id/chat/info` | [AUTH] | Admin: Chat-Info |
| POST | `/admin:id/dokument-anforderung` | [AUTH] | Dokument anfordern |
| POST | `/admin:id/erinnerung` | [AUTH] | Erinnerung senden |
| POST | `/admin:id/whatsapp-welcome` | [AUTH] | WhatsApp-Welcome senden |
| GET | `/admin/users` | [AUTH] | Portal-User auflisten |
| POST | `/admin/users:userId/impersonate` | [AUTH] | Als User agieren |

---

## 19. Kalender & Termine

### calendar.routes.ts
**Base-Path:** `/api/calendar`

**Authentifiziert:**

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/appointments` | [AUTH] | Termine auflisten |
| GET | `/appointments/:id` | [AUTH] | Termin-Details |
| POST | `/appointments` | [AUTH] | Termin erstellen |
| PUT | `/appointments/:id` | [AUTH] | Termin aktualisieren |
| DELETE | `/appointments/:id` | [AUTH][MA] | Termin loeschen |
| GET | `/availability` | [AUTH] | Verfuegbarkeit |
| POST | `/availability` | [AUTH] | Verfuegbarkeit setzen |
| PUT | `/availability/:id` | [AUTH] | Verfuegbarkeit aktualisieren |
| DELETE | `/availability/:id` | [AUTH] | Verfuegbarkeit loeschen |
| GET | `/blocked-dates` | [AUTH] | Geblockte Tage |
| POST | `/blocked-dates` | [AUTH] | Tag blocken |
| DELETE | `/blocked-dates/:id` | [AUTH] | Block aufheben |
| GET | `/services` | [AUTH] | Dienstleistungen |
| POST | `/services` | [AUTH][ADMIN] | Dienstleistung erstellen |
| PUT | `/services/:id` | [AUTH][ADMIN] | Dienstleistung aktualisieren |
| DELETE | `/services/:id` | [AUTH][ADMIN] | Dienstleistung loeschen |
| GET | `/slots` | [AUTH] | Verfuegbare Slots |
| GET | `/settings` | [AUTH] | Kalender-Einstellungen |
| PUT | `/settings` | [AUTH][ADMIN] | Einstellungen aendern |

**Oeffentlich:**

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/public/services` | [PUBLIC] | Oeffentliche Dienstleistungen |
| GET | `/public/user/:id` | [PUBLIC] | Oeffentliches User-Profil |
| GET | `/public/slots` | [PUBLIC] | Oeffentliche Slots |
| POST | `/public/book` | [PUBLIC] | Oeffentliche Buchung |
| GET | `/public/team` | [PUBLIC] | Team-Uebersicht |

---

## 20. WhatsApp

### whatsapp.routes.ts
**Base-Path:** `/api/whatsapp`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/conversations` | [AUTH] | Konversationen |
| GET | `/conversations:id` | [AUTH] | Konversations-Details |
| POST | `/conversations:id/message` | [AUTH] | Nachricht senden |
| GET | `/installation:installationId/messages` | [AUTH] | Nachrichten einer Installation |
| POST | `/installation:installationId/message` | [AUTH] | Nachricht an Installation |
| GET | `/stats` | [AUTH] | WhatsApp-Statistiken |
| POST | `/test` | [AUTH] | Test-Nachricht |
| GET | `/me` | [AUTH] | Eigene WhatsApp-Config |
| DELETE | `/me` | [AUTH] | Eigene Config loeschen |
| DELETE | `/me:phoneNumber` | [AUTH] | Telefonnummer entfernen |
| POST | `/activate` | [AUTH] | WhatsApp aktivieren |
| GET | `/betreiber/templates` | [AUTH] | Betreiber-Templates |
| GET | `/betreiber:installationId/messages` | [AUTH] | Betreiber-Nachrichten |
| POST | `/betreiber:installationId/messages` | [AUTH] | Betreiber-Nachricht senden |
| POST | `/betreiber:installationId/messages/template` | [AUTH] | Template-Nachricht senden |
| GET | `/learning/stats` | [AUTH] | Learning-Stats |
| GET | `/learning/corrections:step` | [AUTH] | Korrekturen |
| GET | `/learning/learnings:step` | [AUTH] | Learnings |
| GET | `/learning/suggestions:productType` | [AUTH] | Vorschlaege |

---

## 21. Admin & System

### admin-center.routes.ts
**Base-Path:** `/api/admin`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/logs` | [AUTH][ADMIN] | Admin-Logs |
| GET | `/logs/stats` | [AUTH][ADMIN] | Log-Statistiken |
| GET | `/bugs` | [AUTH][STAFF] | Bug-Reports |
| POST | `/bugs` | [AUTH] | Bug melden |
| PATCH | `/bugs/:id` | [AUTH][STAFF] | Bug aktualisieren |
| GET | `/bugs/stats` | [AUTH][ADMIN] | Bug-Statistiken |
| GET | `/announcements` | [AUTH][ADMIN] | Ankuendigungen |
| GET | `/unread` | [AUTH] | Ungelesene Ankuendigungen |
| POST | `/announcements` | [AUTH][ADMIN] | Ankuendigung erstellen |
| PATCH | `/announcements/:id` | [AUTH][ADMIN] | Ankuendigung bearbeiten |
| DELETE | `/announcements/:id` | [AUTH][ADMIN] | Ankuendigung loeschen |
| POST | `/:id/read` | [AUTH] | Als gelesen markieren |
| POST | `/read-all` | [AUTH] | Alle als gelesen |
| GET | `/dashboard` | [AUTH][ADMIN] | Admin-Dashboard |

### controlCenter.routes.ts
**Base-Path:** `/api/control-center`
**Middleware:** `router.use(authenticateSession)`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/overview` | [SESSION] | System-Uebersicht |
| GET | `/quick-stats` | [SESSION] | Schnell-Statistiken |
| GET | `/health` | [SESSION] | System-Health |
| GET | `/crons` | [SESSION] | Cron-Jobs |
| POST | `/cache/clear` | [SESSION] | Cache leeren |

### settings.routes.ts
**Base-Path:** `/api/settings`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/company` | [AUTH] | Firmendaten |
| PUT | `/company` | [AUTH] | Firmendaten aendern |
| POST | `/generate-api-key` | [AUTH] | API-Key generieren |
| DELETE | `/revoke-api-key` | [AUTH] | API-Key widerrufen |
| POST | `/test-email` | [AUTH] | Test-Email senden |
| GET | `/integrations` | [AUTH] | Integrationen |
| POST | `/integrations/:provider/connect` | [AUTH] | Integration verbinden |
| POST | `/integrations/:provider/disconnect` | [AUTH] | Integration trennen |
| GET | `/audit-log` | [AUTH] | Audit-Log |

### featureFlags.routes.ts
**Base-Path:** `/api/admin/feature-flags`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/` | [AUTH][ADMIN] | Alle Feature-Flags |
| PUT | `/:name` | [AUTH][ADMIN] | Flag setzen |
| GET | `/check/:name` | [AUTH] | Flag pruefen |

### health.routes.ts
**Base-Path:** `/api/health`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/detailed` | [AUTH][ADMIN] | Detaillierter Health-Check |
| GET | `/cache-stats` | [AUTH][ADMIN] | Cache-Statistiken |

### logs.routes.ts
**Base-Path:** `/api/logs`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/` | [AUTH] | Logs auflisten |
| POST | `/` | [AUTH] | Log erstellen |
| DELETE | `/clear` | [AUTH] | Logs loeschen |

### credentials.routes.ts
**Base-Path:** `/api/credentials`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/` | [AUTH] | Credentials auflisten |
| POST | `/` | [AUTH] | Credential erstellen |
| PATCH | `/:id` | [AUTH] | Credential aktualisieren |
| DELETE | `/:id` | [AUTH] | Credential loeschen |

### backup.routes.ts
**Base-Path:** `/api/backup`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/list` | [AUTH] | Backups auflisten |
| POST | `/run` | [AUTH] | Backup starten |
| GET | `/status` | [AUTH] | Backup-Status |

### tracking.routes.ts
**Base-Path:** `/api/tracking`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | `/session/start` | [AUTH] | Tracking-Session starten |
| POST | `/session/heartbeat` | [AUTH] | Session-Heartbeat |
| POST | `/session/end` | [AUTH] | Session beenden |
| POST | `/session/associate` | [AUTH] | Session mit User verknuepfen |
| POST | `/event` | [AUTH] | Tracking-Event |
| POST | `/batch` | [AUTH] | Batch-Events |
| POST | `/page-view` | [AUTH] | Page-View |
| POST | `/click` | [AUTH] | Klick-Event |
| POST | `/search` | [AUTH] | Such-Event |
| GET | `/stats` | [AUTH] | Tracking-Statistiken |
| POST | `/flush` | [AUTH] | Buffer leeren |

### alert.routes.ts
**Base-Path:** `/api/alerts`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/` | [AUTH] | Alerts auflisten |
| GET | `/stats` | [AUTH] | Alert-Statistiken |
| GET | `/installation:id` | [AUTH] | Installation-Alerts |
| POST | `/:id/read` | [AUTH] | Alert als gelesen markieren |
| POST | `/:id/resolve` | [AUTH] | Alert loesen |
| POST | `/check-overdue` | [AUTH] | Ueberfaellige pruefen |

### rules.routes.ts
**Base-Path:** `/api/rules`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| *(CRUD)* | | [AUTH] | Automations-Regeln |

---

## 22. Sonstiges

### plz.routes.ts
**Base-Path:** `/api/plz`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/:plz` | [PUBLIC] | PLZ-Lookup (OpenPLZ API) |
| GET | `/search/:query` | [PUBLIC] | PLZ-Suche |

### solar.routes.ts
**Base-Path:** `/api/solar`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | `/berechnung` | [PUBLIC] | Solar-Wirtschaftlichkeitsberechnung |
| GET | `/pvgis` | [PUBLIC] | PVGIS-Daten abrufen |
| GET | `/strompreis` | [PUBLIC] | Aktueller Strompreis |

### mastr.routes.ts
**Base-Path:** `/api/mastr`
**Middleware:** `router.use(authenticate)`, `router.use(requireAdmin)`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/test` | [AUTH][ADMIN] | MaStR-API-Test |
| GET | `/einheit/solar/:mastrNr` | [AUTH][ADMIN] | Solar-Einheit abfragen |
| GET | `/einheit/speicher/:mastrNr` | [AUTH][ADMIN] | Speicher-Einheit abfragen |
| GET | `/meine-einheiten` | [AUTH][ADMIN] | Eigene Einheiten |
| GET | `/stromerzeuger` | [AUTH][ADMIN] | Stromerzeuger suchen |
| GET | `/kontingent` | [AUTH][ADMIN] | API-Kontingent |
| GET | `/status` | [AUTH][ADMIN] | MaStR-Status |
| POST | `/installations/:publicId/match` | [AUTH][ADMIN] | Installation mit MaStR matchen |
| POST | `/installations/:publicId/speicher` | [AUTH][ADMIN] | Speicher-Match |
| POST | `/sync` | [AUTH][ADMIN] | MaStR-Sync starten |
| GET | `/sync/status` | [AUTH][ADMIN] | Sync-Status |
| GET | `/sync/history` | [AUTH][ADMIN] | Sync-Historie |
| POST | `/projekte/:projektId/link` | [AUTH][ADMIN] | Projekt mit MaStR verknuepfen |
| DELETE | `/projekte/:projektId/link` | [AUTH][ADMIN] | Verknuepfung loesen |
| GET | `/projekte/:projektId/details` | [AUTH][ADMIN] | MaStR-Details |

### unsubscribe.routes.ts
**Base-Path:** `/api/unsubscribe`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/:token` | [PUBLIC] | Unsubscribe-Seite |
| POST | `/:token` | [PUBLIC] | Abmeldung bestaetigen |

### dsgvo.routes.ts
**Base-Path:** `/api/dsgvo`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/tracking-status` | [AUTH] | Tracking-Status |
| POST | `/opt-out` | [AUTH] | Tracking deaktivieren |
| POST | `/opt-in` | [AUTH] | Tracking aktivieren |
| GET | `/data-export` | [AUTH] | DSGVO-Datenexport |
| POST | `/data-deletion` | [AUTH] | DSGVO-Datenlöschung |

### report.routes.ts
**Base-Path:** `/api/reports`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/data-sources` | [AUTH] | Datenquellen |
| POST | `/preview` | [AUTH] | Report-Vorschau |
| POST | `/export` | [AUTH] | Report exportieren |

### import.routes.ts
**Base-Path:** `/api/import`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | `/preview` | [AUTH] | Import-Vorschau |
| POST | `/execute` | [AUTH] | Import ausfuehren |
| GET | `/template` | [AUTH] | Import-Template herunterladen |

### archiv.routes.ts
**Base-Path:** `/api/archiv`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/` | [AUTH] | Archiv-Eintraege |
| GET | `/:id` | [AUTH] | Archiv-Detail |

### evuLearning.routes.ts
**Base-Path:** `/api/evu`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/dashboard` | [AUTH] | EVU-Dashboard |
| POST | `/analyze-all` | [AUTH] | Alle EVU analysieren |
| POST | `/recalculate-all` | [AUTH] | Alle neu berechnen |
| POST | `/merge-goi` | [AUTH] | GOI zusammenfuehren |
| POST | `/learn` | [AUTH] | Learning ausfuehren |
| GET | `/:evuId/profile` | [AUTH] | EVU-Profil |
| GET | `/:evuId/warnings` | [AUTH] | EVU-Warnungen |
| GET | `/:evuId/tips` | [AUTH] | EVU-Tipps |
| POST | `/analyze:evuId` | [AUTH] | Einzelne EVU analysieren |
| GET | `/:evuId/logs` | [AUTH] | EVU-Logs |

### learning.routes.ts
**Base-Path:** `/api/learning`
**Middleware:** `router.use(authenticate, requireAdmin)`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| *(Endpoints)* | | [AUTH][ADMIN] | Self-Learning System |

### vdeFormular.routes.ts
**Base-Path:** `/api/vde`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/:installationId/data` | [AUTH] | VDE-Formulardaten |
| GET | `/:installationId/sets` | [AUTH] | Formular-Sets |
| POST | `/:installationId/create` | [AUTH] | Formular-Set erstellen |
| PUT | `/sets/:id` | [AUTH] | Set aktualisieren |
| POST | `/sets/:id/sign` | [AUTH] | Set signieren |
| POST | `/sets/:id/generate` | [AUTH] | PDFs generieren |
| GET | `/sets/:id/preview/:formType` | [AUTH] | Formular-Vorschau |
| POST | `/sets/:id/send` | [AUTH] | Formulare senden |

### vde_generator.routes.ts
**Base-Path:** `/api/vde-generator`

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | `/extract` | [AUTH] | Datenblatt-Extraktion |
| POST | `/generate/:installationId` | [AUTH] | VDE-Dokumente generieren |
| POST | `/send-email/:installationId` | [AUTH] | VDE per Email senden |

### formularLink.routes.ts
**Base-Path:** `/api/formulare`

**Oeffentlich:**

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| GET | `/public:slug` | [PUBLIC] | Formular anzeigen |
| POST | `/public:slug/submit` | [PUBLIC] | Formular einreichen |
| GET | `/public:slug/pdf` | [PUBLIC] | Formular-PDF |

**Authentifiziert:**

| Methode | Pfad | Auth | Beschreibung |
|---------|------|------|-------------|
| POST | `/links` | [AUTH] | Formular-Link erstellen |
| GET | `/links` | [AUTH] | Links auflisten |
| PATCH | `/links:id` | [AUTH] | Link aktualisieren |
| DELETE | `/links:id` | [AUTH] | Link loeschen |
| GET | `/submissions` | [AUTH] | Einreichungen |
| GET | `/submissions:id` | [AUTH] | Einreichungs-Details |
| POST | `/submissions:id/convert` | [AUTH] | In Installation umwandeln |
| POST | `/submissions:id/reject` | [AUTH] | Einreichung ablehnen |

---

## Sicherheitshinweise

### Routes ohne Auth (PUBLIC)
Die folgenden Endpunkte sind absichtlich oeffentlich:
- `/api/plz/*` - PLZ-Lookup (OpenPLZ)
- `/api/solar/*` - Solar-Rechner
- `/api/auth/login`, `/api/auth/forgot-password`, `/api/auth/reset-password` - Auth-Flow
- `/api/auth/verify-email/:token`, `/api/auth/verify-reset-token/:token` - Token-Validierung
- `/api/unsubscribe/:token` - Email-Abmeldung
- `/api/calendar/public/*` - Oeffentliche Terminbuchung
- `/api/formulare/public*` - Oeffentliche Formulare
- `/api/rechnungen/public:id/:token/pdf` - Rechnungs-PDF (Token-geschuetzt)
- `/api/payment-links/public/:token` - Zahlungsseite (Token-geschuetzt)
- `/api/wise/webhook/:accountId` - Wise-Webhook (Server-to-Server, Signatur-Validierung)
- `/api/public/confirm-termin:token` - Termin-Bestaetigung (Token-geschuetzt)

### Rate-Limiting
- **Global:** `/api/` - `globalLimiter`
- **Auth:** `/api/auth`, `/api/login` - `authLimiter`
- **Upload:** `/api/uploads`, `/api/documents`, `/api/import` - `uploadLimiter`
- **AI:** `/api/ai`, `/api/feature-builder`, `/api/claude-code`, `/api/rag`, `/api/claude-ai`, `/api/ai-assistant`, `/api/accounting/ai` - `aiLimiter`

---

## Statistik

| Metrik | Wert |
|--------|------|
| Route-Dateien | 96 |
| Registrierte Base-Paths | ~80 |
| Geschaetzte Gesamt-Endpoints | ~600+ |
| Oeffentliche Endpoints | ~20 |
| Admin-Only Endpoints | ~80 |
| AI-Rate-Limited Endpoints | ~25 |
