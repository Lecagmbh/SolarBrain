# GridNetz Portal - Prisma Schema Map

> Generiert am 2026-03-11 | ~120 Models | ~35 Enums | MySQL

---

## 1. Zusammenfassung

Das GridNetz-Datenbankschema umfasst ca. 120 Prisma-Models und 35 Enums auf einer MySQL-Datenbank. Es bildet ein Portal fuer Netzanmeldungen (Photovoltaik, Speicher, Wallbox, Waermepumpe) ab, inklusive Kundenverwaltung, Rechnungsstellung, Handelsvertreter-Provisionen, Email-Automatisierung, KI-Klassifikation, Factro-Integration, Buchhaltung, Kalender, WhatsApp-Bot und mehr.

**Zentrale Entitaeten:**
- **Installation** (~240 Zeilen, 15+ Indizes) — Herzsueck des Systems, verbindet Kunde, Netzbetreiber, Dokumente, Emails, Tasks, Status, Workflow
- **User** — Benutzer mit 7 Rollen, JWT-Auth, Sessions, 2FA
- **Kunde** — Firmenkunden mit Whitelabel, Service-Preisen, Handelsvertreter-Zuordnung
- **Netzbetreiber** — Energieversorger mit EVU-Learning, Credentials, VNBdigital-Anbindung
- **FactroProject** — Projektmanagement-Sync mit Factro, eigene Email-Adresse, Kommentar-Sync

**Technologie-Stack:**
- Prisma ORM mit MySQL
- pgvector (PostgreSQL) separat fuer RAG/Embeddings
- TypeScript strict mode

---

## 2. Enums

### 2.1 Benutzer & Auth

#### UserRole
```
ADMIN | MITARBEITER | HANDELSVERTRETER | KUNDE | SUBUNTERNEHMER | DEMO | ENDKUNDE_PORTAL
```

### 2.2 Anlagen & Installationen

#### AnlageStatus
```
AKTIV | INAKTIV | IN_PLANUNG | STILLGELEGT
```

#### InstallationStatus
```
EINGANG | BEIM_NB | RUECKFRAGE | GENEHMIGT | IBN | FERTIG | STORNIERT
```

### 2.3 Dokumente

#### DocumentKategorie
```
ANTRAG | LAGEPLAN | SCHALTPLAN | DATENBLATT | RECHNUNG | VERTRAG | KORRESPONDENZ | FOTOS_AC | FOTOS_DC | SONSTIGE
```

#### DocumentStatus
```
UPLOADED | VERIFIED | REJECTED | ARCHIVED
```

#### DokumentKategorie (fuer ProjektDokument)
```
ANGEBOT | AUFTRAGSBESTAETIGUNG | RECHNUNG_DOK | LIEFERSCHEIN | ABNAHMEPROTOKOLL |
INBETRIEBNAHMEPROTOKOLL | NETZANMELDUNG | SCHALTPLAN | LAGEPLAN | DATENBLATT |
FOTOS | KORRESPONDENZ | VERTRAG | GUTACHTEN | STATIK | GENEHMIGUNG |
ZERTIFIKAT | WARTUNGSPROTOKOLL | MAENGELPROTOKOLL | DOKUMENTATION | SONSTIGES
```

#### DocumentTypeCategory
```
(Enum fuer DocumentType.category)
```

### 2.4 Emails

#### EmailDirection
```
INBOUND | OUTBOUND
```

#### EmailTemplateCategory
```
SYSTEM | STATUS_UPDATE | INVOICE | REMINDER | DOCUMENT | WELCOME | MARKETING | CUSTOM
```

#### EmailEventType
```
INSTALLATION_CREATED | INSTALLATION_SUBMITTED | INSTALLATION_APPROVED | INSTALLATION_REJECTED |
INSTALLATION_IBN | INSTALLATION_COMPLETED | INSTALLATION_CANCELLED | DOCUMENT_UPLOADED |
DOCUMENT_VERIFIED | DOCUMENT_REJECTED | INVOICE_CREATED | INVOICE_SENT | INVOICE_PAID |
INVOICE_OVERDUE
```

#### EmailRecipientType
```
CUSTOMER | ADMIN | CUSTOM | CREATOR
```

#### EmailQueueStatus
```
PENDING | SCHEDULED | PROCESSING | SENT | FAILED | CANCELLED
```

#### EmailLogStatus
```
SENT | DELIVERED | OPENED | CLICKED | BOUNCED | COMPLAINED | FAILED
```

#### SentEmailStatus
```
(Status-Enum fuer SentEmail)
```

### 2.5 Rechnungen & Finanzen

#### RechnungStatus
```
ENTWURF | OFFEN | VERSENDET | BEZAHLT | UEBERFAELLIG | STORNIERT | MAHNUNG | ZUSAMMENGEFASST
```

#### ProvisionsStatus
```
OFFEN | FREIGEGEBEN | AUSGEZAHLT | STORNIERT
```

#### AuszahlungsStatus
```
AUSSTEHEND | AUSGEZAHLT | FEHLGESCHLAGEN
```

#### ZahlungStatus
```
(8 Werte fuer ProjektZahlung)
```

#### AccountType
```
(Enum fuer Buchhaltungs-Konten)
```

#### ExpenseStatus
```
(Enum fuer Expenses)
```

#### PaymentLinkStatus
```
(Enum fuer PaymentLink)
```

### 2.6 Tasks & Aufgaben

#### TaskStatus
```
OPEN | IN_PROGRESS | COMPLETED | CANCELLED
```

#### TaskPriority
```
LOW | NORMAL | HIGH | URGENT
```

#### AufgabenStatus
```
OFFEN | IN_BEARBEITUNG | WARTET | ERLEDIGT | STORNIERT
```

#### AufgabenPrioritaet
```
NIEDRIG | NORMAL | HOCH | DRINGEND
```

### 2.7 Projekte

#### ProjektStatus
```
ANFRAGE | ANGEBOT | BEAUFTRAGT | IN_PLANUNG | MATERIAL_BESTELLT | MONTAGE_GEPLANT |
MONTAGE_LAEUFT | MONTAGE_ABGESCHLOSSEN | ELEKTRO_GEPLANT | ELEKTRO_ABGESCHLOSSEN |
NETZANMELDUNG | BEIM_NB | GENEHMIGT | IBN | ABGESCHLOSSEN | PAUSIERT
```

#### ProjektTyp
```
PV_ANLAGE | SPEICHER | WALLBOX | WAERMEPUMPE | PV_SPEICHER | PV_SPEICHER_WALLBOX |
KOMPLETTSYSTEM | ERWEITERUNG | WARTUNG | REPARATUR
```

### 2.8 Netzbetreiber

#### NbPortalTyp
```
STROMNETZ_BERLIN | ENBW | AVACON | BAYERNWERK | WESTNETZ | GENERIC
```

#### NbSubmissionStatus
```
(Enum fuer NbPortalSubmission)
```

### 2.9 Produkte

#### ProduktTyp
```
PV_MODUL | WECHSELRICHTER | SPEICHER | WALLBOX | WAERMEPUMPE
```

#### ProductType
```
MODULE | INVERTER | BATTERY | WALLBOX | HEATPUMP | SMARTMETER | OTHER
```

#### ProductSource
```
MANUAL | WEB_SEARCH | IMPORT | ZEREZ
```

#### ZerezCategory
```
(11 Werte fuer ZEREZ-Komponenten)
```

### 2.10 Timeline & Tracking

#### TimelineTyp
```
(10 Werte fuer ProjektTimeline)
```

#### TrackingEventType
```
(Enum fuer TrackingEvent)
```

### 2.11 WhatsApp

#### WhatsAppConversationState
```
(State-Machine fuer WhatsApp-Bot)
```

#### WhatsAppMessageDirection
```
(INBOUND | OUTBOUND fuer WhatsApp)
```

### 2.12 System & Admin

#### ActivityCategory
```
(Enum fuer ActivityLog)
```

#### LogLevel
```
(Enum fuer AgentLog)
```

#### BugCategory / BugSeverity / BugStatus
```
(Enums fuer BugReport)
```

#### Announcement-Enums
```
(type, priority fuer Announcements)
```

### 2.13 Alerts & Insights

#### AlertType / AlertCategory / AlertSourceType
```
(Enums fuer InstallationAlert)
```

#### InsightType / InsightSeverity
```
(Enums fuer Insight)
```

### 2.14 Agent System

#### AgentTaskType / AgentTaskStatus
```
(Enums fuer AgentTask)
```

### 2.15 Sonstige

#### AppointmentStatus
```
(Enum fuer CalendarAppointment)
```

#### HvContractAuditAction
```
(Enum fuer HV-Vertragsaudit)
```

---

## 3. Models nach Bereich

### 3.1 Benutzer & Auth

#### User `@@map("users")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | Primary Key |
| email | String @unique | Login-Email |
| passwordHash | String | Gehashtes Passwort |
| name | String | Anzeigename |
| role | UserRole | Benutzerrolle |
| active | Boolean | Account aktiv |
| gesperrt | Boolean | Account gesperrt |
| pushToken | String? | Push-Notification Token |
| kundeId | Int? → Kunde | FK zum Kunden |
| parentUserId | Int? → User | Self-Ref fuer Sub-User |
| tokenVersion | Int | JWT-Invalidierung |
| twoFactor* | ... | 2FA-Felder |
| whatsapp* | ... | WhatsApp-Felder |
| emailVerified | Boolean | Email verifiziert |

**Relationen (ausgehend):** Kunde, parentUser (self)
**Relationen (eingehend):** RefreshToken[], PasswordResetToken[], EmailVerificationToken[], UserSession[], UserSetting[], Installation[] (created/assigned), Comment[], Task[] (assigned/created), StatusHistory[], Document[], Rechnung[], Handelsvertreter, AgentTask[], CalendarAppointment[], WhatsAppUserLink[], PortalUserInstallation[], CalendarAvailability[], CalendarBlockedDate[], BugReport[] (reported/assigned), Announcement[], EmailAction[], EmailClassification[] (reviewed), SavedView[], PortalNotification[], InstallerContext

#### WhatsAppUserLink `@@map("whatsapp_user_links")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| userId | Int → User | FK |
| phoneNumber | String @unique | Telefonnummer |

#### RefreshToken `@@map("refresh_tokens")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| token | String @unique | Token-Wert |
| userId | Int → User | FK |
| expiresAt | DateTime | Ablaufzeitpunkt |

#### PasswordResetToken `@@map("password_reset_tokens")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| token | String @unique | Reset-Token |
| userId | Int → User | FK |

#### EmailVerificationToken `@@map("email_verification_tokens")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| token | String @unique | Verifikations-Token |
| userId | Int → User | FK |

#### UserSession `@@map("user_sessions")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| sessionToken | String @unique | Session-Token |
| userId | Int → User | FK |
| csrfToken | String | CSRF-Schutz |
| deviceInfo | String? | Geraeteinfo |
| rememberMe | Boolean | Angemeldet bleiben |
| isValid | Boolean | Session gueltig |
| expiresAt | DateTime | Ablauf |

#### LoginAttempt `@@map("login_attempts")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| ipAddress | String | IP-Adresse |
| email | String | Versuchte Email |
| success | Boolean | Erfolgreich? |
| failReason | String? | Fehlergrund |

#### UserSetting `@@map("user_settings")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| userId | Int → User | FK |
| category | String | Einstellungs-Kategorie |
| key | String | Schluessel |
| value | Json | Wert |

**Constraint:** `@@unique([userId, category, key])`

---

### 3.2 Kunden

#### Kunde `@@map("kunden")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| name | String | Kundenname |
| kundenNummer | String @unique | Eindeutige Kundennummer |
| email | String? | Kontakt-Email |
| telefon | String? | Telefon |
| strasse | String? | Strasse |
| plz | String? | PLZ |
| ort | String? | Ort |
| firmenName | String? | Firmenname |
| whiteLabelConfig | Json? | Whitelabel-Konfiguration |
| aktiv | Boolean | Kunde aktiv |
| handelsvertreterId | Int? → Handelsvertreter | FK zum HV |
| accountGesperrt | Boolean | Account gesperrt |

**Relationen (eingehend):** User[], Anlage[], Installation[], Projekt[], Rechnung[], Provision[], KundeServicePrice[], CalendarAppointment[], Mahnung[], FactroConfig[], FormularLink[]

#### KundeServicePrice `@@map("kunde_service_prices")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| kundeId | Int → Kunde | FK |
| serviceKey | String | Service-Schluessel |
| priceNet | Decimal | Nettopreis |
| vatRate | Decimal | MwSt-Satz |

**Constraint:** `@@unique([kundeId, serviceKey])`

---

### 3.3 Anlagen & Technik

#### Anlage `@@map("anlagen")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| kundeId | Int → Kunde | FK |
| netzbetreiberId | Int? → Netzbetreiber | FK |
| leistungKwp | Decimal? | Gesamtleistung kWp |
| status | AnlageStatus | Anlagenstatus |

**Relationen (eingehend):** TechnikModul[], TechnikWechselrichter[], TechnikSpeicher[], TechnikWallbox[], TechnikWaermepumpe[], Document[], Rechnung[], Installation[]

#### TechnikModul `@@map("technik_module")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| anlageId | Int → Anlage | FK |
| hersteller | String | Hersteller (String, keine Relation!) |
| modell | String | Modellbezeichnung |
| leistungWp | Int? | Leistung in Wp |
| anzahl | Int | Stueckzahl |

#### TechnikWechselrichter `@@map("technik_wechselrichter")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| anlageId | Int → Anlage | FK |
| hersteller | String | Hersteller (String!) |
| modell | String | Modellbezeichnung |
| leistungKw | Decimal? | Leistung in kW |
| hybrid | Boolean | Hybrid-WR? |

#### TechnikSpeicher `@@map("technik_speicher")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| anlageId | Int → Anlage | FK |
| hersteller | String | Hersteller (String!) |
| modell | String | Modellbezeichnung |
| kapazitaetKwh | Decimal? | Kapazitaet in kWh |

#### TechnikWallbox `@@map("technik_wallboxen")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| anlageId | Int → Anlage | FK |
| hersteller | String | Hersteller (String!) |
| modell | String | Modellbezeichnung |
| leistungKw | Decimal? | Ladeleistung in kW |

#### TechnikWaermepumpe `@@map("technik_waermepumpen")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| anlageId | Int → Anlage | FK |
| hersteller | String | Hersteller (String!) |
| modell | String | Modellbezeichnung |
| steuerbar14a | Boolean? | 14a-steuerbar |

---

### 3.4 Netzbetreiber

#### Netzbetreiber `@@map("netzbetreiber")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| name | String | NB-Name |
| bdewCode | String? @unique | BDEW-Code |
| vnbDigitalId | String? @unique | VNBdigital-ID |
| email | String? | Kontakt-Email |
| portalUrl | String? | Portal-URL |
| portalUsername | String? | Portal-User |
| portalPassword | String? | Portal-Passwort |
| plzBereiche | Json? | PLZ-Bereiche (kein strasse/plz/ort!) |
| tonalitaet | String? | EVU-Tonalitaet |
| kontakte | Json? | Kontaktpersonen |
| (EVU-Learning-Felder) | ... | Diverse Lernfelder |

**Relationen (eingehend):** Anlage[], Installation[], Projekt[], NetzbetreiberCredential[], GridOperatorIntelligence, IncomingEmail[], AutomationRule[], NbCorrespondence[], NbPortalConfig, NbDomainMapping[], EvuProfile, EvuLearningLog[], NbFewShotExample[], NbTabDocument[], NbComplaintPattern[]

#### NetzbetreiberCredential `@@map("netzbetreiber_credentials")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| netzbetreiberId | Int → Netzbetreiber | FK |
| username | String | Benutzername |
| passwordEnc | String | Verschluesseltes Passwort |
| label | String? | Bezeichnung |

**Constraint:** `@@unique([netzbetreiberId, label])`

---

### 3.5 Installations / Netzanmeldungen

#### Installation `@@map("installations")`

Das zentrale Model des Systems (~240 Zeilen im Schema, 15+ Indizes).

| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| publicId | String @unique | Oeffentliche ID |
| dedicatedEmail | String? | Dedizierte Email-Adresse |
| caseType | String? | Falltyp |
| kundeId | Int → Kunde | FK zum Kunden |
| netzbetreiberId | Int? → Netzbetreiber | FK zum NB |
| status | InstallationStatus | Aktueller Status |
| technicalData | Json? | Technische Daten (enthaelt totalPvKwPeak!) |
| wizardContext | LongText? | Wizard-Kontext |
| createdById | Int? → User | Ersteller |
| assignedToId | Int? → User | Zugewiesener Bearbeiter |
| zaehlerwechsel* | ... | Zaehlerwechsel-Felder |
| nb* | ... | NB-bezogene Felder |
| ibn* | ... | IBN-bezogene Felder |
| rechnung* | ... | Rechnungs-Felder |
| phase | String? | Workflow V2 Phase |
| zustand | String? | Workflow V2 Zustand |
| reminderActive | Boolean? | Erinnerung aktiv |

**Wichtig:** Kein `gesamt_kwp` Feld! kWp steckt in `technicalData` JSON als `totalPvKwPeak`.

**Relationen (eingehend):** Document[], Comment[], Task[], StatusHistory[], Email[], SentEmail[], IncomingEmail[], Projekt (1:1 unique), InstallationEvent[], InboxItem[], Deadline[], VdeFormularSet[], OpsReminderLog[], NbResponseTask[], FormularSubmission[], FactroProject (1:1 unique), InstallationMessage[], PortalUserInstallation[], EndkundenConsent (1:1 unique), PortalNotification[], CalendarAppointment[], InstallationAlert[], AutomationExecution[], VorgangsnummerMapping[], EvuLearningLog[], DocumentEmailBatch[], NbCorrespondence[], RueckfrageResponse[], EmailEscalation[], OpsAuditLog[]

---

### 3.6 Workflow V2

#### InstallationEvent `@@map("installation_events")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| installationId | Int → Installation | FK |
| type | String | Event-Typ |
| payload | Json? | Event-Daten |

#### InboxItem `@@map("inbox_items")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| installationId | Int? → Installation | FK |
| type | String | Item-Typ |
| title | String | Titel |
| priority | String? | Prioritaet |
| actions | Json? | Moegliche Aktionen |
| resolvedAt | DateTime? | Erledigt am |
| assignedToId | Int? | Zugewiesen an |
| category | String? | Kategorie |
| dueDate | DateTime? | Faellig am |
| visibility | String? | Sichtbarkeit |
| isRead | Boolean | Gelesen |
| deadline | DateTime? | Frist |

#### Deadline `@@map("deadlines")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| installationId | Int → Installation | FK |
| type | String | Deadline-Typ |
| dueDate | DateTime | Faelligkeitsdatum |
| warnDays | Int | Tage vorher warnen |
| isTriggered | Boolean | Bereits ausgeloest |

---

### 3.7 VDE Formulare

#### VdeFormularSet `@@map("vde_formular_sets")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| installationId | Int → Installation | FK |
| formulare | Json | Formular-Daten |
| signaturInstallateur | LongText? | Signatur (Base64) |
| status | String? | Status |

---

### 3.8 Dokumente

#### Document `@@map("documents")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| installationId | Int? → Installation | FK |
| anlageId | Int? → Anlage | FK |
| kategorie | DocumentKategorie | Dokumenttyp |
| dateiname | String | Dateiname |
| speicherpfad | String | Speicherpfad |
| status | DocumentStatus | Dokumentstatus |
| autoDetectedType | String? | KI-erkannter Typ |
| factroDocumentId | String? @unique | Factro-Dokument-ID |
| factroProjectId | Int? → FactroProject | FK |
| uploadedById | Int? → User | Hochgeladen von |

---

### 3.9 Emails

#### Email `@@map("emails")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| externalId | String @unique | Externe ID |
| installationId | Int? → Installation | FK |
| subject | String? | Betreff |
| fromAddress | String | Absender |
| bodyHtml | LongText? | HTML-Body |
| bodyText | LongText? | Text-Body |
| direction | EmailDirection | Richtung |
| messageId | String? | Message-ID Header |
| threadId | String? | Thread-ID |
| aiAnalysis | Json? | KI-Analyse |
| factroProjectId | Int? → FactroProject | FK |

**Relationen (eingehend):** EmailAction[], EmailClassification[]

#### EmailEscalation `@@map("email_escalations")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| installationId | Int? → Installation | FK |
| factroProjectId | Int? → FactroProject | FK |
| type | String | Eskalationstyp |
| status | String | Status |
| scheduledFor | DateTime? | Geplant fuer |

#### EmailAction `@@map("email_actions")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| emailId | Int → Email | FK |
| action | String | Aktion |
| userId | Int? → User | Ausgefuehrt von |

#### SentEmail `@@map("sent_emails")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| installationId | Int → Installation | FK |
| toAddress | String | Empfaenger |
| subject | String | Betreff |
| body | String | Inhalt |
| status | SentEmailStatus | Status |

---

### 3.10 Kommentare & Status

#### Comment `@@map("comments")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| installationId | Int → Installation | FK |
| authorId | Int → User | Autor |
| message | String | Nachricht |
| isInternal | Boolean | Intern? |

**Wichtig:** Kein `entity_type` Feld, nur `installation_id` und `is_internal`.

#### StatusHistory `@@map("status_history")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| installationId | Int → Installation | FK |
| fromStatus | String | Vorheriger Status |
| toStatus | String | Neuer Status |
| changedById | Int? → User | Geaendert von |
| createdAt | DateTime | Zeitstempel |

**Wichtig:** Tabellenname `status_history` (NICHT `status_histories`), Spalten `from_status`/`to_status`.

---

### 3.11 Rechnungen

#### Rechnung `@@map("rechnungen")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| rechnungsNummer | String @unique | Format: RE-YYYYMM-XXXXXX (base36, Offset 17000) |
| kundeId | Int → Kunde | FK |
| anlageId | Int? → Anlage | FK |
| betragNetto | Decimal | Nettobetrag |
| betragMwst | Decimal | MwSt-Betrag |
| betragBrutto | Decimal | Bruttobetrag |
| status | RechnungStatus | Rechnungsstatus |
| faelligAm | DateTime? | Faelligkeitsdatum |
| mahnStufe | Int | Aktuelle Mahnstufe |
| pdfPath | String? | PDF-Pfad |

**Relationen (eingehend):** Provision (1:1 unique), Mahnung[], WiseTransaction (1:1 unique), JournalEntry[], PaymentLink[]

---

### 3.12 Handelsvertreter & Provisionen

#### Handelsvertreter `@@map("handelsvertreter")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| userId | Int → User @unique | FK (1:1) |
| provisionssatz | Decimal? | Provisionssatz % |
| iban | String? | Bankverbindung |
| bic | String? | BIC |
| wiseRecipientId | String? | Wise Empfaenger-ID |

**Relationen (eingehend):** Kunde[], Provision[], ProvisionsAuszahlung[], HvContractAcceptance[]

#### Provision `@@map("provisionen")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| handelsvertreterId | Int → Handelsvertreter | FK |
| rechnungId | Int → Rechnung @unique | FK (1:1) |
| kundeId | Int → Kunde | FK |
| provisionsBetrag | Decimal | Provisionsbetrag |
| status | ProvisionsStatus | Status |
| auszahlungId | Int? → ProvisionsAuszahlung | FK |

#### ProvisionsAuszahlung `@@map("provisions_auszahlungen")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| handelsvertreterId | Int → Handelsvertreter | FK |
| auszahlungsNummer | String @unique | Auszahlungsnummer |
| gesamtBetrag | Decimal | Gesamtbetrag |
| status | AuszahlungsStatus | Status |
| wiseTransferId | String? | Wise-Transfer-ID |

**Relationen (eingehend):** Provision[]

#### ProvisionsCounter `@@map("provisions_counters")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| key | String @id (VarChar(6)) | PK (z.B. "202603") |
| next | Int | Naechste Nummer |

---

### 3.13 NB Portal

#### NbPortalConfig `@@map("nb_portal_configs")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| netzbetreiberId | Int → Netzbetreiber @unique | FK (1:1) |
| portalTyp | NbPortalTyp | Portal-Typ |
| autoPolling | Boolean | Auto-Polling aktiv |
| autoSubmit | Boolean | Auto-Submit aktiv |

#### NbPortalSubmission `@@map("nb_portal_submissions")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| kundeId | Int | Kunde (kein FK-Constraint) |
| installationId | Int? | Installation (kein FK-Constraint) |
| portalId | String | Portal-Identifier |
| formData | Json | Formulardaten |
| status | NbSubmissionStatus | Status |

---

### 3.14 Company & System Settings

#### CompanySettings `@@map("company_settings")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id (immer 1) | Singleton |
| (Firma) | ... | ~20 Firmenfelder |
| (Kontakt) | ... | Kontaktdaten |
| (Bank) | ... | Bankverbindung |
| (Branding) | ... | Logo, Farben |
| (Email-Config) | ... | SMTP, IMAP |
| (Rechnungen) | ... | Rechnungseinstellungen |
| (Integrationen) | ... | API-Keys |
| (Sicherheit) | ... | Sicherheitsconfig |
| (Features) | ... | Feature-Toggles |

**Gesamt ca. 120 Felder.**

---

### 3.15 Audit & Logging

#### AuditLog `@@map("audit_logs")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| userId | Int? | User-ID |
| action | String | Aktion |
| entity | String? | Betroffene Entitaet |
| details | Json? | Details |
| ipAddress | String? | IP-Adresse |
| severity | String? | Schweregrad |

#### ActivityLog `@@map("activity_logs")`
**UNUSED** — Duplikat von AuditLog.

---

### 3.16 Email Command Center

#### EmailTemplate `@@map("email_templates")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| slug | String @unique | Eindeutiger Slug |
| name | String | Template-Name |
| subject | String | Betreff-Template |
| bodyMjml | LongText | MJML-Body |
| category | EmailTemplateCategory | Kategorie |

**Relationen (eingehend):** EmailTrigger[], EmailQueueItem[], EmailLog[]

#### EmailTrigger `@@map("email_triggers")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| eventType | EmailEventType | Ausloese-Event |
| templateId | Int → EmailTemplate | FK |
| conditions | Json? | Bedingungen |
| recipientType | EmailRecipientType | Empfaengertyp |

#### EmailQueueItem `@@map("email_queue")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| templateId | Int? → EmailTemplate | FK |
| recipientEmail | String | Empfaenger |
| subject | String | Betreff |
| bodyHtml | LongText | HTML-Body |
| status | EmailQueueStatus | Queue-Status |
| priority | Int | Prioritaet |

#### EmailLog `@@map("email_logs")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| templateId | Int? → EmailTemplate | FK |
| recipientEmail | String | Empfaenger |
| subject | String | Betreff |
| status | EmailLogStatus | Status |
| factroProjectId | Int? → FactroProject | FK |

#### EmailUnsubscribe `@@map("email_unsubscribes")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| email | String | Email-Adresse |
| token | String @unique | Abmelde-Token |

---

### 3.17 Tasks

#### Task `@@map("tasks")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| installationId | Int → Installation | FK |
| title | String | Titel |
| status | TaskStatus | OPEN, IN_PROGRESS, COMPLETED, CANCELLED |
| priority | TaskPriority | LOW, NORMAL, HIGH, URGENT |
| dueDate | DateTime? | Faelligkeitsdatum |
| assignedToId | Int? → User | Zugewiesen an |
| createdById | Int? → User | Erstellt von |

**Wichtig:** Status-Enum ist `OPEN/IN_PROGRESS/COMPLETED/CANCELLED` (NICHT DONE!).

---

### 3.18 Admin Center

#### BugReport `@@map("bug_reports")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| title | String | Titel |
| severity | BugSeverity | Schweregrad |
| status | BugStatus | Status |
| reportedById | Int → User | Gemeldet von |
| assignedToId | Int? → User | Zugewiesen an |

#### Announcement `@@map("announcements")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| title | String | Titel |
| type | String | Typ |
| priority | String | Prioritaet |
| createdById | Int → User | Erstellt von |

**Relationen (eingehend):** AnnouncementRead[]

#### AnnouncementRead `@@map("announcement_reads")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| announcementId | Int → Announcement | FK |
| userId | Int → User | FK |

**Constraint:** `@@unique([announcementId, userId])`

---

### 3.19 Produkt-Datenbank

#### Hersteller `@@map("hersteller")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| name | String @unique | Herstellername |
| verified | Boolean | Verifiziert |

**Relationen (eingehend):** Produkt[], PvModul[], Wechselrichter[], SpeicherSystem[], WallboxDb[], WaermepumpeDb[]

#### Produkt `@@map("produkte")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| herstellerId | Int → Hersteller | FK (Relation, kein String!) |
| modell | String | Modellbezeichnung |
| typ | ProduktTyp | Produkttyp |
| verified | Boolean | Verifiziert (KEIN `aktiv` Feld!) |

**Constraint:** `@@unique([herstellerId, modell])`

#### PvModul `@@map("pv_module_db")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| herstellerId | Int → Hersteller | FK |
| modell | String | Modellbezeichnung |
| leistungWp | Int? | Leistung in Wp |
| (ca. 30 weitere Felder) | ... | Technische Daten |

#### Wechselrichter `@@map("wechselrichter_db")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| herstellerId | Int → Hersteller | FK |
| modell | String | Modellbezeichnung |
| acLeistungW | Int? | AC-Leistung in W (NICHT max*!) |
| dcLeistungMaxW | Int? | Max DC-Leistung in W |
| mppTrackerAnzahl | Int? | Anzahl MPP-Tracker |
| wirkungsgradMaxProzent | Decimal? | Max Wirkungsgrad % |
| (ca. 36 weitere Felder) | ... | Technische Daten |

#### SpeicherSystem `@@map("speicher_db")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| herstellerId | Int → Hersteller | FK |
| modell | String | Modellbezeichnung |
| kapazitaetBruttoKwh | Decimal? | Brutto-Kapazitaet kWh |
| ladeleistungMaxKw | Decimal? | Max Ladeleistung kW |
| entladeleistungMaxKw | Decimal? | Max Entladeleistung kW |
| batterietyp | String? | Batterietyp (lowercase!) |
| zyklenBeiDod80 | Int? | Zyklen bei 80% DoD |
| verified | Boolean | Verifiziert (KEIN `aktiv` Feld!) |
| (ca. 32 weitere Felder) | ... | Technische Daten |

#### Batteriesystem `@@map("batteriesystem_db")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| name | String | Name (KEINE Hersteller-Relation!) |
| (ca. 60 Felder) | ... | PV*SOL Import-Daten |

**Standalone-Model, keine FK-Relationen zu/von anderen Models.**

#### WallboxDb `@@map("wallbox_db")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| herstellerId | Int → Hersteller | FK |
| modell | String | Modellbezeichnung |
| ladeleistungKw | Decimal? | Ladeleistung kW |
| (ca. 27 weitere Felder) | ... | Technische Daten |

#### WaermepumpeDb `@@map("waermepumpe_db")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| herstellerId | Int → Hersteller | FK |
| modell | String | Modellbezeichnung |
| heizleistungKw | Decimal? | Heizleistung kW |
| (ca. 27 weitere Felder) | ... | Technische Daten |

---

### 3.20 PV*SOL Legacy (UNUSED)

#### WechselrichterPvsol `@@map("wechselrichter_pvsol")`
**UNUSED** — Legacy PV*SOL Import.

#### SpeicherPvsol `@@map("speicher_pvsol")`
**UNUSED** — Legacy PV*SOL Import.

#### BatterieSystemRaw `@@map("batterie_system_raw")`
**UNUSED** — Legacy Rohdaten.

#### BatterieWrKombiPvsol `@@map("batterie_wr_kombi_pvsol")`
**UNUSED** — Kreuzreferenz WR <-> Speicher.

---

### 3.21 Projekt-Management

#### Projekt `@@map("projekte")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| projektNummer | String @unique | Projektnummer |
| status | ProjektStatus | Projektstatus (16 Werte) |
| typ | ProjektTyp | Projekttyp (10 Werte) |
| kundeId | Int? → Kunde | FK |
| netzbetreiberId | Int? → Netzbetreiber | FK |
| installationId | Int? → Installation @unique | FK (1:1) |
| (ca. 77 weitere Felder) | ... | Projektdetails |

**Relationen (eingehend):** ProjektKomponente[], ProjektDokument[], ProjektTimeline[], ProjektAufgabe[], ProjektZahlung[], ProjektTermin[]

#### ProjektKomponente `@@map("projekt_komponenten")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| projektId | Int → Projekt | FK |
| produktTyp | String | Produkttyp |
| hersteller | String | Hersteller |
| modell | String | Modell |
| anzahl | Int | Stueckzahl |
| (Preisfelder) | Decimal? | Einzel-/Gesamtpreis |

#### ProjektDokument `@@map("projekt_dokumente")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| projektId | Int → Projekt | FK |
| kategorie | DokumentKategorie | Kategorie (21 Werte) |
| dateiname | String | Dateiname |

#### ProjektTimeline `@@map("projekt_timeline")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| projektId | Int → Projekt | FK |
| typ | TimelineTyp | Timeline-Typ (10 Werte) |
| titel | String | Titel |

#### ProjektAufgabe `@@map("projekt_aufgaben")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| projektId | Int → Projekt | FK |
| status | AufgabenStatus | Status |
| prioritaet | AufgabenPrioritaet | Prioritaet |

#### ProjektZahlung `@@map("projekt_zahlungen")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| projektId | Int → Projekt | FK |
| typ | String | Zahlungstyp |
| betrag | Decimal | Betrag |
| status | String | Status |

#### ProjektTermin `@@map("projekt_termine")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| projektId | Int → Projekt | FK |
| typ | String | Termintyp |
| startzeit | DateTime | Startzeitpunkt |

---

### 3.22 Wizard Intelligence

#### WizardLearningSession `@@map("wizard_learning_sessions")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| sessionId | String @unique | Session-ID |
| plz | String? | PLZ |
| kategorie | String? | Kategorie |
| gesamtleistungKwp | Decimal? | Gesamtleistung kWp |

#### ProductPattern `@@map("product_patterns")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| patternHash | String @unique | Pattern-Hash |
| produkt1 | String? | Produkt 1 |
| produkt2 | String? | Produkt 2 |
| anzahlVerwendungen | Int | Verwendungshaeufigkeit |

#### UserPreference `@@map("user_preferences")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| userId | Int → User @unique | FK (1:1) |
| bevorzugteHersteller | Json? | Bevorzugte Hersteller |
| (WhatsApp-Bot-Felder) | ... | Bot-Praeferenzen |
| learnedPatterns | Json? | Gelernte Patterns |

#### SmartSuggestion `@@map("smart_suggestions")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| kontextHash | String | Kontext-Hash |
| kontextTyp | String | Kontext-Typ |
| vorschlagJson | Json | Vorschlag-Daten |

#### SuggestionFeedback `@@map("suggestion_feedback")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| suggestionId | Int | Suggestion-ID (kein FK!) |
| aktion | String | Feedback-Aktion |

---

### 3.23 Bank Integration

#### BankConnection `@@map("bank_connections")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| requisitionId | String @unique | Requisition-ID |
| institutionId | String | Bank-ID |
| accountId | String? | Konto-ID |
| status | String | Verbindungsstatus |

**Relationen (eingehend):** BankTransaction[]

#### BankTransaction `@@map("bank_transactions")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| externalId | String @unique | Externe ID |
| bankConnectionId | Int → BankConnection | FK |
| amount | Decimal | Betrag |
| matchedRechnungId | Int? | Gematchte Rechnung (kein FK?) |

---

### 3.24 Wise Integration

#### WiseAccount `@@map("wise_accounts")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| profileId | String | Wise Profile-ID |
| encryptedToken | String | Verschluesselter API-Token |
| iban | String @unique | IBAN |
| balance | Decimal? | Aktueller Saldo |

**Relationen (eingehend):** WiseTransaction[]

#### WiseTransaction `@@map("wise_transactions")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| referenceNumber | String @unique | Referenznummer |
| wiseAccountId | Int → WiseAccount | FK |
| amount | Decimal | Betrag |
| matchedRechnungId | Int? → Rechnung @unique | FK (1:1) |

**Relationen (eingehend):** JournalEntry[]

#### PaymentLink `@@map("payment_links")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| token | String @unique | Link-Token |
| rechnungId | Int → Rechnung | FK |
| amount | Decimal | Betrag |
| status | PaymentLinkStatus | Status |

---

### 3.25 Intelligence System

#### GridOperatorIntelligence `@@map("grid_operator_intelligence")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| netzbetreiberId | Int → Netzbetreiber @unique | FK (1:1) |

**@deprecated** — Wird nicht mehr aktiv genutzt.

#### IncomingEmail `@@map("incoming_emails")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| messageId | String @unique | Message-ID |
| fromEmail | String | Absender |
| matchedInstallationId | Int? → Installation | FK |
| matchedNetzbetreiberId | Int? → Netzbetreiber | FK |
| factroProjectId | Int? → FactroProject | FK |
| status | String | Verarbeitungsstatus |

**Relationen (eingehend):** IncomingEmailAttachment[]

#### IncomingEmailAttachment `@@map("incoming_email_attachments")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| incomingEmailId | Int → IncomingEmail | FK |
| filename | String | Dateiname |

#### VorgangsnummerMapping `@@map("vorgangsnummer_mappings")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| vorgangsnummer | String @unique | Vorgangsnummer |
| installationId | Int → Installation | FK |

#### AutomationRule `@@map("automation_rules")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| triggerType | String | Trigger-Typ |
| actionType | String | Aktionstyp |
| netzbetreiberId | Int? → Netzbetreiber | FK |

**Relationen (eingehend):** AutomationExecution[]

#### AutomationExecution `@@map("automation_executions")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| ruleId | Int → AutomationRule | FK |
| installationId | Int? → Installation | FK |
| status | String | Ausfuehrungsstatus |

#### LearningEvent `@@map("learning_events")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| eventType | String | Event-Typ |
| eventData | Json | Event-Daten |

---

### 3.26 Tracking & Analytics

#### TrackingEvent `@@map("tracking_events")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| eventType | String | Event-Typ |
| eventName | String | Event-Name |
| userId | Int? | User-ID |
| properties | Json? | Eigenschaften |

#### TrackingSession `@@map("tracking_sessions")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | String @id (VarChar) | PK |
| userId | Int? | User-ID |
| pageViews | Int | Seitenaufrufe |
| actionsCount | Int | Aktionen |

#### HourlyMetrics `@@map("hourly_metrics")`
**UNUSED**
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| timestamp | DateTime @unique | Zeitstempel |

#### DailyMetrics `@@map("daily_metrics")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| date | DateTime @unique | Datum |
| newInstallations | Int | Neue Installationen |
| emailsSent | Int | Gesendete Emails |
| (weitere Metriken) | ... | ... |

#### Insight `@@map("insights")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| insightType | InsightType | Insight-Typ |
| category | String? | Kategorie |
| title | String | Titel |
| severity | InsightSeverity | Schweregrad |

#### ApiCallLog `@@map("api_call_logs")`
**UNUSED**
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| method | String | HTTP-Methode |
| path | String | Pfad |
| responseTime | Int | Antwortzeit ms |

---

### 3.27 System

#### SystemHealth `@@map("system_health")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| recordedAt | DateTime | Zeitstempel |
| activeUsers24h | Int | Aktive User (24h) |
| pendingEmails | Int | Ausstehende Emails |
| (weitere Metriken) | ... | ... |

#### BackupRecord `@@map("backup_records")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| filename | String | Dateiname |
| filesize | BigInt | Dateigroesse |
| backupType | String | Backup-Typ |
| status | String | Status |
| checksum | String? | Pruefsumme |

#### InvoiceCounter `@@map("invoice_counters")`
**UNUSED** (Rechnungsnummern nutzen eigene Logik)
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| key | String @id (VarChar(6)) | PK (z.B. "202603") |
| next | Int | Naechste Nummer |

---

### 3.28 Zerez

#### ZerezComponent `@@map("zerez_components")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| zerezId | String @unique | ZEREZ-ID |
| modelName | String | Modellname |
| category | ZerezCategory | Kategorie (11 Werte) |
| manufacturerName | String | Hersteller |
| maxActivePowerKw | Decimal? | Max Wirkleistung kW |
| certifcate* | ... | Zertifikatsfelder |

**Constraint:** `@@fulltext`

---

### 3.29 Feature Flags

#### FeatureFlag `@@map("feature_flags")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| name | String @unique | Flag-Name |
| enabled | Boolean | Aktiviert |

---

### 3.30 NB Domain & Forms

#### NbDomainMapping `@@map("nb_domain_mappings")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| netzbetreiberId | Int → Netzbetreiber | FK |
| domain | String @unique | Email-Domain |

#### NbFormMapping `@@map("nb_form_mappings")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| netzbetreiber | String @unique | NB-Name |
| formFields | Json | Formularfelder |
| selectorMap | Json? | CSS-Selektoren |

---

### 3.31 Agent System

#### AgentTask `@@map("agent_tasks")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| type | AgentTaskType | Task-Typ |
| status | AgentTaskStatus | Status |
| userId | Int → User | FK |
| input | Json? | Eingabedaten |
| output | Json? | Ausgabedaten |
| progress | Int? | Fortschritt % |

**Relationen (eingehend):** AgentLog[]

#### AgentLog `@@map("agent_logs")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| taskId | Int → AgentTask | FK |
| level | String | Log-Level |
| message | String | Nachricht |

#### AgentTemplate `@@map("agent_templates")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| name | String | Template-Name |
| agentType | String | Agent-Typ |
| chainSteps | Json? | Chain-Steps |

#### AgentNotification `@@map("agent_notifications")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| taskId | Int | Task-ID (kein FK!) |
| userId | Int | User-ID |
| channel | String | Benachrichtigungskanal |
| read | Boolean | Gelesen |

#### AgentPrompt `@@map("agent_prompts")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| name | String | Prompt-Name |
| agentType | String | Agent-Typ |
| template | String | Template-Text |

**Constraint:** `@@unique([name, version])`

---

### 3.32 Brain System

#### BrainKnowledge `@@map("brain_knowledge")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| category | String | Kategorie |
| key | String | Schluessel |
| value | Json | Wert |
| confidence | Decimal? | Konfidenz (85-95%) |

**Constraint:** `@@unique([category, key])`

#### BrainPattern `@@map("brain_patterns")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| patternType | String | Pattern-Typ |
| conditions | Json | Bedingungen |
| actions | Json | Aktionen |

#### BrainRule `@@map("brain_rules")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| name | String | Regelname |
| ruleType | String | Regeltyp |
| trigger | Json | Trigger |
| action | Json | Aktion |

#### BrainFeedback `@@map("brain_feedback")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| actionType | String | Aktionstyp |
| rating | Int | Bewertung |
| userId | Int? | User-ID |

#### BrainEvent `@@map("brain_events")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| eventType | String | Event-Typ |
| category | String? | Kategorie |
| action | String? | Aktion |
| entityType | String? | Entitaetstyp |
| entityId | String? | Entitaets-ID |

---

### 3.33 Alert System

#### InstallationAlert `@@map("installation_alerts")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| installationId | Int → Installation | FK |
| type | AlertType | Alert-Typ |
| category | AlertCategory | Kategorie |
| isResolved | Boolean | Geloest |

---

### 3.34 Dokument-Typen

#### DocumentType `@@map("document_types")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| code | String @unique | Typ-Code |
| name | String | Name |
| category | DocumentTypeCategory | Kategorie |
| requiredForSubmission | Boolean | Pflicht fuer Einreichung |

---

### 3.35 Kalender

#### CalendarService `@@map("calendar_services")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| nameKey | String | Service-Name |
| durationMin | Int | Dauer in Minuten |
| isActive | Boolean | Aktiv |

**Relationen (eingehend):** CalendarAppointment[]

#### CalendarAvailability `@@map("calendar_availability")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| dayOfWeek | Int | Wochentag (0-6) |
| startTime | String | Startzeit |
| endTime | String | Endzeit |
| userId | Int? → User | FK |

#### CalendarBlockedDate `@@map("calendar_blocked_dates")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| date | DateTime | Blockiertes Datum |
| reason | String? | Grund |
| userId | Int? → User | FK |

#### CalendarAppointment `@@map("calendar_appointments")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| serviceId | Int → CalendarService | FK |
| installationId | Int? → Installation | FK |
| kundeId | Int? → Kunde | FK |
| scheduledAt | DateTime | Geplant fuer |
| status | AppointmentStatus | Status |
| assignedUserId | Int? → User | FK |
| confirmToken | String? @unique | Bestaetigungstoken |
| cancelToken | String? @unique | Stornierungstoken |

#### CalendarSetting `@@map("calendar_settings")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| key | String @unique | Einstellungsschluessel |
| value | String | Wert |

---

### 3.36 WhatsApp

#### WhatsAppConversation `@@map("whatsapp_conversations")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| waId | String @unique | WhatsApp-ID |
| phoneNumber | String | Telefonnummer |
| state | WhatsAppConversationState | Konversationsstatus |
| collectedData | Json? | Gesammelte Daten |

**Relationen (eingehend):** WhatsAppMessage[], WhatsAppMedia[]

#### WhatsAppMessage `@@map("whatsapp_messages")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| conversationId | Int → WhatsAppConversation | FK |
| messageId | String @unique | Message-ID |
| direction | WhatsAppMessageDirection | Richtung |
| content | String | Inhalt |

#### WhatsAppMedia `@@map("whatsapp_media")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| conversationId | Int → WhatsAppConversation | FK |
| filename | String | Dateiname |
| storagePath | String | Speicherpfad |
| category | String? | Kategorie |

---

### 3.37 Product (Smart Detection)

#### Product `@@map("products")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| uuid | String @unique | UUID |
| type | ProductType | Produkttyp |
| manufacturer | String | Hersteller |
| model | String | Modell |
| source | ProductSource | Datenquelle |

**Constraint:** `@@unique([manufacturer, model])`
**Standalone** — Existiert parallel zu Produkt/Hersteller, keine Relationen.

---

### 3.38 Betreiber-Chat

#### InstallationMessage `@@map("installation_messages")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| installationId | Int → Installation | FK |
| content | String | Nachrichteninhalt |
| direction | String | Richtung |
| senderType | String | Absendertyp |
| channelType | String | Kanaltyp |

#### MessageTemplate `@@map("message_templates")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| key | String @unique | Template-Key |
| template | String | Template-Text |
| triggerType | String | Trigger |

#### PendingRequest `@@map("pending_requests")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| phoneNumber | String | Telefonnummer |
| installationId | Int? | Installation-ID |
| requestType | String | Anfragetyp |
| status | String | Status |

#### PendingDocumentRequest `@@map("pending_document_requests")`
**Legacy/deprecated**

---

### 3.39 Installer Context

#### InstallerContext `@@map("installer_contexts")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| userId | Int @unique | User-ID (1:1) |
| phoneNumber | String? | Telefonnummer |
| contextType | String | Kontexttyp |
| pendingData | Json? | Ausstehende Daten |

---

### 3.40 WhatsApp Bot Learning

#### BotLearning `@@map("bot_learnings")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| inputPattern | String | Eingabemuster |
| wizardStep | String | Wizard-Schritt |
| fieldType | String | Feldtyp |
| extractedValue | String | Extrahierter Wert |
| confidence | Decimal | Konfidenz |

**Constraint:** `@@unique([inputNormalized, wizardStep, fieldType])`

#### ProductCombination `@@map("product_combinations")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| product1Type | String | Produkt 1 Typ |
| product1Manufacturer | String | Produkt 1 Hersteller |
| product1Model | String | Produkt 1 Modell |
| product2Type | String | Produkt 2 Typ |
| product2Manufacturer | String | Produkt 2 Hersteller |
| product2Model | String | Produkt 2 Modell |
| combinationCount | Int | Haeufigkeit |

#### BotCorrection `@@map("bot_corrections")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| wizardStep | String | Wizard-Schritt |
| fieldName | String | Feldname |
| wrongValue | String | Falscher Wert |
| correctedValue | String | Korrekter Wert |

#### BotUserPreference `@@map("bot_user_preferences")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| phoneNumber | String | Telefonnummer |
| preferenceType | String | Praeferenztyp |
| preferenceKey | String | Schluessel |
| preferenceValue | String | Wert |

---

### 3.41 Endkunden-Portal

#### PortalUserInstallation `@@map("portal_user_installations")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| userId | Int → User | FK |
| installationId | Int → Installation | FK |

**Constraint:** `@@unique([userId, installationId])`

#### EndkundenConsent `@@map("endkunden_consents")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| installationId | Int → Installation @unique | FK (1:1) |
| emailConsent | Boolean | Email-Einwilligung |
| whatsappConsent | Boolean | WhatsApp-Einwilligung |

#### PortalNotification `@@map("portal_notifications")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| userId | Int → User | FK |
| installationId | Int → Installation | FK |
| type | String | Benachrichtigungstyp |
| read | Boolean | Gelesen |

---

### 3.42 Mahnsystem

#### SystemSettings `@@map("system_settings")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id (immer 1) | Singleton |
| mahnwesenAktiv | Boolean | Mahnwesen aktiviert |
| emailVersandAktiv | Boolean | Email-Versand aktiv |
| tageBisMahnung | Int | Tage bis Mahnung |
| tageBisSperrung | Int | Tage bis Sperrung |

#### Mahnung `@@map("mahnungen")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| rechnungId | Int → Rechnung | FK |
| kundeId | Int → Kunde | FK |
| stufe | Int | Mahnstufe |
| offenerBetrag | Decimal | Offener Betrag |
| versandArt | String | Versandart |

#### MahnungConfig `@@map("mahnung_config")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| stufe | Int @unique | Mahnstufe |
| mahngebuehr | Decimal | Mahngebuehr |
| emailTemplate | String? | Email-Template |
| aktion | String? | Aktion |

---

### 3.43 Buchhaltung

#### Account `@@map("accounts")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| code | String @unique | Kontonummer |
| name | String | Kontoname |
| type | AccountType | Kontotyp |
| parentId | Int? → Account | Self-Ref (Kontenhierarchie) |

**Relationen (eingehend):** JournalEntryLine[], Account[] (children)

#### JournalEntry `@@map("journal_entries")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| date | DateTime | Buchungsdatum |
| rechnungId | Int? → Rechnung | FK |
| expenseId | Int? → Expense | FK |
| wiseTransactionId | Int? → WiseTransaction | FK |
| isPosted | Boolean | Gebucht |

**Relationen (eingehend):** JournalEntryLine[]

#### JournalEntryLine `@@map("journal_entry_lines")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| journalEntryId | Int → JournalEntry | FK |
| accountId | Int → Account | FK |
| debit | Decimal | Soll |
| credit | Decimal | Haben |

#### Expense `@@map("expenses")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| vendorId | Int? → Vendor | FK |
| description | String | Beschreibung |
| totalAmount | Decimal | Gesamtbetrag |
| status | ExpenseStatus | Status |
| relatedEntityId | Int? → LegalEntity | FK |

**Relationen (eingehend):** JournalEntry[]

#### Vendor `@@map("vendors")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| name | String | Lieferantenname |
| isIntercompany | Boolean | Konzernintern |

**Relationen (eingehend):** Expense[]

#### LegalEntity `@@map("legal_entities")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| name | String | Name |
| country | String | Land |
| currency | String | Waehrung |

**Relationen (eingehend):** Expense[]

#### ExchangeRate `@@map("exchange_rates")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| fromCurrency | String | Von Waehrung |
| toCurrency | String | Nach Waehrung |
| rate | Decimal | Kurs |
| date | DateTime | Datum |

**Constraint:** `@@unique([fromCurrency, toCurrency, date])`

#### FiscalYear `@@map("fiscal_years")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| year | Int @unique | Geschaeftsjahr |
| isClosed | Boolean | Abgeschlossen |

#### ExpenseCategory `@@map("expense_categories")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| name | String @unique | Kategoriename |
| accountCode | String? | Zugeordnetes Konto |

#### AccountingAnomaly `@@map("accounting_anomalies")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| type | String | Anomalie-Typ |
| severity | String | Schweregrad |
| expenseId | Int? | Expense-ID |
| isResolved | Boolean | Geloest |

---

### 3.44 EVU Learning

#### EvuProfile `@@map("evu_profiles")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| netzbetreiberId | Int → Netzbetreiber @unique | FK (1:1) |
| totalSubmissions | Int | Gesamteinreichungen |
| successRate | Decimal? | Erfolgsrate |
| avgProcessingDays | Decimal? | Durchschn. Bearbeitungstage |
| commonIssues | Json? | Haeufige Probleme |
| tips | Json? | Tipps |

#### EvuLearningLog `@@map("evu_learning_logs")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| netzbetreiberId | Int → Netzbetreiber | FK |
| installationId | Int? → Installation | FK |
| eventType | String | Event-Typ |
| category | String? | Kategorie |
| rawMessage | String? | Rohnachricht |

#### NbFewShotExample `@@map("nb_few_shot_examples")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| netzbetreiberId | Int → Netzbetreiber | FK |
| typ | String | Beispieltyp |
| eingehend | String | Eingehende Nachricht |
| antwort | String | Antwort |

---

### 3.45 NB Tab-Dokumente

#### NbTabDocument `@@map("nb_tab_documents")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| netzbetreiberId | Int → Netzbetreiber | FK |
| filename | String | Dateiname |
| summary | Json? | Zusammenfassung |

---

### 3.46 MaStR

#### MaStrSyncLog `@@map("mastr_sync_log")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| status | String | Sync-Status |
| matchedSolar | Int? | Gematchte Solar-Anlagen |
| matchedSpeicher | Int? | Gematchte Speicher |

---

### 3.47 Rueckfrage Auto-Antwort

#### RueckfrageResponse `@@map("rueckfrage_responses")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| installationId | Int → Installation | FK |
| status | String | Status |
| draftSubject | String? | Entwurf-Betreff |
| draftBody | String? | Entwurf-Text |

---

### 3.48 Ops Center

#### OpsReminderLog `@@map("ops_reminder_log")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| installationId | Int → Installation | FK |
| reminderNumber | Int | Erinnerungsnummer |
| emailSentTo | String | Gesendet an |

#### OpsAuditLog `@@map("ops_audit_log")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| installationId | Int? → Installation | FK |
| action | String | Aktion |
| fieldName | String? | Feldname |
| oldValue | String? | Alter Wert |
| newValue | String? | Neuer Wert |

---

### 3.49 Factro Integration

#### FactroConfig `@@map("factro_configs")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| apiKey | String | API-Key (Header: `api-key`, kein Bearer!) |
| projectId | String | Factro Projekt-ID |
| kundeId | Int? → Kunde | FK |

**Relationen (eingehend):** FactroSyncLog[], FactroProject[]

#### FactroProject `@@map("factro_projects")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| configId | Int → FactroConfig | FK |
| factroTaskId | String @unique | Factro Task-ID |
| title | String | Projekttitel |
| customerName | String? | Kundenname |
| plz | String? | PLZ |
| ort | String? | Ort |
| totalKwp | Decimal? | Gesamtleistung kWp |
| status | String? | Status |
| isSold | Boolean | Verkauft |
| dedicatedEmail | String? @unique | Dedizierte Email |
| installationId | Int? → Installation @unique | FK (1:1) |
| netzanfrageGestelltAm | DateTime? | NA gestellt am |
| netzanfrageVnbEmail | String? | VNB-Email fuer NA |

**Relationen (eingehend):** FactroSyncLog[], Document[], FactroComment[], FactroCommentAction[], EmailLog[], Email[], IncomingEmail[], EmailEscalation[]

#### FactroSyncLog `@@map("factro_sync_logs")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| configId | Int → FactroConfig | FK |
| action | String | Sync-Aktion |
| factroProjectId | Int? → FactroProject | FK |

#### FactroComment `@@map("factro_comments")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| factroCommentId | String @unique | Factro Comment-ID |
| factroProjectId | Int → FactroProject | FK |
| text | String | Kommentartext |

**Relationen (eingehend):** FactroCommentAction[]

#### FactroCommentAction `@@map("factro_comment_actions")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| factroCommentId | Int → FactroComment | FK |
| factroProjectId | Int → FactroProject | FK |
| actionType | String | Aktionstyp |
| assignedToId | Int? → User | FK |

---

### 3.50 Email Learning Center

#### EmailClassification `@@map("email_classifications")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| emailId | Int → Email | FK |
| llmCategory | String? | OpenAI-Kategorie (primary) |
| llmConfidence | Decimal? | OpenAI-Konfidenz |
| localCategory | String? | Ollama-Kategorie (parallel) |
| humanCategory | String? | Manuelle Kategorie |
| status | String | Status |
| reviewedBy | Int? → User | FK |

#### EmailRule `@@map("email_rules")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| category | String @unique | Kategorie |
| minConfidence | Decimal | Min. Konfidenz |
| autoStatusChange | String? | Auto-Statusaenderung |
| (Boolean-Flags) | ... | Diverse Flags |

#### EmailTrainingStat `@@map("email_training_stats")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| date | DateTime @unique | Datum |
| totalClassified | Int | Gesamt klassifiziert |
| accuracy | Decimal? | Genauigkeit |

#### NbResponseTask `@@map("nb_response_tasks")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| installationId | Int → Installation | FK |
| triggerEmailId | Int? | Ausloesende Email-ID |
| status | String | Task-Status |
| responseBody | String? | Antwort-Text |
| resolveStatus | String? | pending/partial/resolved/manual_needed |
| threadEmails | Json? | Email-Thread |
| classificationId | Int? | Klassifikations-ID |
| category | String? | Kategorie |
| extractedData | Json? | Extrahierte Daten |
| ibnCheckliste | Json? | IBN-Checkliste |

**Relationen (eingehend):** NbComplaint[], NbTaskComment[]

---

### 3.51 NB Task Comments

#### NbTaskComment `@@map("nb_task_comments")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| taskId | Int → NbResponseTask | FK |
| type | String | Typ |
| action | String? | Aktion |
| message | String | Nachricht |

---

### 3.52 Auto-Resolve System

#### NbComplaint `@@map("nb_complaints")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| taskId | Int → NbResponseTask | FK |
| type | String | MISSING_SIGNATURE, SCHALTPLAN_ERROR, WRONG_DATE, MISSING_DOCUMENT, FORM_INCOMPLETE, CLARIFICATION_NEEDED |
| resolved | Boolean | Geloest |

#### NbComplaintPattern `@@map("nb_complaint_patterns")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| netzbetreiberId | Int? → Netzbetreiber | FK |
| complaintType | String | Beschwerdetyp |
| pattern | String | Pattern |
| frequency | Int | Haeufigkeit |

**Constraint:** `@@unique([netzbetreiberId, complaintType, pattern])`

#### EfkSignature `@@map("efk_signatures")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| efkName | String | EFK-Name |
| signatureImage | Bytes | Signatur (PNG/JPEG) |
| isDefault | Boolean | Standard-Signatur |

#### EmailAttachment `@@map("email_attachments")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| emailId | Int? | Email-ID |
| installationId | Int? | Installation-ID |
| fileName | String | Dateiname |
| contentHash | String | SHA-256 Duplikaterkennung |

---

### 3.53 Externe Formulare

#### FormularLink `@@map("formular_links")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| kundeId | Int → Kunde | FK |
| slug | String @unique | URL-Slug |
| token | String @unique | Zugangstoken |

**Relationen (eingehend):** FormularSubmission[]

#### FormularSubmission `@@map("formular_submissions")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| formularLinkId | Int → FormularLink | FK |
| installationId | Int? → Installation | FK |
| data | Json | Formulardaten |
| status | String | Status |

---

### 3.54 HV-Vertragssystem

#### HvContractTemplate `@@map("hv_contract_templates")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| version | String @unique | Vertragsversion |
| pdfPath | String | PDF-Pfad |
| pdfHash | String | PDF-Hash |
| isActive | Boolean | Aktiv |

**Relationen (eingehend):** HvContractAcceptance[], HvContractAuditLog[]

#### HvContractAcceptance `@@map("hv_contract_acceptances")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| handelsvertreterId | Int → Handelsvertreter | FK |
| contractTemplateId | Int → HvContractTemplate | FK |
| acceptedAt | DateTime | Akzeptiert am |
| signatureData | String? | Signatur-Daten |
| revokedById | Int? → User | Widerrufen von |

#### HvContractAuditLog `@@map("hv_contract_audit_log")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| contractTemplateId | Int? → HvContractTemplate | FK |
| action | HvContractAuditAction | Aktion |

---

### 3.55 Document Email Batching

#### DocumentEmailBatch `@@map("document_email_batch")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| installationId | Int → Installation | FK |
| recipientEmail | String | Empfaenger |
| batchKey | String | Batch-Schluessel |

---

### 3.56 NB Korrespondenz

#### NbCorrespondence `@@map("nb_correspondences")`
| Feld | Typ | Beschreibung |
|------|-----|--------------|
| id | Int @id | PK |
| installationId | Int → Installation | FK |
| netzbetreiberId | Int? → Netzbetreiber | FK |
| type | String | Korrespondenztyp |
| sentTo | String | Gesendet an |

---

## 4. Abhaengigkeitsmatrix

### 4.1 Zentrale Hub-Models

Die folgenden Models haben die meisten eingehenden FK-Relationen:

| Model | Eingehende Relationen | Beschreibung |
|-------|----------------------|--------------|
| **Installation** | ~35+ | Absolutes Zentrum des Systems |
| **User** | ~20+ | Benutzer ueberall referenziert |
| **Kunde** | ~12 | Kunden in Rechnungen, Installationen, Projekten |
| **Netzbetreiber** | ~15 | NB in Installationen, EVU-Learning, Patterns |
| **FactroProject** | ~10 | Factro-Hub fuer Emails, Dokumente, Kommentare |
| **Hersteller** | 6 | Referenziert von allen Produkt-Tabellen |
| **Rechnung** | 5 | Provisionen, Mahnungen, Wise, Journal, PaymentLinks |
| **EmailTemplate** | 3 | Triggers, Queue, Logs |
| **Handelsvertreter** | 4 | Kunden, Provisionen, Auszahlungen, Vertraege |

### 4.2 Abhaengigkeitsketten

```
User
  ├── Handelsvertreter (1:1) → Kunden[], Provisionen[], Auszahlungen[], Vertraege[]
  ├── Installation[] (created/assigned)
  │     ├── Document[], Comment[], Task[], StatusHistory[]
  │     ├── Email[], SentEmail[], IncomingEmail[]
  │     ├── InstallationEvent[], InboxItem[], Deadline[]
  │     ├── InstallationAlert[], InstallationMessage[]
  │     ├── NbResponseTask[] → NbComplaint[], NbTaskComment[]
  │     ├── FactroProject (1:1) → FactroComment[] → FactroCommentAction[]
  │     ├── Projekt (1:1) → Komponenten[], Dokumente[], Timeline[], Aufgaben[], Zahlungen[], Termine[]
  │     ├── VdeFormularSet[], FormularSubmission[]
  │     ├── EndkundenConsent (1:1), PortalUserInstallation[]
  │     └── OpsReminderLog[], OpsAuditLog[], NbCorrespondence[]
  ├── UserSession[], RefreshToken[], UserSetting[]
  ├── AgentTask[] → AgentLog[]
  └── CalendarAppointment[]

Kunde
  ├── User[] (inkl. Subunternehmer via parentUserId)
  ├── Anlage[] → Technik*[], Document[], Rechnung[]
  ├── Installation[]
  ├── Rechnung[] → Provision (1:1), Mahnung[], JournalEntry[], PaymentLink[]
  ├── Provision[]
  ├── FactroConfig[] → FactroProject[] → ...
  ├── FormularLink[] → FormularSubmission[]
  └── KundeServicePrice[]

Netzbetreiber
  ├── Anlage[], Installation[], Projekt[]
  ├── NetzbetreiberCredential[]
  ├── NbPortalConfig (1:1)
  ├── EvuProfile (1:1), EvuLearningLog[], NbFewShotExample[]
  ├── NbDomainMapping[], NbTabDocument[]
  ├── NbComplaintPattern[]
  ├── AutomationRule[] → AutomationExecution[]
  ├── IncomingEmail[]
  └── GridOperatorIntelligence (deprecated, 1:1)

Hersteller
  ├── Produkt[] (herstellerId, NICHT String!)
  ├── PvModul[]
  ├── Wechselrichter[]
  ├── SpeicherSystem[]
  ├── WallboxDb[]
  └── WaermepumpeDb[]
```

### 4.3 1:1 Relationen (unique FK)

| Von | Nach | Feld |
|-----|------|------|
| Handelsvertreter | User | userId @unique |
| Provision | Rechnung | rechnungId @unique |
| WiseTransaction | Rechnung | matchedRechnungId @unique |
| Projekt | Installation | installationId @unique |
| FactroProject | Installation | installationId @unique |
| EndkundenConsent | Installation | installationId @unique |
| NbPortalConfig | Netzbetreiber | netzbetreiberId @unique |
| GridOperatorIntelligence | Netzbetreiber | netzbetreiberId @unique |
| EvuProfile | Netzbetreiber | netzbetreiberId @unique |
| UserPreference | User | userId @unique |
| InstallerContext | User | userId @unique |

---

## 5. Verwaiste Models

Die folgenden Models haben **keine eingehenden FK-Relationen** (kein anderes Model referenziert sie):

### Standalone Daten-Models
| Model | Tabelle | Bemerkung |
|-------|---------|-----------|
| Batteriesystem | batteriesystem_db | PV*SOL Import, kein Hersteller-FK |
| Product | products | Parallel zu Produkt/Hersteller |
| ZerezComponent | zerez_components | ZEREZ-Datenbank |

### Singletons & Config
| Model | Tabelle | Bemerkung |
|-------|---------|-----------|
| CompanySettings | company_settings | Singleton (id=1) |
| SystemSettings | system_settings | Singleton (id=1) |
| MahnungConfig | mahnung_config | Stufen-Config |
| CalendarSetting | calendar_settings | Kalender-Config |
| FeatureFlag | feature_flags | Feature-Toggles |

### Counter & Tracking
| Model | Tabelle | Bemerkung |
|-------|---------|-----------|
| ProvisionsCounter | provisions_counters | Nummern-Counter |
| InvoiceCounter | invoice_counters | UNUSED |
| TrackingEvent | tracking_events | Analytics |
| TrackingSession | tracking_sessions | Session-Tracking |
| DailyMetrics | daily_metrics | Tagesmetriken |

### UNUSED Models
| Model | Tabelle | Bemerkung |
|-------|---------|-----------|
| ActivityLog | activity_logs | Duplikat von AuditLog |
| HourlyMetrics | hourly_metrics | Nicht genutzt |
| ApiCallLog | api_call_logs | Nicht genutzt |
| BatterieSystemRaw | batterie_system_raw | Legacy |
| WechselrichterPvsol | wechselrichter_pvsol | Legacy |
| SpeicherPvsol | speicher_pvsol | Legacy |
| BatterieWrKombiPvsol | batterie_wr_kombi_pvsol | Legacy |
| PendingDocumentRequest | pending_document_requests | Deprecated |

### Intelligence & Learning (Standalone)
| Model | Tabelle |
|-------|---------|
| BrainKnowledge | brain_knowledge |
| BrainPattern | brain_patterns |
| BrainRule | brain_rules |
| BrainFeedback | brain_feedback |
| BrainEvent | brain_events |
| SmartSuggestion | smart_suggestions |
| SuggestionFeedback | suggestion_feedback |
| ProductPattern | product_patterns |
| ProductCombination | product_combinations |
| BotLearning | bot_learnings |
| BotCorrection | bot_corrections |
| BotUserPreference | bot_user_preferences |
| WizardLearningSession | wizard_learning_sessions |
| LearningEvent | learning_events |
| Insight | insights |

### Sonstige Standalone
| Model | Tabelle |
|-------|---------|
| LoginAttempt | login_attempts |
| AuditLog | audit_logs |
| SystemHealth | system_health |
| BackupRecord | backup_records |
| NbFormMapping | nb_form_mappings |
| NbDomainMapping | nb_domain_mappings |
| NbTabDocument | nb_tab_documents |
| NbCorrespondence | nb_correspondences |
| DocumentEmailBatch | document_email_batch |
| EmailUnsubscribe | email_unsubscribes |
| EmailTrainingStat | email_training_stats |
| MaStrSyncLog | mastr_sync_log |
| MessageTemplate | message_templates |
| DocumentType | document_types |
| ExchangeRate | exchange_rates |
| FiscalYear | fiscal_years |
| ExpenseCategory | expense_categories |
| AccountingAnomaly | accounting_anomalies |
| AgentTemplate | agent_templates |
| AgentNotification | agent_notifications |
| AgentPrompt | agent_prompts |

---

## 6. Statistiken

| Metrik | Wert |
|--------|------|
| **Models gesamt** | ~120 |
| **Enums gesamt** | ~35 |
| **Datenbank** | MySQL (via Prisma) |
| **UNUSED Models** | 7 (ActivityLog, HourlyMetrics, ApiCallLog, InvoiceCounter, WechselrichterPvsol, SpeicherPvsol, BatterieSystemRaw, BatterieWrKombiPvsol) |
| **Deprecated Models** | 1 (GridOperatorIntelligence) |
| **Singleton Models** | 2 (CompanySettings, SystemSettings) |
| **Verwaiste Models** | ~45 (keine eingehenden FK) |
| **1:1 Relationen** | 11 (via @unique FK) |
| **Groesstes Model** | Installation (~240 Zeilen, 15+ Indizes) |
| **Model mit meisten Relationen** | Installation (~35+ eingehende) |
| **Bereichsgruppen** | 56 Kategorien |
| **Separate Vector-DB** | pgvector auf PostgreSQL (gridnetz_vectors) |

### Bereichsverteilung

| Bereich | Anzahl Models |
|---------|---------------|
| Benutzer & Auth | 8 |
| Kunden | 2 |
| Anlagen & Technik | 6 |
| Netzbetreiber | 2 |
| Installations | 1 (aber riesig) |
| Workflow V2 | 3 |
| Dokumente | 1 |
| Emails | 4 |
| Kommentare & Status | 2 |
| Rechnungen | 1 |
| Handelsvertreter & Provisionen | 4 |
| NB Portal | 2 |
| Email Command Center | 5 |
| Tasks | 1 |
| Admin Center | 3 |
| Produkt-Datenbank | 8 |
| PV*SOL Legacy | 4 (UNUSED) |
| Projekt-Management | 7 |
| Wizard Intelligence | 5 |
| Bank & Wise Integration | 5 |
| Intelligence System | 7 |
| Tracking & Analytics | 6 |
| System | 3 |
| Agent System | 5 |
| Brain System | 5 |
| Kalender | 5 |
| WhatsApp | 3 |
| WhatsApp Bot Learning | 4 |
| Betreiber-Chat | 4 |
| Endkunden-Portal | 3 |
| Mahnsystem | 3 |
| Buchhaltung | 10 |
| EVU Learning | 3 |
| Factro | 5 |
| Email Learning | 4 |
| Auto-Resolve | 4 |
| Externe Formulare | 2 |
| HV-Vertragssystem | 3 |
| Sonstige | 6 |
