# GridNetz Portal - Umfassende Code-Review-Analyse

> Stand: 2026-03-11 | Reviewer: Claude Code (automatisiert)
> Backend: `/var/www/gridnetz-backend` (Node.js, Express, TypeScript, Prisma)
> Frontend: `/var/www/gridnetz-frontend` (React, TypeScript, Vite, Tailwind)

---

## Inhaltsverzeichnis

1. [Zusammenfassung](#1-zusammenfassung)
2. [Backend Services](#2-backend-services)
3. [Backend Routes](#3-backend-routes)
4. [Backend Middleware & Infrastruktur](#4-backend-middleware--infrastruktur)
5. [Frontend](#5-frontend)
6. [Querschnittsthemen](#6-querschnittsthemen)
7. [Kritische Findings (Top 10)](#7-kritische-findings-top-10)
8. [Empfehlungen](#8-empfehlungen)

---

## 1. Zusammenfassung

### Gesamtbewertung: 7.2 / 10

Das GridNetz Portal ist ein umfangreiches Produkt mit ~90 Service-Dateien, ~96 Route-Dateien und einem Feature-reichen React-Frontend. Die Codebasis zeigt solide Grundmuster (Logger, asyncHandler, Prisma), hat aber an mehreren Stellen Verbesserungspotenzial bei Typsicherheit, Duplikation und Error-Handling.

### Staerken
- Konsistentes Logger-Pattern (`createLogger`) durchgehend
- Gutes Error-Handling-Framework mit `asyncHandler` + `ApiError`
- Saubere Rollen-Hierarchie mit granularen Guards
- Token-Invalidation via `tokenVersion` (best practice)
- Idempotente Service-Funktionen (z.B. `createProvisionForInvoice`)
- Saubere Trennung Service/Route in den meisten Faellen

### Schwaechen
- 57+ Stellen mit `: any` im Services-Ordner, 115+ `as any`/`Record<string, any>` insgesamt
- 3x duplizierte `nextInvoiceNumber()`/`encodeInvoiceCode()` Funktionen
- 4 verschiedene API-Clients im Frontend
- Leere `catch {}` Bloecke (55+ Stellen)
- Mehrere `process.env` Zugriffe ohne Validierung
- Security-Audit nur Log-basiert, keine DB-Persistierung

---

## 2. Backend Services

### 2.1 factro.service.ts

**Pfad:** `/var/www/gridnetz-backend/src/services/factro.service.ts`
**Zeilen:** ~1500+ | **Qualitaet: 7/10**

**Positiv:**
- Klare Strukturierung in Sektionen (Status-Mapping, Polling, Sync)
- Gutes Logging mit strukturierten Metadaten
- Saubere Factro-API-Abstraktion mit konsistenter Fehlerbehandlung

**Probleme:**
- **Hardcoded UUIDs** (Zeile 21-28): `STATUS_TO_PACKAGE` enthaelt Factro-Package-IDs als Hardcoded-Strings. Bei Aenderung im Factro-System muss Code geaendert werden. Besser: DB-Konfiguration oder ENV-Variablen.
- **`any`-Types**: 5x `as any` und 2x `: any` gefunden (z.B. `Record<string, any>` bei PATCH-Daten)
- **Groesse**: Mit ~1500+ Zeilen zu gross fuer eine einzelne Datei. Sollte in Sub-Module aufgeteilt werden (factroSync, factroProjects, factroPolling).

**Performance:**
- `getFactroProjects()` laedt alle Projekte eines Kunden ohne Paginierung bei internen Queries — bei grossem Datenbestand problematisch.

---

### 2.2 email.service.ts

**Pfad:** `/var/www/gridnetz-backend/src/services/email.service.ts`
**Zeilen:** 382 | **Qualitaet: 9/10**

**Positiv:**
- Saubere Trennung zwischen `send()` (sofort) und `queue()` (verzoegert)
- Vollstaendiges Error-Handling mit Logging auch bei Fehlern
- Idempotenter Queue-Prozessor mit Retry-Logik und maxAttempts
- Unsubscribe-Check mit Auth-Slug-Ausnahmen
- Konsistentes Logging mit Dauer-Messung

**Probleme:**
- **processQueue Race Condition** (Zeile 234-240): Zwischen `findMany` und `update` zu `PROCESSING` koennte ein paralleler Worker dasselbe Item greifen. Empfehlung: Atomaren `UPDATE ... WHERE status IN ('PENDING', 'SCHEDULED') LIMIT 20` verwenden oder `FOR UPDATE SKIP LOCKED`.
- **Queue-Item templateId Fallback** (Zeile 181): `templateId: template?.id || 0` — ID 0 ist kein gueltiger FK und koennte Constraint-Fehler verursachen, falls die Relation mandatory ist.

---

### 2.3 netzanfrage.service.ts

**Pfad:** `/var/www/gridnetz-backend/src/services/netzanfrage.service.ts`
**Zeilen:** 1015 | **Qualitaet: 7/10**

**Positiv:**
- Gute Kategorisierung (batteriespeicher, dachflaeche, schwarmspeicher, etc.)
- Preview-Funktion vor Versand (canSend-Check)
- Race-Condition-Schutz bei `batchSend()` (Zeile 828-839)
- Rate-Limiting mit 500ms Pause zwischen Batch-Sends

**Probleme:**
- **Code-Duplikation**: `buildAdressKurz()` und `buildAdressFull()` (Zeile 449-468) sind IDENTISCH — gleicher Code, zwei Funktionen. Sollte eine sein.
- **Hardcoded FROM-Adresse** (Zeile 19): `FROM_ADDRESS = "netzanmeldung@lecagmbh.de"` — sollte per ENV konfigurierbar sein.
- **Hardcoded Signatur** (Zeile 471-479): Firmenadresse und Telefonnummer sind hardcoded. Bei Firmenwechsel muss Code geaendert werden.
- **`escapeHtml()`** (Zeile 498-504): Ist dupliziert — existiert auch in mehreren anderen Dateien.
- **Batch-Delay** (Zeile 867): `await new Promise((r) => setTimeout(r, 500))` — Magic Number ohne Konstante.

---

### 2.4 wise.service.ts

**Pfad:** `/var/www/gridnetz-backend/src/services/wise.service.ts`
**Zeilen:** 1247 | **Qualitaet: 8/10**

**Positiv:**
- Saubere Verschluesselung der API-Tokens (AES-256-CBC)
- SCA-Challenge-Handling fuer starke Authentifizierung
- Gutes Fallback-Pattern (Statement → Activities Endpoint)
- Vollstaendiges Matching mit Confidence-Levels

**Probleme:**
- **N+1 Query bei syncWiseAccount** (Zeile 413-449): Fuer jede Transaktion wird einzeln `findUnique` + `create` + `matchWiseTransaction` ausgefuehrt. Bei 50 Transaktionen sind das 150+ DB-Queries. Besser: Batch-Insert + Batch-Match.
- **Hardcoded SEPA-IBAN** (provision.service.ts Zeile 700): `<IBAN>DE00000000000000000000</IBAN>` — Platzhalter-IBAN im SEPA-Export. Muss von CompanySettings kommen.
- **matchWiseTransaction Fallback** (Zeile 551-568): Laedt ALLE offenen Rechnungen in den Speicher (`findMany` ohne `take`). Bei vielen offenen Rechnungen potenzielles Memory-Problem.
- **Import-Position** (Zeile 848-849): `import fs` und `import path` mitten in der Datei statt am Anfang — kein technisches Problem, aber unueblich.

---

### 2.5 provision.service.ts

**Pfad:** `/var/www/gridnetz-backend/src/services/provision.service.ts`
**Zeilen:** 1108 | **Qualitaet: 8/10**

**Positiv:**
- Gute Idempotenz-Checks
- Self-Provision Guard (Zeile 104-130) verhindert Eigenprovisionen
- FIFO-Verrechnungslogik korrekt implementiert
- Atomare Transaktionen fuer Auszahlungen

**Probleme:**
- **Self-Provision Guard Schwaeche** (Zeile 121-123): Namensvergleich als Identitaetspruefung ist fragil. Wenn ein HV seinen Namen aendert, greift der Guard nicht mehr. Besser: Explizites Flag `isSelfAccount` auf dem User.
- **Verrechnung ohne Lock** (Zeile 976-1107): `previewVerrechnung()` und `executeVerrechnung()` laufen nicht atomar. Zwischen Preview und Execute koennten sich die Daten aendern (neue Rechnung, neue Provision).
- **SEPA ohne Debtor-IBAN** (Zeile 700): `DE00000000000000000000` ist ein Platzhalter — bankseitig wuerde das abgelehnt.

---

### 2.6 emailPipeline.service.ts

**Pfad:** `/var/www/gridnetz-backend/src/services/emailPipeline.service.ts`
**Zeilen:** ~1400+ | **Qualitaet: 6/10**

**Probleme:**
- **Massivste `any`-Nutzung im Projekt**: 49x `as any` gefunden — fast jedes Objekt wird unsicher gecastet.
- **Komplexitaet**: Die Pipeline-Logik ist tief verschachtelt mit vielen bedingten Pfaden. Schwer testbar und wartbar.
- **Fire-and-Forget Patterns**: Mehrere Stellen wo Fehler geschluckt werden (`catch(() => {})`).

**Positiv:**
- Dual-LLM parallele Klassifikation (OpenAI + Ollama) ist architektonisch gut.
- `Promise.allSettled()` fuer fehlertolerante parallele Verarbeitung.

---

### 2.7 invoicePdf.service.ts

**Pfad:** `/var/www/gridnetz-backend/src/services/invoicePdf.service.ts`
**Zeilen:** 492 | **Qualitaet: 7/10**

**Positiv:**
- Premium PDF-Rendering mit Gradient-Header, Farb-Schema
- Sauber strukturiertes Layout mit Seitenumbruch-Handling
- SHA-256 Hash fuer Integritaetspruefung

**Probleme:**
- **Magic Numbers** (Zeile 143-146): `W = 595.28`, `H = 841.89`, `M = 50` — A4-Dimensionen sollten als benannte Konstanten definiert sein.
- **Hardcoded Farben** (Zeile 158-164): `PRIMARY = "#8b5cf6"` etc. sollten konfigurierbar sein (CompanySettings).
- **Synchroner Datei-Lese** (Zeile 483): `fs.readFileSync(fullPath)` — blockiert den Event-Loop. Fuer grosse PDFs problematisch.
- **Kein Cleanup**: Preview-PDFs (`invoices-preview/`) werden nie geloescht.

---

### 2.8 nbResponseOrchestrator.service.ts

**Pfad:** `/var/www/gridnetz-backend/src/services/nbResponseOrchestrator.service.ts`
**Zeilen:** ~400+ | **Qualitaet: 6/10**

**Probleme:**
- **`any`-Types**: 23x `as any` Casts — besonders bei `extractedData` und `requiredDocuments`. Hier sollten konkrete Interfaces definiert werden.
- **Zeile 83**: `extractedData: ctx.extractedData as unknown as any` — doppelter Cast zeigt fehlende Typdefinition.
- **Keine Validierung** der `extractedData`-Struktur vor Speicherung in DB (JSON-Spalte).

---

### 2.9 nbResolveEngine.service.ts

**Pfad:** `/var/www/gridnetz-backend/src/services/nbResolveEngine.service.ts`
**Zeilen:** ~300+ | **Qualitaet: 6/10**

**Probleme:**
- **`any`-Types**: 17x `: any` — hoechste Dichte nach emailPipeline.
- **`catch (err: any)`** (Zeile 79): Fehlertyp sollte `unknown` sein (TypeScript Best Practice seit 4.4).
- **Fehlende Validierung**: Complaint-Typen werden ohne Schema-Validierung verarbeitet.

---

### 2.10 autoInvoice.service.ts

**Pfad:** `/var/www/gridnetz-backend/src/services/autoInvoice.service.ts`
**Zeilen:** ~300+ | **Qualitaet: 7/10**

**Probleme:**
- **Code-Duplikation**: `nextInvoiceNumber()` und `encodeInvoiceCode()` sind 1:1 Kopien aus `rechnung.routes.ts`. Diese Funktionen existieren in 3 Dateien:
  1. `rechnung.routes.ts`
  2. `autoInvoice.service.ts`
  3. `installation.routes.ts` (fuer die dort generierte Rechnungsnummer)
  Sollte in ein gemeinsames Modul extrahiert werden (z.B. `lib/invoiceNumber.ts`).

---

### 2.11 securityAudit.service.ts

**Pfad:** `/var/www/gridnetz-backend/src/services/securityAudit.service.ts`
**Zeilen:** 39 | **Qualitaet: 5/10**

**Probleme:**
- **Nur Log-basiert**: Security-Events werden nur geloggt, nicht in der Datenbank persistiert. Bei einem Security-Incident muss man Log-Dateien durchsuchen.
- **Kein Alerting**: Keine Integration mit einem Alerting-System bei kritischen Events.
- **Begrenzte Event-Typen**: Nur 5 Event-Typen definiert. Fehlende Events: `BRUTE_FORCE_ATTEMPT`, `TOKEN_REPLAY`, `PRIVILEGE_ESCALATION`.
- **Keine Rate-Tracking**: Kein Counter fuer wiederholte Zugriffsverletzungen.

---

### 2.12 emailInbox.service.ts

**Pfad:** `/var/www/gridnetz-backend/src/services/emailInbox.service.ts`
**Qualitaet: 7/10**

**Positiv:**
- Multi-Mailbox-Unterstuetzung (inbox + netzanmeldung)
- Konfigurierbar ueber ENV-Variablen
- Integration mit Email-Pipeline und Brain-Event-Hooks

**Probleme:**
- **16x `process.env`-Zugriffe** direkt im Service — sollten einmal beim Start validiert und in einem Config-Objekt gebunden werden.
- Enge Kopplung zwischen IMAP-Polling, Email-Matching und KI-Analyse in einer Datei.

---

### 2.13 Weitere Services (Kurzauswertung)

| Service | Qualitaet | Hauptproblem |
|---|---|---|
| `claudeAI.service.ts` | 7/10 | 1x `as any`, sonst sauber |
| `mahnung.service.ts` | 7/10 | 2x TODO (Email-Versand nicht implementiert) |
| `pricing.service.ts` | 8/10 | Sauber, gute Preisberechnung |
| `workflow.service.ts` | 7/10 | 3x `process.env` ohne Validierung |
| `vnbdigital.service.ts` | 6/10 | 5x `: any`, 2x `as any` bei GraphQL-Responses |
| `openai.service.ts` | 7/10 | 10x leere `catch {}` Bloecke |
| `websocket.service.ts` | 8/10 | Sauber, gutes Connection-Management |
| `pvgis.service.ts` | 8/10 | Sauberer externer API-Client |
| `evuLearning.service.ts` | 7/10 | Gut strukturiert, leichte `any`-Nutzung |

---

## 3. Backend Routes

### 3.1 auth.routes.ts

**Pfad:** `/var/www/gridnetz-backend/src/routes/auth.routes.ts`
**Zeilen:** 736 | **Qualitaet: 8/10**

**Positiv:**
- Anti-User-Enumeration bei `forgot-password` (Zeile 411, 418)
- Token-Rotation bei Refresh (alter Token wird geloescht)
- Token-Version-Check bei Refresh
- Rate-Limiting fuer Verification-Emails
- 2FA-Support mit Backup-Codes

**Probleme:**
- **Route nach Export** (Zeile 717-735): `/push-token` Route wird NACH dem `export default router` definiert. Funktioniert in diesem Fall, aber ist ein Anti-Pattern und koennte zu Verwirrung fuehren.
- **In-Memory Rate-Limiting** (Zeile 539-540): `resendLimits` Map wachst unbegrenzt. Memory Leak bei vielen Usern. Kommentar sagt "fuer Production besser Redis" — ist aber Production-Code.
- **Password-Reset Token im Klartext** (Zeile 427): Token wird als Hex-String in DB gespeichert. Besser: Nur Hash speichern, Token per Email senden.
- **Kein Login-Rate-Limiting**: Es gibt keinen Schutz gegen Brute-Force-Angriffe auf den Login-Endpoint.

---

### 3.2 installation.routes.ts

**Pfad:** `/var/www/gridnetz-backend/src/routes/installation.routes.ts`
**Zeilen:** ~1200+ | **Qualitaet: 6/10**

**Probleme:**
- **Zu gross**: Route-Datei mit 1200+ Zeilen ist ein God-Object. Enthaelt Upload-Setup, Helper-Funktionen, technische Datenextraktion UND alle Routes. Sollte in mehrere Dateien aufgeteilt werden.
- **Business-Logik in Route**: Funktionen wie `extractTotalKwp()` (Zeile 167-200), `resolveKategorieFromDokumentTyp()` (Zeile 95-118) gehoeren in einen Service.
- **`safeJson()`-Helper** (Zeile 82-93): Unsicherer Cast mit `as T` ohne Runtime-Validierung.
- **Multer-Setup in Route** (Zeile 40-73): Upload-Konfiguration gehoert in ein eigenes Modul.

---

### 3.3 rechnung.routes.ts

**Pfad:** `/var/www/gridnetz-backend/src/routes/rechnung.routes.ts`
**Zeilen:** ~800+ | **Qualitaet: 7/10**

**Positiv:**
- HMAC-basierter Public-PDF-Zugang (ohne Auth)
- Gute Validierung (`ensureMandatory`)
- CompanySettings-Check vor Rechnungserstellung

**Probleme:**
- **PDF_TOKEN_SECRET Fallback** (Zeile 31): `process.env.JWT_SECRET || "gridnetz-pdf-fallback-secret"` — der Fallback ist ein schwaches Geheimnis. Wenn JWT_SECRET nicht gesetzt ist, sind alle PDF-URLs vorhersagbar.
- **Duplizierte `nextInvoiceNumber()`** (Zeile 70-94): Identisch zu autoInvoice.service.ts.
- **`ensureInvoicePdfAsDocument()`** (Zeile 128-197): 70 Zeilen Business-Logik in einer Route-Datei. Gehoert in einen Service.

---

### 3.4 factro.routes.ts

**Pfad:** `/var/www/gridnetz-backend/src/routes/factro.routes.ts`
**Zeilen:** ~600+ | **Qualitaet: 7/10**

**Positiv:**
- Klare Zugriffs-Kontrolle (hasFactroAccess, getKundeScope)
- Middleware-Chain mit `requireFactroAccess`

**Probleme:**
- **`Record<string, any>`** (Zeile 166): Bei PATCH werden Felder ohne Typ-Pruefung uebernommen. Obwohl `allowedFields` whitelisted, gibt es keine Wert-Validierung (z.B. ob `totalKwp` eine Zahl ist).
- **`next: Function`** (Zeile 53): Sollte `NextFunction` aus Express sein, nicht der generische `Function`-Type.

---

### 3.5 Weitere Routes (Kurzauswertung)

| Route-Datei | Qualitaet | Hauptproblem |
|---|---|---|
| `dashboard.routes.ts` | 7/10 | 5x "any", grosse Aggregations-Queries inline |
| `emails.routes.ts` | 7/10 | 13x "any", komplexe Filter-Logik |
| `produkte.routes.ts` | 6/10 | 40x "any" — hoechster Wert aller Route-Dateien |
| `portal.routes.ts` | 7/10 | 18x "any", gute Endkunden-Isolation |
| `projekte.routes.ts` | 7/10 | 8x "any", Business-Logik in Route |
| `nbResponse.routes.ts` | 7/10 | Saubere Task-Management-Routes |
| `wise.routes.ts` | 8/10 | Guter Admin-Only-Schutz |
| `provisionen.routes.ts` | 8/10 | Sauber, gute Rollensteuerung |
| `adminUsers.routes.ts` | 7/10 | Fehlender ADMIN-Check bei einigen Endpoints (nur AUTH) |

---

## 4. Backend Middleware & Infrastruktur

### 4.1 auth.ts (Middleware)

**Pfad:** `/var/www/gridnetz-backend/src/middleware/auth.ts`
**Zeilen:** 192 | **Qualitaet: 8/10**

**Positiv:**
- Multi-Auth-Support (JWT + Session Cookie) mit sauberem Fallback
- Inactivity-Timeout (4h) fuer Sessions
- `lastActivity`-Update fire-and-forget mit 60s Throttle
- Token-Version-Check mit Cookie-Fallback

**Probleme:**
- **Grace Period fuer Download-Tokens** (Zeile 122-128): 1 Stunde nach JWT-Ablauf koennen Query-Token-Requests weiter authentifiziert werden. Das ist ein Sicherheitsrisiko — wenn ein Token kompromittiert wird, bleibt er 1h laenger gueltig.
- **DB-Query bei JEDEM Request** (Zeile 136-139): `prisma.user.findUnique()` wird bei jedem authentifizierten Request ausgefuehrt. Bei hoher Last ein Performance-Bottleneck. Cache-Layer empfohlen.
- **Doppelter `requireAdmin`**: In `auth.ts` (Zeile 189) UND in `roles.ts` (Zeile 22) gibt es jeweils eine `requireAdmin`-Funktion. Imports muessen sorgfaeltig geprueft werden — falsche Import-Quelle koennte zu unterschiedlichem Verhalten fuehren.

---

### 4.2 roles.ts (Middleware)

**Pfad:** `/var/www/gridnetz-backend/src/middleware/roles.ts`
**Zeilen:** ~200+ | **Qualitaet: 8/10**

**Positiv:**
- Klare Hierarchie-Logik (Staff > Kunde > Sub)
- Security-Audit-Logging bei Zugriffsverletzungen
- `getDescendantUserIds()` fuer rekursive Sub-User

**Probleme:**
- **Rekursive DB-Queries** in `getDescendantUserIds()` (Zeile 76+): Fuer jeden Level in der Hierarchie wird eine separate DB-Query gemacht. Bei tiefer Hierarchie (3+ Levels) problematisch. Besser: CTE (Common Table Expression) oder Materialized Path.

---

### 4.3 errorHandler.ts

**Qualitaet: 9/10** — `asyncHandler`-Wrapper und `ApiError`-Klasse sind sauber implementiert und werden konsistent genutzt.

---

## 5. Frontend

### 5.1 API-Client Duplikation (KRITISCH)

Das Frontend hat **4 verschiedene API-Client-Implementierungen**:

| Datei | Typ | Nutzung |
|---|---|---|
| `src/api/client.ts` | Fetch-basiert mit `apiGet/apiPost/apiPatch/apiPut/apiDelete` | Primary |
| `src/services/apiClient.ts` | Eigener Wrapper mit `/api`-Prefix | Dashboard etc. |
| `src/portal/api.ts` | Importiert aus `api/client.ts` | Portal |
| `src/main.tsx` (Zeile 19-37) | Globaler `window.fetch` Interceptor | Alle raw-fetch Calls |

**Probleme:**
- **Doppelte Auth-Header**: `main.tsx` setzt per globalem Fetch-Interceptor den Authorization-Header, UND `api/client.ts` setzt ihn auch. Doppelte Header-Setzung.
- **Unterschiedliches Token-Reading**: `main.tsx` liest aus `localStorage.getItem('gridnetz_token')`, `api/client.ts` nutzt `getAccessToken()`. Falls diese unterschiedliche Werte liefern, inkonsistentes Verhalten.
- **`services/apiClient.ts`** (Zeile 9): `if (!token) throw new Error(...)` — wirft Fehler wenn nicht eingeloggt, waehrend `api/client.ts` den Request ohne Token sendet. Unterschiedliches Verhalten.
- **Kein zentraler Error-Handler**: Jeder Client hat eigene Fehlerbehandlung. Kein automatisches Token-Refresh bei 401.

**Empfehlung:** Auf EINEN API-Client konsolidieren mit:
- Zentralem Token-Management
- Automatischem 401 → Refresh-Token Flow
- Einheitlicher Fehlerbehandlung

---

### 5.2 main.tsx

**Pfad:** `/var/www/gridnetz-frontend/src/main.tsx`
**Zeilen:** 83 | **Qualitaet: 7/10**

**Positiv:**
- Sentry-Integration
- ErrorBoundary als aeusserste Schicht
- PWA Service Worker Registration
- Vite Chunk-Error Handler

**Probleme:**
- **Globaler Fetch-Override** (Zeile 19-37): Monkey-Patching von `window.fetch` ist fragil. Kann mit Bibliotheken kollidieren die eigene Interceptoren haben.
- **Verwaiste App.tsx**: `src/App.tsx` wird laut Frontend-Map NICHT genutzt — main.tsx baut die Provider-Hierarchie selbst. Tote Datei.

---

### 5.3 api/client.ts

**Pfad:** `/var/www/gridnetz-frontend/src/api/client.ts`
**Zeilen:** 165 | **Qualitaet: 7/10**

**Positiv:**
- Typisierte API-Funktionen (`apiGet<T>`, `apiPost<T>`, etc.)
- Automatische Bearer-Token-Injection
- FormData-Support fuer Uploads

**Probleme:**
- **Kein 401-Handling**: Bei abgelaufenem Token wird ein generischer Error geworfen statt automatisch zu refreshen.
- **Kein Retry-Mechanismus**: Netzwerk-Fehler fuehren sofort zum Abbruch.
- **Error-Messages enthalten URL**: `throw new Error("GET " + url + " failed: ...")` — koennte sensitive Pfade in Error-Tracking exponieren.
- **`apiDelete` gibt `void` zurueck**: Keine Moeglichkeit, Server-Response bei DELETE auszuwerten.

---

### 5.4 React Query Konfiguration

**Konfiguration** (main.tsx Zeile 50-58):
```
staleTime: 30s, gcTime: 5min, retry: 1, refetchOnWindowFocus: false
```

**Probleme:**
- **`refetchOnWindowFocus: false`**: Benutzer die zwischen Tabs wechseln sehen veraltete Daten. Fuer ein Verwaltungsportal wo mehrere Leute gleichzeitig arbeiten ist das problematisch.
- **`retry: 1`**: Nur ein Retry bei Netzwerkfehlern. Fuer kritische Operationen (Rechnungs-PDF laden) zu wenig.

---

### 5.5 Provider-Hierarchie

```
ErrorBoundary > QueryClientProvider > AuthProvider > RealtimeProvider > WhiteLabelProvider > AppRouter
```

**Bewertung: 8/10** — Sinnvolle Reihenfolge. RealtimeProvider (WebSocket) innerhalb von Auth ist korrekt.

---

## 6. Querschnittsthemen

### 6.1 TypeScript `any`-Nutzung

| Bereich | `any`-Stellen | Bewertung |
|---|---|---|
| emailPipeline.service.ts | 49x `as any` | KRITISCH |
| nbResponseOrchestrator.service.ts | 23x | HOCH |
| nbResolveEngine.service.ts | 17x | HOCH |
| ops.service.ts | 16+2 | HOCH |
| produkte.routes.ts | 40x | HOCH |
| Routes gesamt | 138x (Wort "any") | MITTEL |
| Services gesamt | 57x `: any` | HOCH |

**Haupt-Ursachen:**
1. Prisma JSON-Felder (`additionalData`, `extractedData`, `technicalData`) werden als `any` behandelt statt mit Zod/io-ts validiert.
2. LLM-Responses werden unsicher gecastet.
3. Email-Pipeline-Kontext wird zwischen Funktionen als `any` weitergereicht.

---

### 6.2 Code-Duplikation

| Duplizierter Code | Dateien | Empfehlung |
|---|---|---|
| `nextInvoiceNumber()` + `encodeInvoiceCode()` | `rechnung.routes.ts`, `autoInvoice.service.ts`, `installation.routes.ts` | → `lib/invoiceNumber.ts` |
| `escapeHtml()` / `escapeXml()` | 15+ Dateien | → `utils/escape.ts` |
| `buildAdressKurz()` / `buildAdressFull()` | `netzanfrage.service.ts` (identisch!) | Zusammenfuehren |
| Factro API Request Pattern | `factro.service.ts`, `netzanfrage.service.ts`, `factroCommentSync.ts` | → `lib/factroClient.ts` |
| Email-Template-Fallbacks | 5+ Template-Dateien | → Template-Registry |

---

### 6.3 Leere catch-Bloecke

55+ Stellen mit leeren `catch {}` oder `catch { }` gefunden. Die haeufigsten Patterns:

1. **Fire-and-Forget DB-Updates**: `.catch(() => {})` — akzeptabel fuer nicht-kritische Updates (z.B. lastActivity)
2. **Leere catch in Service-Logik**: Potenziell gefaehrlich, da Fehler verschluckt werden
3. **JSON.parse ohne Fehlerbehandlung**: Einige `catch {}` bei JSON-Parsing sind OK, sollten aber mindestens loggen

---

### 6.4 Process.env ohne Validierung

49+ Stellen wo `process.env` direkt gelesen wird, oft mit String-Fallbacks:

**Kritische Beispiele:**
- `CREDENTIALS_MASTER_KEY` (wise.service.ts Zeile 30): Kein Fallback, wirft erst bei Nutzung
- `WISE_SCA_PRIVATE_KEY_PATH` (Zeile 851): Leerer String als Fallback, `fs.readFileSync("")` wuerde crashen
- `JWT_SECRET` wird zentral in `bootstrap/env.ts` validiert — gutes Pattern, aber nicht ueberall genutzt

**Empfehlung:** Zentrale ENV-Validierung beim Start (z.B. mit `envalid` oder `zod`).

---

### 6.5 Potenzielle Performance-Probleme

| Problem | Datei | Zeile | Schwere |
|---|---|---|---|
| N+1 bei Wise-Sync (einzelne Transaktion) | wise.service.ts | 413-449 | MITTEL |
| Alle offenen Rechnungen laden fuer Matching | wise.service.ts | 551-568 | MITTEL |
| DB-Query bei jedem Auth-Request | auth.ts | 136-139 | HOCH |
| Rekursive User-Hierarchie-Queries | roles.ts | 76+ | NIEDRIG |
| Synchroner PDF-Datei-Lese | invoicePdf.service.ts | 483 | NIEDRIG |
| processQueue Race-Condition | email.service.ts | 217-240 | MITTEL |

---

### 6.6 Sicherheitsbewertung

| Aspekt | Status | Details |
|---|---|---|
| Auth (JWT + Session) | GUT | Token-Version, Cookie-Fallback, 2FA |
| Rollen-System | GUT | 7 Rollen, granulare Guards, Security-Audit |
| Input-Validierung | MITTEL | express-validator bei Auth, aber nicht ueberall |
| SQL-Injection | SICHER | Prisma ORM schuetzt durch parametrisierte Queries |
| Path Traversal | GUT | `resolveSafePath()` Utility vorhanden |
| CSRF | TEILWEISE | Session-Auth hat CSRF-Token, JWT-Auth nicht betroffen |
| Rate-Limiting | MANGELHAFT | Nur `aiLimiter` fuer AI-Endpoints, kein Login-Rate-Limit |
| Brute-Force-Schutz | FEHLEND | Kein Account-Lockout, kein exponentielles Backoff |
| Secrets in Code | ACHTUNG | PDF_TOKEN_SECRET Fallback-Wert ist schwach |
| Password-Reset Token | ACHTUNG | Im Klartext in DB (sollte gehasht sein) |

---

## 7. Kritische Findings (Top 10)

### #1 — Kein Login-Rate-Limiting (SICHERHEIT)
**Datei:** `/var/www/gridnetz-backend/src/routes/auth.routes.ts`
**Problem:** Der Login-Endpoint hat keinen Brute-Force-Schutz. Ein Angreifer kann unbegrenzt Passwoerter durchprobieren.
**Empfehlung:** `express-rate-limit` mit 5 Versuchen pro 15 Minuten pro IP+Email.

### #2 — 4 API-Clients im Frontend (ARCHITEKTUR)
**Dateien:** `src/api/client.ts`, `src/services/apiClient.ts`, `src/main.tsx`, `src/portal/api.ts`
**Problem:** Inkonsistentes Verhalten, doppelte Auth-Header, unterschiedliche Fehlerbehandlung.
**Empfehlung:** Konsolidierung auf einen Client mit Interceptor-Pattern.

### #3 — 49x `as any` in emailPipeline.service.ts (TYPSICHERHEIT)
**Datei:** `/var/www/gridnetz-backend/src/services/emailPipeline.service.ts`
**Problem:** Fast jedes Objekt wird unsicher gecastet. Laufzeitfehler durch falsche Typen moeglich.
**Empfehlung:** Zod-Schemas fuer LLM-Responses und Pipeline-Kontext definieren.

### #4 — processQueue Race Condition (ZUVERLAESSIGKEIT)
**Datei:** `/var/www/gridnetz-backend/src/services/email.service.ts`, Zeile 217-240
**Problem:** Parallele Worker koennten dasselbe Queue-Item greifen.
**Empfehlung:** Atomarer `UPDATE ... RETURNING` oder Database-Lock.

### #5 — 3x duplizierte nextInvoiceNumber() (WARTBARKEIT)
**Dateien:** `rechnung.routes.ts`, `autoInvoice.service.ts`, `installation.routes.ts`
**Problem:** Aenderungen an der Rechnungsnummern-Logik muessen an 3 Stellen gemacht werden.
**Empfehlung:** Gemeinsames Modul `/var/www/gridnetz-backend/src/lib/invoiceNumber.ts`.

### #6 — DB-Query bei jedem Auth-Request (PERFORMANCE)
**Datei:** `/var/www/gridnetz-backend/src/middleware/auth.ts`, Zeile 136-139
**Problem:** `prisma.user.findUnique()` bei jedem Request. Bei 100 req/s = 100 DB-Queries/s nur fuer Auth.
**Empfehlung:** In-Memory-Cache (60s TTL) fuer User-Active-Status und tokenVersion.

### #7 — In-Memory Rate-Limit Map waechst unbegrenzt (MEMORY LEAK)
**Datei:** `/var/www/gridnetz-backend/src/routes/auth.routes.ts`, Zeile 539-540
**Problem:** `resendLimits` Map wird nie bereinigt. Bei vielen Usern ueber Zeit Memory Leak.
**Empfehlung:** TTL-basierte Map (z.B. `lru-cache`) oder Redis.

### #8 — Password-Reset Token im Klartext (SICHERHEIT)
**Datei:** `/var/www/gridnetz-backend/src/routes/auth.routes.ts`, Zeile 427
**Problem:** Bei DB-Kompromittierung sind alle Reset-Tokens sofort nutzbar.
**Empfehlung:** Nur SHA-256-Hash des Tokens in DB speichern.

### #9 — Hardcoded SEPA-IBAN im Export (FUNKTIONALITAET)
**Datei:** `/var/www/gridnetz-backend/src/services/provision.service.ts`, Zeile 700
**Problem:** `DE00000000000000000000` als Debtor-IBAN. SEPA-Dateien werden von Banken abgelehnt.
**Empfehlung:** IBAN aus CompanySettings oder WiseAccount laden.

### #10 — Hardcoded Factro-Package-UUIDs (WARTBARKEIT)
**Datei:** `/var/www/gridnetz-backend/src/services/factro.service.ts`, Zeile 21-28
**Problem:** Bei Aenderung der Factro-Konfiguration muss Backend-Code geaendert und deployed werden.
**Empfehlung:** In DB-Tabelle (FactroConfig) oder ENV-Variablen auslagern.

---

## 8. Empfehlungen

### Sofort (Quick Wins, < 1 Tag)
1. **Login-Rate-Limiting** implementieren (`express-rate-limit`, 1-2h Aufwand)
2. **`nextInvoiceNumber()`** in gemeinsames Modul `lib/invoiceNumber.ts` extrahieren (30min)
3. **`buildAdressKurz`/`buildAdressFull`** in netzanfrage.service.ts zusammenfuehren (5min)
4. **`resendLimits` Map** mit TTL-Bereinigung oder `lru-cache` versehen (15min)
5. **Route nach Export** in auth.routes.ts fixen — `/push-token` vor `export` verschieben (5min)

### Kurzfristig (1-2 Wochen)
6. **Frontend API-Client konsolidieren** — `services/apiClient.ts` eliminieren, `main.tsx` Interceptor entfernen
7. **Zod-Schemas** fuer LLM-Responses und Pipeline-Kontext definieren
8. **User-Cache in Auth-Middleware** (in-memory mit TTL oder Redis)
9. **Password-Reset-Token hashen** (SHA-256)
10. **`escapeHtml()`/`escapeXml()`** in `utils/escape.ts` zentralisieren

### Mittelfristig (1-3 Monate)
11. **emailPipeline.service.ts** refactoren und 49x `any` eliminieren
12. **installation.routes.ts** in Sub-Module aufteilen (Routes, Upload, Helpers)
13. **Security-Audit-Events** in DB persistieren (neue Tabelle `security_audit_log`)
14. **ENV-Validierung** beim Startup mit Zod (`src/bootstrap/validateEnv.ts`)
15. **processQueue** auf atomare Queue-Verarbeitung umstellen (SELECT FOR UPDATE SKIP LOCKED)
16. **Doppelter `requireAdmin`** konsolidieren — eine Quelle der Wahrheit

### Langfristig
17. **Comprehensive Input-Validierung** (Zod-Middleware fuer alle Endpoints)
18. **OpenTelemetry-Integration** fuer Performance-Monitoring
19. **E2E-Tests** fuer kritische Flows (Login, Rechnung, Netzanfrage, Wise-Sync)
20. **SEPA-Export** mit echten Debtor-Daten aus CompanySettings
21. **Factro-UUIDs** in DB-Konfiguration oder Admin-UI verschieben

---

*Generiert am 2026-03-11 durch automatisierte Code-Analyse. ~45 Dateien analysiert.*
