# GridNetz Portal - Architektur-Uebersicht

> Stand: 2026-03-11 | ~120 DB-Models | ~96 Route-Dateien | ~822 Frontend-Dateien
> Aktualisiert mit Cross-Layer-Analyse und Refactoring-Empfehlungen

---

## Inhaltsverzeichnis

1. [Gesamtuebersicht](#1-gesamtuebersicht)
2. [Technologie-Stack](#2-technologie-stack)
3. [Cross-Layer-Abhaengigkeiten](#3-cross-layer-abhaengigkeiten)
4. [Datenfluss pro Feature-Bereich](#4-datenfluss-pro-feature-bereich)
5. [Mermaid-Diagramme](#5-mermaid-diagramme)
6. [Technische Schulden mit Prioritaet](#6-technische-schulden)
7. [Architektur-Schwaechen und bessere Patterns](#7-architektur-schwaechen)
8. [Empfohlene Refactoring-Reihenfolge](#8-empfohlene-refactoring-reihenfolge)
9. [Statistik](#9-statistik)

---

## 1. Gesamtuebersicht

Das GridNetz Portal ist eine Full-Stack-Anwendung fuer die Verwaltung von Netzanmeldungen (Photovoltaik, Speicher, Wallbox, Waermepumpe). Es orchestriert den gesamten Lebenszyklus einer Installation vom Kundeneingang bis zur Inbetriebnahme, inklusive automatisierter Email-Verarbeitung, KI-gestuetzter Klassifikation, Factro-Projektmanagement-Sync, doppelter Buchfuehrung und WhatsApp-Bot.

```
┌───────────────────────────────────────────────────────────────────┐
│                    FRONTEND (React 18 + Vite)                      │
│  ~822 Dateien │ 65 Pages │ 15 Feature-Module │ Tailwind + Three.js │
│  TanStack Query │ Zustand │ WebSocket │ Electron-Support            │
├───────────────────────────────────────────────────────────────────┤
│                   NGINX Reverse Proxy (HTTPS)                      │
├───────────────────────────────────────────────────────────────────┤
│                   API GATEWAY (Express, Port 3002)                 │
│  JWT + Session Dual-Auth │ Rate Limiting │ CSRF │ RequestID         │
│  96 Route-Dateien │ ~500+ Endpoints │ WebSocket (ws)               │
├───────────────────────────────────────────────────────────────────┤
│                       SERVICE LAYER                                │
│  14 Service-Bereiche │ 80+ Services │ ~20 Cron-Jobs                │
│  accounting/ │ ai/ │ automations/ │ brain/ │ claude/               │
│  documentGenerator/ │ nbPortal*/ │ rag/ │ stromnetzBot/            │
│  vdeFormular/ │ whatsapp/ │ workflowV2/ │ 40+ Root-Services        │
├──────────────┬──────────────┬──────────────┬──────────────────────┤
│  MySQL       │ PostgreSQL   │ File System  │ Externe APIs          │
│  (Prisma)    │ (pgvector)   │ (Uploads,    │ OpenAI, Factro,       │
│  ~120 Models │ 25k Embeds   │  PDFs)       │ Wise, VNBdigital,     │
│  gridnetz_db │ gridnetz_    │              │ MaStR, Wassenger,     │
│              │ vectors      │              │ SMTP/IMAP, Maps       │
└──────────────┴──────────────┴──────────────┴──────────────────────┘
```

### Benutzerrollen (7 Stufen)

| Rolle | Berechtigungen |
|-------|---------------|
| ADMIN | Vollzugriff, System-Konfiguration, User-Management |
| MITARBEITER | Staff-Zugriff, kein System-Config, Email-Center |
| HANDELSVERTRETER | Eigene zugewiesene Kunden, Provisionen, Self-Service |
| KUNDE | Whitelabel, eigene Installationen erstellen/einsehen |
| SUBUNTERNEHMER | Unter Whitelabel-Kunde, kein Rechnungszugriff |
| DEMO | Leserechte |
| ENDKUNDE_PORTAL | Separates Portal, Endkunden-Sicht auf eigene Installation |

---

## 2. Technologie-Stack

### Backend

| Schicht | Technologie | Bemerkung |
|---------|-------------|-----------|
| Runtime | Node.js (TypeScript strict, NodeNext) | Compiled nach `dist/` |
| Framework | Express.js | PM2 Prozess (ID 5) |
| ORM | Prisma (MySQL) | ~120 Models, ~35 Enums |
| Vektor-DB | pgvector (PostgreSQL 15, v0.8.0) | HNSW-Index, Cosine Similarity |
| Auth | JWT + Session (Dual) | Cookie-Fallback, tokenVersion-Validierung |
| Email | Nodemailer (SMTP) + ImapFlow (IMAP) | Polling alle 5 Min |
| AI Primary | OpenAI gpt-4o-mini | Klassifikation, Embeddings, Chat, Complaint-Parsing |
| AI Parallel | Ollama llama3.1:8b (lokal) | Vergleichs-Klassifikation |
| PDF | PDFKit + Python Scripts | Schaltplaene, Lagplaene, Vollmachten |
| Cron | node-cron | ~20 Jobs (5min - woechentlich) |
| WebSocket | ws (nativ) | Echtzeit-Updates, Terminal |
| Bot | Puppeteer (NB-Portal), Wassenger (WhatsApp) | Portal-Automation |
| Logging | Pino via createLogger() | Strukturiertes Logging |
| Error Tracking | Sentry (captureError) | Backend-Fehler |

### Frontend

| Schicht | Technologie | Bemerkung |
|---------|-------------|-----------|
| Framework | React 18 | Lazy-Loading fuer geschuetzte Seiten |
| Build | Vite | Service Worker fuer PWA |
| Styling | Tailwind CSS | |
| Server-State | TanStack React Query | staleTime 30s, gcTime 5min, retry 1 |
| Client-State | Zustand | Feature-Stores |
| Routing | React Router | BrowserRouter (Web), HashRouter (Electron) |
| 3D | Three.js / React Three Fiber | Dashboard-Hintergrund, Haus-Visualisierung |
| Realtime | WebSocket (custom) | Auto-Reconnect, Channel-Subscription |
| Desktop | Electron-Support | HashRouter, Offline-Koffer |

### Infrastruktur

| Komponente | Details |
|------------|---------|
| Server | Linux (Debian 6.1.0) |
| Process Manager | PM2 (gridnetz-backend = ID 5) |
| Datenbank | MySQL (gridnetz_db) + PostgreSQL (gridnetz_vectors) |
| Cache | Map-basiert (in-process, max 100/500 Entries) |
| Backup | pg_dump + Upload-Backup (3:15 AM, Woechentlich) |
| Monitoring | Slack Webhooks, Health-Checks (intern) |
| Build | `npm run build` (Backend: TSC, Frontend: Vite) |

---

## 3. Cross-Layer-Abhaengigkeiten

### 3.1 Kern-Entitaeten und Verknuepfungen

```
Installation (Herzstuck, ~240 Zeilen im Schema, 15+ Indizes)
├── Kunde (N:1) ──── User (1:N) ──── Handelsvertreter (1:1 via User)
├── Netzbetreiber (N:1) ──── NetzbetreiberCredential[] (NB-Portal-Login)
├── FactroProject (1:1 unique) ──── FactroComment[], EmailLog[]
├── Document[] (1:N) ──── via installationId + factroProjectId
├── Email[] (1:N) ──── EmailClassification[], EmailAction[]
├── IncomingEmail[] (1:N) ──── NB-Email-Matching
├── SentEmail[] (1:N) ──── Ausgehende Emails
├── Comment[] (1:N) ──── installationId, authorId, isInternal
├── Task[] (1:N) ──── assignedToId, OPEN/IN_PROGRESS/COMPLETED/CANCELLED
├── StatusHistory[] (1:N) ──── from_status, to_status, changed_by
├── InboxItem[] (1:N) ──── WorkflowV2 Aufgaben-Queue
├── InstallationEvent[] (1:N) ──── WorkflowV2 Event-Stream
├── NbResponseTask[] (1:N) ──── Auto-Resolve Pipeline
├── Deadline[] (1:N) ──── Fristueberwachung
├── VdeFormularSet[] (1:N) ──── VDE-Formulare
├── InstallationAlert[] (1:N) ──── Anomalie-Alerts
├── CalendarAppointment[] (1:N)
├── PortalUserInstallation[] (N:M) ──── Endkunden-Portal-Zugang
├── Projekt (1:1 unique) ──── Projekt-Management-Modul
├── Anlage (N:1) ──── Technik-Komponenten, Rechnungen
└── WorkflowV2 (phase/zustand Felder) ──── Parallel zu Legacy-Status
```

### 3.2 Service-Abhaengigkeitsgraph

```
emailInbox.service (IMAP Polling)
  └── emailPipeline.service (Verarbeitung)
      ├── openaiClassifier.service ──── OpenAI API
      ├── localAI.service ──── Ollama API
      ├── emailMatcher.service ──── nbDomainMapping, Installation-Lookup
      └── nbResponseOrchestrator.service
          ├── nbThreadAnalyzer.service ──── Email-Thread-Rekonstruktion
          ├── nbComplaintParser.service ──── OpenAI GPT-4o-mini
          ├── nbResolveEngine.service
          │   ├── efkSignature.service ──── EFK-Unterschriften
          │   ├── vdeFormularFetcher.service ──── gridnetz.de/vde-formulare
          │   └── emailAttachment.service ──── SHA-256 Duplikaterkennung
          └── nbComplaintPattern ──── Cross-Project-Learning

workflowV2/transitionService
  ├── workflowV2/eventService ──── InstallationEvent
  │   ├── workflowV2/automationEngine ──── Notifications, Tasks
  │   └── workflowV2/inboxItemFactory ──── InboxItems generieren
  ├── workflowV2/dualWrite ──── Legacy ↔ V2 Sync
  └── brainEventHooks ──── Self-Learning Brain

autoInvoice.service
  ├── invoicePdf.service ──── PDFKit
  ├── journalService ──── Doppelte Buchfuehrung
  └── provisionsService ──── HV-Provisionen

factro.service
  ├── factroCommentSync ──── Kommentar-Import
  ├── factroDocumentImporter ──── Dokument-Import
  ├── factroParser ──── Metadata-Extraktion
  └── netzanfrage.service ──── NA-Tracking, Email-Versand

enterpriseRagService (RAG Entry-Point)
  ├── embeddingService ──── OpenAI text-embedding-3-small
  ├── chunkingService ──── Text-Splitting + Overlap
  └── indexingService ──── pgvector Indexierung
```

### 3.3 Frontend → Backend Mapping

| Frontend-Feature | Frontend-Dateien | API-Route-Dateien | Backend-Services |
|-----------------|-----------------|-------------------|------------------|
| Netzanmeldungen | ~120 (features/netzanmeldungen/) | installation*.routes (7) | workflow*, autoInvoice, emailPipeline |
| Email-Center | ~25 (control-center/tabs/communication/) | emailInbox, emailSend, emailAdmin, emailLearning | emailInbox, emailPipeline, ai/* |
| Factro | ~15 (pages/FactroCenter, components/factro/) | factro.routes, factroCommentActions | factro.service, factroCommentSync |
| Rechnungen | ~30 (finanzen-module/, modules/rechnungen/) | rechnung, mahnung, wise, accounting | autoInvoice, accounting/*, wise |
| Dashboard | ~20 (modules/dashboard/, DashboardV2/) | dashboard, analytics | diverse Aggregations-Services |
| Produkte-DB | ~10 (pages/ProdukteDatenbank) | produkte, zerez, wizardLearning | wizardLearning, produktMatch |
| HV-Center | ~15 (features/hv-center/) | hv.routes, provision.routes | provisionsService, hvReport |
| Portal | ~15 (portal/) | portal.routes | betreiberChat, portalNotification |
| KI-System | ~15 (features/rag-admin/, brain-admin/, ai-center/) | ai, claudeAI, rag, brain, featureBuilder | ai/*, rag/*, brain/*, claudeAI |
| WhatsApp | ~5 (embedded in Detail-Panel) | whatsapp.routes | whatsapp/* (7 Services) |

---

## 4. Datenfluss pro Feature-Bereich

### 4.1 Installation-Lifecycle

```
[Frontend] Wizard (WizardMain.tsx)
    │
    ▼ POST /api/installations/customer
[API] installationsCustomer.routes.ts
    │
    ▼
[Service] → prisma.installation.create() + prisma.anlage.create()
    │
    ▼
[DB] Installation (status: EINGANG) + Anlage + TechnikModul/WR/Speicher
    │
    ▼ Dokument-Upload
[Frontend] DetailModal → DocumentsTab
    │
    ▼ POST /api/installations/:id/documents
[API] installation.routes.ts
    │
    ▼
[Service] documentCompleteness.checkDocumentCompleteness()
    │
    ▼ Status-Transition: EINGANG → BEIM_NB
[Service] workflowV2/transitionService.transition()
    │
    ├── dualWrite.dualWriteStatus() (Legacy + V2)
    ├── eventService.createEvent("STATUS_CHANGED")
    │   ├── automationEngine.runAutomations()
    │   └── inboxItemFactory.processEvent()
    ├── statusHistory.create()
    └── brainEventHooks.trackInstallationStatusChanged()

    ▼ Email an NB senden
[Service] nbCommunication.service → emailGateway.service → SMTP
    │
    ▼ NB antwortet (IMAP Polling, Cron: */5)
[Service] emailInbox.service.poll()
    │
    ▼
[Service] emailPipeline.service.processEmail()
    ├── openaiClassifier → Kategorie, Sentiment, Dringlichkeit
    ├── localAI → Parallel-Klassifikation (Vergleich)
    └── emailMatcher → Installation zuordnen
    │
    ├── Falls "Genehmigung" → Status: GENEHMIGT → Rechnung
    ├── Falls "Rueckfrage" → Status: RUECKFRAGE → NbResponseTask
    └── Falls "Ablehnung" → Status: STORNIERT

    ▼ Bei GENEHMIGT
[Service] autoInvoice.service.generateInvoiceForInstallation()
    ├── invoiceCounter (atomare Nummernvergabe)
    ├── invoicePdf.service (PDF-Generierung)
    ├── journalService.bookInvoiceIssued() (Doppelte Buchfuehrung)
    └── provisionsService (HV-Provision berechnen)

    ▼ Zahlung
[Service] wise.service → WiseTransaction → aiMatching → Rechnung.BEZAHLT
    └── journalService.bookPaymentReceived()
```

### 4.2 Email-Pipeline (Detail)

```
[Extern] IMAP Server (NB-Emails)
    │
    ▼ Cron: */5 min
[Service] emailInbox.service.poll() → ImapFlow
    │
    ▼ Neue Email erkannt
[Service] emailPipeline.service.processEmail(rawEmail)
    │
    ├── Promise.allSettled([
    │     openaiClassifier.classifyEmail(),    // PRIMARY: gpt-4o-mini
    │     localAI.classifyEmailLocal()         // PARALLEL: llama3.1:8b
    │   ])
    │
    ├── Guards pruefen:
    │   ├── noreply@ → responseTo=null, Warnung
    │   ├── hasConcreteDocumentRequests() → DOCUMENT_KEYWORDS pruefen
    │   └── IBN-Checkliste fuer netztechnische_stellungnahme
    │
    ├── emailMatcher.matchEmailToInstallation()
    │   ├── Schritt 1: NB-Domain → nbDomainMapping → netzbetreiberId
    │   ├── Schritt 2: Betreff → Aktenzeichen/Name/Adresse
    │   ├── Schritt 3: Body → Vorgangsnummern, PLZ, Adressen
    │   └── Ergebnis: installationId | null
    │
    ▼
[DB] EmailClassification erstellen
    ├── llm* = OpenAI Ergebnis (Primary)
    ├── local* = Ollama Ergebnis (Parallel)
    └── reviewedById = null (wartet auf Admin-Review)
    │
    ├── Falls category == "nb_response":
    │   ▼
    │   [Service] nbResponseOrchestrator.orchestrateResponse()
    │   ├── nbThreadAnalyzer.buildThread() → Email-Thread rekonstruieren
    │   ├── nbComplaintParser.parseComplaints() → GPT-4o-mini
    │   │   └── 6 Typen: MISSING_SIGNATURE, SCHALTPLAN_ERROR, WRONG_DATE,
    │   │       MISSING_DOCUMENT, FORM_INCOMPLETE, CLARIFICATION_NEEDED
    │   ├── nbResolveEngine.resolveTask()
    │   │   ├── EFK-Signatur anheften (efkSignature.service)
    │   │   ├── VDE-Formulare beifuegen (vdeFormularFetcher)
    │   │   └── Dokumente suchen (emailAttachment, SHA-256 Dedupe)
    │   └── NbResponseTask erstellen
    │       ├── resolve_status: pending|partial|resolved|manual_needed
    │       ├── thread_emails: JSON
    │       └── Admin gibt frei → Email senden → learnFromResolvedTask()
    │
    └── brainEventHooks.trackEmailReceived() → LearningEvent
```

### 4.3 Factro-Integration

```
[Extern] Factro Cloud API (cloud.factro.com/api/core)
    │
    ▼ Cron: */10 min (Projekte)
[Service] factro.service.pollProjects()
    ├── GET /projects → Factro API (Header: api-key)
    ├── factroParser.parse() → Metadata extrahieren
    ├── FactroProject upsert (DB)
    ├── Sold-Erkennung: "PROJEKT VERKAUFT" Package → isSold=true
    └── Installation-FK synchronisieren
    │
    ▼ Cron: */10 min (Kommentare)
[Service] factroCommentSync.syncAllComments()
    ├── GET /tasks/{taskId}/comments → Factro API
    ├── FactroComment upsert (inkrementell, 4155 ueber 117 Projekte)
    └── parentCommentId fuer Reply-Chains
    │
    ▼ Netzanfrage senden
[Service] netzanfrage.service
    ├── VNB-Email ermitteln (resolveVnbEmail: 4 Fallbacks)
    ├── Email senden → emailGateway
    ├── Factro-Kommentar schreiben: "Netzanfrage gestellt am DD.MM.YYYY"
    ├── FactroProject.netzanfrageGestelltAm setzen
    └── EmailLog erstellen (factroProjectId FK)

[Frontend] ProjektDetailPage.tsx
    ├── GET /api/factro/projects/:id → Projekt-Details
    ├── GET /api/factro/projects/:id/comments → Kommentare
    ├── GET /api/factro/projects/:id/documents → Dokumente
    └── GET /api/factro/projects/:id/emails → Email-Verlauf (outgoing + incoming)
```

### 4.4 Rechnungsstellung

```
[Trigger] Installation.status → GENEHMIGT oder FERTIG
    │
    ▼
[Service] autoInvoice.service.generateInvoiceForInstallation()
    │
    ├── 1. Kundenpreis ermitteln
    │   ├── KundeServicePrice (kundenspezifisch, z.B. Sol-Living=50€)
    │   └── Default-Preis (z.B. EHBB=89€)
    │
    ├── 2. SUB-Erkennung
    │   ├── users.parent_user_id → Whitelabel-User finden
    │   └── Rechnung IMMER unter Whitelabel-Kunden (nicht SUB)
    │
    ├── 3. Rechnungsnummer generieren
    │   ├── Format: RE-YYYYMM-XXXXXX (base36, Offset 17000)
    │   ├── invoiceCounter.upsert (atomare Nummernvergabe)
    │   └── ⚠ Aktuelle Implementierung hat potenzielle Race Condition
    │
    ├── 4. Rechnung erstellen
    │   └── Status: ENTWURF
    │
    ├── 5. PDF generieren
    │   └── invoicePdf.service → PDFKit
    │
    ├── 6. Doppelte Buchfuehrung
    │   └── journalService.bookInvoiceIssued() → JournalEntry + JournalEntryLines
    │
    └── 7. Provision erstellen
        └── provisionsService → Provision (HV-Provisionssatz * Nettobetrag)

[Rechnung Lifecycle]
    ENTWURF → OFFEN → VERSENDET → BEZAHLT
                │                    ▲
                ▼                    │
            UEBERFAELLIG ──→ MAHNUNG │
                                     │
    Wise API → WiseTransaction ──────┘
        ├── aiMatching.getMatchSuggestions() (Scoring 0-100)
        ├── Auto-Match bei Konfidenz >= 90
        └── journalService.bookPaymentReceived()
```

### 4.5 KI/AI-System

```
                       ┌────────────────────┐
                       │ Benutzer-Anfrage   │
                       └─────────┬──────────┘
                                 │
                    ┌────────────▼────────────┐
                    │ Query Router (RAG oder  │
                    │ direkte LLM-Antwort?)   │
                    └──┬──────────────────┬───┘
                       │                  │
           ┌───────────▼───┐    ┌────────▼──────────┐
           │ Direkte LLM   │    │ Enterprise RAG     │
           │ gpt-4o-mini   │    │ getSmartContext()  │
           └───────────────┘    └────────┬──────────┘
                                         │
                                ┌────────▼──────────┐
                                │ Kategorie-Auswahl │
                                │ (29 Kategorien)   │
                                └────────┬──────────┘
                                         │
                                ┌────────▼──────────┐
                                │ Multi-Query       │
                                │ Decomposition     │
                                └────────┬──────────┘
                                         │
                            ┌────────────▼────────────┐
                            │ Embedding generieren    │
                            │ (text-embedding-3-small)│
                            └────────────┬────────────┘
                                         │
                            ┌────────────▼────────────┐
                            │ pgvector Suche           │
                            │ (HNSW, Cosine Similarity)│
                            └────────────┬────────────┘
                                         │
                            ┌────────────▼────────────┐
                            │ Heuristisches Reranking │
                            │ Vektor 40% │ Terms 25% │
                            │ Bigrams 15% │ Pos 10% │
                            │ Metadata 10%            │
                            └────────────┬────────────┘
                                         │
                            ┌────────────▼────────────┐
                            │ Contextual Compression  │
                            │ (nur relevante Saetze)  │
                            │ Token-Budget-Management │
                            └────────────┬────────────┘
                                         │
                            ┌────────────▼────────────┐
                            │ LLM-Antwort mit Kontext │
                            └─────────────────────────┘

RAG-Kategorien (29): produkte, netzbetreiber, email_templates, docs,
  bot_learning, installations, status_history, kunden, brain_patterns,
  brain_rules, smart_suggestions, grid_operator_intelligence,
  installation_intelligence, nb_correspondence, nb_config, evu_profiles,
  technik_katalog (17.160!), anlagen, dokumente, kommentare_aufgaben,
  learning_events, automation_rules, projekte, regional_patterns,
  email_analyses, whatsapp_insights, automation_logs
```

### 4.6 WhatsApp-Bot

```
[Extern] Wassenger Webhook → POST /api/whatsapp/webhook
    │
    ▼
[Service] whatsappWebhook.service.handleWebhook()
    │
    ▼
[Service] whatsappRouter.service.routeMessage()
    ├── whatsAppUserLink pruefen (Telefonnummer → User)
    ├── whatsappConversation.service (State Machine)
    │   └── States: IDLE → GREETING → INQUIRY → PRODUCT_MATCH → ...
    └── claudeBot.service.processMessage()
        ├── whatsappContext.buildContext() → Installation/Kunde/NB Kontext
        ├── productMatcher.matchProducts() → Produkt-DB Suche
        └── Claude/OpenAI API → Antwort generieren

[Service] whatsappMessage.service.sendMessage() → Wassenger API
    └── whatsappMedia.service → Medien-Verarbeitung
```

---

## 5. Mermaid-Diagramme

### 5.1 Gesamtarchitektur

```mermaid
graph TB
    subgraph Frontend["Frontend (React 18 + Vite)"]
        UI[UI Components<br/>~822 Dateien]
        TQ[TanStack Query<br/>Server-State]
        ZS[Zustand<br/>Client-State]
        WS_C[WebSocket Client<br/>Echtzeit]
        Router[React Router<br/>65 Pages]
    end

    subgraph API["API Layer (Express, Port 3002)"]
        Auth[JWT + Session<br/>Dual Auth]
        Routes[96 Route-Dateien<br/>~500+ Endpoints]
        MW[Middleware<br/>Rate Limit, CSRF,<br/>Tracking, RequestID]
        EH[Error Handler<br/>ApiError, Prisma,<br/>Sentry]
    end

    subgraph Services["Service Layer (14 Bereiche)"]
        Email[Email-System<br/>IMAP + SMTP + Pipeline<br/>Dual-LLM]
        AI[KI-System<br/>OpenAI + Ollama<br/>Klassifikation]
        Workflow[Workflow V2<br/>Status + Events<br/>+ Legacy Dual-Write]
        Factro[Factro-Sync<br/>Projekte + Kommentare<br/>Cron: */10 min]
        Invoice[Rechnungen<br/>PDF + Buchfuehrung<br/>Auto-Invoice]
        NB[NB-Auto-Resolve<br/>Complaints + Patterns<br/>Thread-Analyse]
        RAG[RAG Enterprise<br/>29 Kategorien<br/>25k Embeddings]
        WA[WhatsApp Bot<br/>Claude + Wassenger<br/>State Machine]
        Acct[Accounting<br/>Journal + Expenses<br/>Year-End]
        DocGen[Dokument-Generator<br/>Schaltplan + Lageplan<br/>Vollmacht]
    end

    subgraph Data["Daten-Schicht"]
        MySQL[(MySQL<br/>~120 Models<br/>gridnetz_db)]
        PGV[(PostgreSQL<br/>pgvector 25k<br/>gridnetz_vectors)]
        FS[File System<br/>Uploads, PDFs<br/>Backups]
    end

    subgraph External["Externe APIs (12+)"]
        OpenAI[OpenAI<br/>GPT + Embeddings]
        FactroAPI[Factro<br/>cloud.factro.com]
        WiseAPI[Wise<br/>Banktransaktionen]
        VNB[VNBdigital<br/>GraphQL]
        MaStR[MaStR/BNetzA<br/>SOAP]
        Wass[Wassenger<br/>WhatsApp]
        SMTP[SMTP/IMAP<br/>Email]
        Maps[Google Maps<br/>MapTiler, OSM]
    end

    subgraph Cron["Cron-Jobs (~20)"]
        C1[Email Poll<br/>*/5 min]
        C2[Factro Sync<br/>*/10 min]
        C3[Mahnwesen<br/>taeglich 8:00]
        C4[RAG Reindex<br/>*/60 min]
        C5[Backup<br/>3:15 AM]
        C6[HV-Report<br/>5. des Monats]
        C7[Provisionen<br/>1. des Monats]
        C8[NB-Recognition<br/>*/30 min]
    end

    UI --> TQ --> Routes
    ZS --> UI
    WS_C -.->|WebSocket| API
    Router --> UI

    Routes --> Auth --> Services
    MW --> Routes
    EH --> Routes

    Email --> SMTP
    AI --> OpenAI
    Factro --> FactroAPI
    Invoice --> WiseAPI
    NB --> Email
    RAG --> PGV
    RAG --> OpenAI
    WA --> Wass
    DocGen --> Maps

    Services --> MySQL
    Services --> PGV
    Services --> FS

    C1 --> Email
    C2 --> Factro
    C3 --> Invoice
    C4 --> RAG
    C5 --> MySQL
    C6 --> Invoice
    C7 --> Invoice
    C8 --> Email
```

### 5.2 Datenfluss — Email-Pipeline

```mermaid
sequenceDiagram
    participant IMAP as IMAP Server
    participant Inbox as emailInbox.service
    participant Pipeline as emailPipeline
    participant OpenAI as OpenAI gpt-4o-mini
    participant Ollama as Ollama llama3.1:8b
    participant Matcher as emailMatcher
    participant Orch as nbResponseOrchestrator
    participant Parser as nbComplaintParser
    participant Engine as nbResolveEngine
    participant DB as MySQL

    Note over IMAP,DB: Cron: alle 5 Minuten
    IMAP->>Inbox: poll() via ImapFlow
    Inbox->>Pipeline: processEmail(rawEmail)

    par Dual-LLM Klassifikation
        Pipeline->>OpenAI: classifyEmail() [PRIMARY]
        Pipeline->>Ollama: classifyEmailLocal() [PARALLEL]
    end

    OpenAI-->>Pipeline: llm* Ergebnis
    Ollama-->>Pipeline: local* Ergebnis

    Pipeline->>Pipeline: Guards pruefen (noreply, Documents, IBN)
    Pipeline->>Matcher: matchEmailToInstallation()
    Matcher->>DB: Domain-Mapping + Betreff + Body
    Matcher-->>Pipeline: installationId | null

    Pipeline->>DB: EmailClassification speichern

    alt NB-Rueckfrage erkannt
        Pipeline->>Orch: orchestrateResponse()
        Orch->>Orch: buildThread() (References, In-Reply-To)
        Orch->>Parser: parseComplaints() [GPT-4o-mini]
        Parser-->>Orch: NbComplaint[] (6 Typen)
        Orch->>Engine: resolveTask()
        Engine->>DB: EFK-Signatur, VDE-Formulare, Dokumente suchen
        Engine-->>Orch: resolve_status (pending/partial/resolved)
        Orch->>DB: NbResponseTask erstellen
        Note over DB: Admin gibt frei → Email senden
    end

    alt Status-Aenderung
        Pipeline->>DB: Installation.status aktualisieren
        Note over DB: workflowV2 + brainEventHooks
    end
```

### 5.3 Installation Lifecycle (State Machine)

```mermaid
stateDiagram-v2
    [*] --> EINGANG: Wizard / Import / Factro-Sync
    EINGANG --> BEIM_NB: Dokumente vollstaendig + NB zugeordnet

    BEIM_NB --> RUECKFRAGE: NB fragt nach (IMAP erkannt)
    RUECKFRAGE --> BEIM_NB: Antwort gesendet (Auto-Resolve oder manuell)
    BEIM_NB --> GENEHMIGT: NB genehmigt (IMAP erkannt)

    GENEHMIGT --> IBN: Inbetriebnahme gestartet
    IBN --> FERTIG: IBN abgeschlossen

    EINGANG --> STORNIERT: Kunde storniert
    BEIM_NB --> STORNIERT: NB lehnt endgueltig ab
    RUECKFRAGE --> STORNIERT: Timeout / keine Reaktion

    FERTIG --> [*]
    STORNIERT --> [*]

    note right of EINGANG
        Wizard-Erstellung
        Dokument-Upload
        NB-Zuordnung (PLZ-basiert)
        VDE-Formulare generieren
    end note

    note right of BEIM_NB
        Email an NB senden
        Reminder-System (Cron)
        IMAP-Monitoring
        Factro-Kommentar: "NA gestellt"
    end note

    note right of RUECKFRAGE
        NbResponseTask erstellen
        Auto-Resolve Pipeline
        Complaint-Parsing (GPT)
        Admin gibt Antwort frei
    end note

    note right of GENEHMIGT
        Auto-Rechnung erstellen
        HV-Provision berechnen
        Doppelte Buchfuehrung
        MaStR-Registrierung
    end note

    note right of FERTIG
        Rechnung finalisieren
        Wise-Zahlungs-Matching
        Factro: "PROJEKT VERKAUFT"
        Portal-Benachrichtigung
    end note
```

### 5.4 Deployment-Architektur

```mermaid
graph TB
    subgraph Server["Linux Server (Debian)"]
        subgraph PM2["PM2 Process Manager"]
            BE[gridnetz-backend<br/>ID 5, Port 3002<br/>Node.js + TypeScript]
            LECA[leca-backend<br/>NICHT ANFASSEN!]
        end

        subgraph DBs["Datenbanken"]
            MYSQL[(MySQL<br/>gridnetz_db<br/>~120 Models)]
            LECADB[(MySQL<br/>leca_db<br/>NUR LESEN!)]
            PG[(PostgreSQL 15<br/>gridnetz_vectors<br/>pgvector 0.8.0)]
        end

        subgraph Static["Statische Dateien"]
            FE[gridnetz-frontend<br/>/var/www/gridnetz-frontend/dist<br/>Vite Build]
            UPLOADS[Uploads<br/>/var/www/gridnetz-backend/uploads]
        end

        NGINX[NGINX<br/>Reverse Proxy<br/>HTTPS, SSL]
        OLLAMA[Ollama<br/>llama3.1:8b<br/>localhost:11434]
    end

    subgraph Cloud["Externe Cloud-Dienste"]
        OAI[OpenAI API]
        FACTRO[Factro Cloud]
        WISE[Wise API]
        WASS[Wassenger]
        VNBD[VNBdigital]
    end

    CLIENT[Browser / Electron] -->|HTTPS| NGINX
    NGINX -->|/api/*| BE
    NGINX -->|Static| FE
    BE --> MYSQL
    BE --> PG
    BE --> UPLOADS
    BE --> OLLAMA
    BE --> OAI
    BE --> FACTRO
    BE --> WISE
    BE --> WASS
    BE --> VNBD

    style LECA fill:#f99,stroke:#c00
    style LECADB fill:#f99,stroke:#c00
```

---

## 6. Technische Schulden

### Prioritaet KRITISCH

| # | Schuld | Auswirkung | Aufwand |
|---|--------|-----------|---------|
| T1 | Fehlende Rollen-Middleware auf Admin/Accounting/Rechnungen/Email-Routes | Privilege Escalation, Datenleck | S |
| T2 | Cron-Jobs ohne Error-Isolation (11 von ~20) | Server-Absturz bei Fehler | M |
| T3 | NB-Portal-Credentials ohne verifizierten Encryption-Service | Credential-Leak bei DB-Zugriff | M |
| T4 | Wise Webhook ohne Signatur-Verifizierung | Gefaelschte Zahlungen | S |
| T5 | Login ohne Rate-Limiting | Brute-Force moeglich | S |
| T6 | Token in Query-Parameter mit 1h Grace Period | Token-Leak | S |
| T7 | Race Condition bei Rechnungsnummer-Generierung | Doppelte Nummern | S |

### Prioritaet HOCH

| # | Schuld | Auswirkung | Aufwand |
|---|--------|-----------|---------|
| T8 | 6 verschiedene API-Clients im Frontend | Inkonsistentes Auth, Token-Leaks | L |
| T9 | 3 Installation-Detail-Versionen (v1, v2, Enterprise) | Feature-Drift, doppelter Wartungsaufwand | L |
| T10 | WorkflowV2 Dual-Write (Legacy ↔ V2 parallel) | Komplexitaet, Inkonsistenzen | L |
| T11 | Keine Test-Infrastruktur | Regression bei jeder Aenderung | L |
| T12 | Stille `.catch(() => {})` Bloecke | Unerkannte DB-Probleme | S |
| T13 | Doppelte Route-Pfade (3+ Konflikte) | Undefiniertes Verhalten | M |
| T14 | N+1 Query-Probleme in Listen-Endpoints | Langsame Responses | M |
| T15 | pgvector Pool ohne explizite Limits | Pool-Erschoepfung | S |

### Prioritaet MITTEL

| # | Schuld | Auswirkung | Aufwand |
|---|--------|-----------|---------|
| T16 | 4x StatusPill, 4x CommandPalette, 3x AdminLayout | UI-Inkonsistenz, Bundle-Bloat | M |
| T17 | 21+ verwaiste Frontend-Dateien + 6 unused DB-Models | Dead Code, Verwirrung | M |
| T18 | Duale Enum-Systeme (DE/EN) | Fehleranfaellig | L |
| T19 | Map-basierter Cache (kein LRU, kein Redis) | Memory-Leak, kein Multi-Instance | M |
| T20 | CompanySettings mit 120 Feldern | Unwartbar | L |
| T21 | Fehlende Request-Validierung (Zod kaum genutzt) | Ungueltige Daten in DB | L |
| T22 | Mixed Auth (JWT + Session parallel) | Erhoehte Angriffsflaeche | L |
| T23 | Fehlende Pagination bei einigen Endpoints | OOM bei grossen Daten | M |
| T24 | 3x Rechnungs-API im Frontend | Wartungshoelle | M |

### Prioritaet NIEDRIG

| # | Schuld | Auswirkung | Aufwand |
|---|--------|-----------|---------|
| T25 | Inkonsistente API-Pfade (Singular/Plural, fehlende Slashes) | DX-Problem | M |
| T26 | PDF-Generierung teils Client, teils Server | Doppelte Logik | L |
| T27 | Three.js im Haupt-Bundle | Grosse initiale Ladezeit | M |
| T28 | Kein OpenAPI/Swagger | Keine maschinenlesbare API-Doku | L |
| T29 | Mixed Logging (console.log + Pino) | Unstrukturierte Logs | M |
| T30 | Monolithische index.ts (~900 Zeilen) | Schwer wartbar | M |

---

## 7. Architektur-Schwaechen und bessere Patterns

### S1: Monolithische index.ts als God-File

**Problem:** `src/index.ts` (~900 Zeilen) enthaelt: Express-Setup, Route-Registrierung aller 96 Route-Dateien, Cron-Job-Setup (~20 Jobs), WebSocket-Init, Graceful Shutdown.

**Besseres Pattern:**
```
src/
  index.ts          ← Nur: Server-Start, Signal-Handling
  app.ts            ← Express-Setup, Middleware, CORS
  routes/index.ts   ← Route-Registrierung (automatisiert)
  cron/index.ts     ← Cron-Job-Registrierung mit Guards
  websocket.ts      ← WebSocket-Setup
```

```typescript
// src/routes/index.ts — Automatische Route-Registrierung
import { Router } from "express";
const routeModules = import.meta.glob("./routes/*.routes.ts", { eager: true });
export function registerRoutes(app: Express) {
  for (const [path, module] of Object.entries(routeModules)) {
    const basePath = extractBasePath(path);
    app.use(basePath, (module as any).default);
  }
}
```

### S2: Enge Service-Kopplung statt Event-Bus

**Problem:** Services rufen sich direkt gegenseitig auf. Eine Status-Aenderung triggert synchron: dualWrite → eventService → automationEngine → inboxItemFactory → brainEventHooks → provisionsService. Aenderung an einem Service erfordert Aenderungen an allen Konsumenten.

**Besseres Pattern:** Domain Events mit Event-Bus:
```typescript
// src/events/eventBus.ts
import { EventEmitter } from "events";
export const eventBus = new EventEmitter();

// In workflowV2/transitionService.ts
eventBus.emit("installation.statusChanged", { installationId, fromStatus, toStatus, userId });

// In autoInvoice.service.ts
eventBus.on("installation.statusChanged", async ({ installationId, toStatus }) => {
  if (toStatus === "GENEHMIGT") await generateInvoiceForInstallation(installationId);
});

// In brainEventHooks.ts
eventBus.on("installation.statusChanged", async (event) => {
  await trackInstallationStatusChanged(event);
});
```

Vorteile: Lose Kopplung, neue Features als Listener ohne Aenderung am Core.

### S3: Business-Logik in Route-Handlern

**Problem:** Viele Route-Handler enthalten direkte Prisma-Queries und Business-Logik statt Service-Aufrufe. Das macht Wiederverwendung und Testing unmoeglich.

**Besseres Pattern:** Strikte 3-Schichten:
```
Route (Controller) → Service → Repository (Prisma)
```

```typescript
// NICHT SO (aktuell):
router.post("/:id/status", authenticate, asyncHandler(async (req, res) => {
  const { status } = req.body;
  await prisma.installation.update({ where: { id: +req.params.id }, data: { status } });
  await prisma.statusHistory.create({ data: { ... } });
  // ...50 Zeilen Business-Logik...
  res.json({ success: true });
}));

// BESSER:
router.post("/:id/status", authenticate, validate(statusChangeSchema), asyncHandler(async (req, res) => {
  const result = await installationService.changeStatus(+req.params.id, req.body.status, req.user!);
  res.json(result);
}));
```

### S4: Fehlende Transaktionen bei kritischen Operationen

**Problem:** Mehrstufige Operationen (Rechnung + Provision + Journal) laufen ohne DB-Transaktion. Bei Fehler im Schritt 3 bleiben Schritte 1 und 2 bestehen → inkonsistenter Zustand.

**Besseres Pattern:**
```typescript
async function createInvoiceWithProvision(installationId: number) {
  return prisma.$transaction(async (tx) => {
    // Alles in einer Transaktion
    const counter = await tx.invoiceCounter.upsert({ ... });
    const rechnung = await tx.rechnung.create({ ... });
    const provision = await tx.provision.create({ ... });
    const journal = await tx.journalEntry.create({ ... });
    return rechnung;
  });
}
```

### S5: Horizontal-Scaling unmoeglich

**Problem:** In-Process Map-Caches, Session-State im Memory, Cron-Jobs im selben Prozess → nur Single-Instance-Deployment moeglich.

**Besseres Pattern:**
1. **Redis** fuer Cache + Sessions + Distributed Locks
2. **Cron-Jobs in separatem Worker-Prozess** (PM2 Cluster-Mode)
3. **Distributed Locks** fuer Cron-Jobs:
```typescript
import { Redlock } from "redlock";
const lock = await redlock.acquire(["cron:emailPoll"], 30000);
try { await pollEmails(); } finally { await lock.release(); }
```

### S6: Frontend-State-Management fragmentiert

**Problem:** Mix aus React Query, Zustand, Context-API und useState fuer verschiedene State-Typen. Kein klares Pattern wann was genutzt wird.

**Besseres Pattern:**
| State-Typ | Technologie | Beispiel |
|-----------|-------------|---------|
| Server-Daten | React Query | Installationen, Emails, Rechnungen |
| Globaler UI-State | Zustand | Sidebar-Status, Theme, aktives Modal |
| Auth/Theme Provider | Context | AuthProvider, WhiteLabelProvider |
| Formular-State | React Hook Form | Wizard, Erstell-Formulare |
| Lokaler UI-State | useState | Dropdown-offen, Tab-Index |

### S7: Keine API-Versionierung

**Problem:** Alle Endpoints unter `/api/...` ohne Version. Breaking Changes erfordern simultanes Frontend+Backend-Deployment.

**Besseres Pattern:**
```
/api/v1/installations/:id    ← Bestehende Endpoints
/api/v2/installations/:id    ← Neue Version mit Breaking Changes
```
Session-Auth (`/api/auth/v2`) ist bereits ein guter Ansatz.

### S8: Fehlende Observability

**Problem:** Kein zentrales Monitoring-Dashboard. Health-Checks nur intern (Slack). Kein `/health` oder `/ready` Endpoint. Keine Metriken (Request-Dauer, Error-Rate, DB-Pool-Auslastung).

**Besseres Pattern:**
```typescript
// Unprotected health endpoints
app.get("/health", (req, res) => res.json({ status: "ok", uptime: process.uptime() }));
app.get("/ready", async (req, res) => {
  const checks = {
    mysql: await prisma.$queryRaw`SELECT 1`.then(() => "ok").catch(() => "fail"),
    pgvector: await pgPool.query("SELECT 1").then(() => "ok").catch(() => "fail"),
  };
  const allOk = Object.values(checks).every(v => v === "ok");
  res.status(allOk ? 200 : 503).json(checks);
});

// Prometheus-kompatible Metriken
app.get("/metrics", authenticate, requireAdmin, (req, res) => {
  res.set("Content-Type", "text/plain");
  res.send(promClient.register.metrics());
});
```

---

## 8. Empfohlene Refactoring-Reihenfolge

### Phase 1: Sicherheit absichern (Woche 1)

| Schritt | Aufgabe | Aufwand | Referenz |
|---------|---------|---------|----------|
| 1 | Rollen-Middleware auf Admin/Accounting/Rechnungen/Email-Routes | S (3h) | T1 |
| 2 | Login Rate-Limiter anwenden | S (1h) | T5 |
| 3 | Wise Webhook Signatur-Check | S (1h) | T4 |
| 4 | Rechnungsnummer-Counter in Transaction | S (1h) | T7 |
| 5 | Query-Token Grace Period reduzieren (1h→5min) | S (1h) | T6 |
| 6 | Cron-Jobs mit withCronGuard() wrappen | M (3h) | T2 |
| 7 | NB-Credentials Encryption verifizieren/fixen | M (4-6h) | T3 |

### Phase 2: Stabilitaet verbessern (Wochen 2-3)

| Schritt | Aufgabe | Aufwand | Referenz |
|---------|---------|---------|----------|
| 8 | Stille .catch(() => {}) durch Logging ersetzen | S (2h) | T12 |
| 9 | Error-Boundaries um Feature-Module | S (3h) | — |
| 10 | pgvector Pool-Limits konfigurieren | S (1h) | T15 |
| 11 | Route-Konflikte aufloesen | M (4h) | T13 |
| 12 | N+1 Queries optimieren (top 5 Endpoints) | M (6h) | T14 |
| 13 | Fehlende Pagination ergaenzen | M (1 Tag) | T23 |

### Phase 3: Frontend konsolidieren (Wochen 4-6)

| Schritt | Aufgabe | Aufwand | Referenz |
|---------|---------|---------|----------|
| 14 | API-Client auf einen konsolidieren | L (2-3 Tage) | T8 |
| 15 | Dead Code entfernen (verwaiste Dateien) | M (4h) | T17 |
| 16 | Shared Components (StatusPill, CommandPalette) | M (2 Tage) | T16 |
| 17 | Rechnungs-API konsolidieren | M (6h) | T24 |

### Phase 4: Backend-Architektur (Wochen 7-12)

| Schritt | Aufgabe | Aufwand | Referenz |
|---------|---------|---------|----------|
| 18 | Test-Infrastruktur aufbauen (Vitest) | M (1 Tag) | T11 |
| 19 | Kritische Tests schreiben (Auth, Rechnungen, Status) | L (fortlaufend) | T11 |
| 20 | index.ts aufteilen (app.ts, cron.ts, ws.ts) | M (4h) | T30 |
| 21 | Request-Validierung (Zod) fuer kritische Endpoints | L (schrittweise) | T21 |
| 22 | Legacy DB-Tabellen entfernen | S (3h) | T17 |
| 23 | Event-Bus einfuehren (loose coupling) | M (1 Woche) | S2 |

### Phase 5: Langfristige Verbesserungen (Quartal 2)

| Schritt | Aufgabe | Aufwand | Referenz |
|---------|---------|---------|----------|
| 24 | Installation-Detail auf Enterprise konsolidieren | L (3-5 Tage) | T9 |
| 25 | WorkflowV2 finalisieren, Dual-Write entfernen | L (1-2 Wochen) | T10 |
| 26 | Redis einfuehren (Cache + Sessions) | L (1 Woche) | T19, S5 |
| 27 | Enum-Bereinigung (DE/EN) | L (3-5 Tage) | T18 |
| 28 | CompanySettings aufsplitten | L (2 Tage) | T20 |
| 29 | OpenAPI-Spec + Swagger-UI | L (3-5 Tage) | T28 |
| 30 | API-Versionierung einfuehren | L (1 Woche) | S7 |

---

## 9. Statistik

| Metrik | Wert |
|--------|------|
| **Backend** | |
| Route-Dateien | 96 |
| Geschaetzte Endpoints | ~500+ |
| Service-Bereiche | 14 Ordner + 40+ Root-Services |
| Cron-Jobs | ~20 (5min bis woechentlich) |
| DB Models (MySQL) | ~120 |
| DB Enums | ~35 |
| **Frontend** | |
| Dateien gesamt | ~822 |
| Pages | ~65 (Public: 14, Auth: 16, Staff: 20, Admin: 10, Portal: 9) |
| Feature-Module | 15 |
| API-Clients | 6 (Soll: 1) |
| **KI/RAG** | |
| RAG Embeddings (pgvector) | 25.314 |
| RAG Kategorien | 29 |
| Embedding-Modell | text-embedding-3-small (1536 Dim) |
| LLM Primary | OpenAI gpt-4o-mini |
| LLM Parallel | Ollama llama3.1:8b |
| **Integrationen** | |
| Externe APIs | 12+ |
| **Technische Schulden** | |
| KRITISCH | 7 |
| HOCH | 8 |
| MITTEL | 9 |
| NIEDRIG | 6 |
| Duplizierte Frontend-Bereiche | 8+ |
| Verwaiste Frontend-Dateien | 21+ |
| Unused DB-Models | 6+ |
