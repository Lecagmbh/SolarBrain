# GridNetz Portal - Verbesserungsvorschlaege

> Stand: 2026-03-11 | Basierend auf: schema-map.md, service-map.md, api-map.md, frontend-map.md
> Aktualisiert mit Code-Level-Analyse

---

## Inhaltsverzeichnis

1. [KRITISCH — Sicherheit, Datenverlust, Race Conditions](#1-kritisch)
2. [HOCH — Performance, stilles Versagen, Inkonsistenzen](#2-hoch)
3. [MITTEL — Code-Duplikation, fehlende Tests, API-Design](#3-mittel)
4. [NICE TO HAVE — Code-Style, Ordnerstruktur, Dokumentation](#4-nice-to-have)
5. [Zusammenfassung und empfohlene Reihenfolge](#5-zusammenfassung)

---

## 1. KRITISCH

### K1: Admin-User-Routes ohne requireAdmin

**Problem:** `adminUsers.routes.ts` Endpoints (`GET /api/admin/users`, `POST`, `PATCH /:id`, `POST /:id/reset-password`, `DELETE /:id`) verwenden nur `authenticate` ohne `requireAdmin`/`requireStaff`. Rollen-Checks sind teils inline im Handler, aber nicht konsistent.

**Betroffene Dateien:**
- `/var/www/gridnetz-backend/src/routes/adminUsers.routes.ts`

**Ist:**
```typescript
router.get("/simple", authenticate, asyncHandler(...));
router.post("/", authenticate, asyncHandler(...));
router.post("/:id/reset-password", authenticate, asyncHandler(...));
```

**Soll:**
```typescript
// Alle Admin-User-Routes absichern
router.use(authenticate, requireAdmin);
router.get("/simple", asyncHandler(...));
router.post("/", asyncHandler(...));
router.post("/:id/reset-password", asyncHandler(...));
```

**Risiko:** Privilege Escalation — KUNDE oder SUBUNTERNEHMER koennte User anlegen/loeschen.
**Aufwand:** S (15 Min)

---

### K2: Accounting-Routes ohne Rollen-Check

**Problem:** Saemtliche ~40 Accounting-Endpoints (`/api/accounting/*`) nutzen nur `[AUTH]`. Jeder eingeloggte Benutzer (KUNDE, SUBUNTERNEHMER, DEMO) kann Konten erstellen, Buchungen anlegen, Jahresabschluesse durchfuehren, Steuer-Pakete herunterladen, GuV und Bilanzen einsehen.

**Betroffene Dateien:**
- `/var/www/gridnetz-backend/src/routes/accounting.routes.ts`
- `/var/www/gridnetz-backend/src/routes/accountingAI.routes.ts`

**Ist:**
```typescript
router.get("/accounts", authenticate, asyncHandler(async (req, res) => { ... }));
router.post("/year-end/close:year", authenticate, asyncHandler(async (req, res) => { ... }));
```

**Soll:**
```typescript
// Lesend: requireStaff, Schreibend: requireAdmin
router.get("/accounts", authenticate, requireStaff, asyncHandler(...));
router.post("/year-end/close:year", authenticate, requireAdmin, asyncHandler(...));
```

**Risiko:** Datenschutz-Verstoss (Kunden sehen Finanzdaten), Manipulation von Buchungsdaten.
**Aufwand:** S (1h)

---

### K3: Rechnungs-Endpoints ohne Rollen-Pruefung

**Problem:** Viele Rechnungs-Endpoints (`POST /`, `POST /:id/finalize`, `POST /:id/mark-paid`, `DELETE /:id`, `POST /:id/storno`, `POST /batch-create`) verwenden nur `[AUTH]`.

**Betroffene Dateien:**
- `/var/www/gridnetz-backend/src/routes/rechnung.routes.ts`

**Ist:**
```typescript
router.post("/", authenticate, asyncHandler(async (req, res) => { ... }));
router.delete("/:id", authenticate, asyncHandler(async (req, res) => { ... }));
router.post("/:id/storno", authenticate, asyncHandler(async (req, res) => { ... }));
```

**Soll:**
```typescript
router.post("/", authenticate, requireStaff, asyncHandler(...));
router.delete("/:id", authenticate, requireAdmin, asyncHandler(...));
router.post("/:id/storno", authenticate, requireAdmin, asyncHandler(...));
```

**Risiko:** Kunden koennten Rechnungen loeschen oder Status manipulieren.
**Aufwand:** S (1h)

---

### K4: Email-Inbox ohne Rollen-Check

**Problem:** Alle ~25 Email-Inbox-Endpoints verwenden nur `[AUTH]`. Kunden und Subunternehmer koennten alle Emails einsehen, loeschen, archivieren und Auto-Replies genehmigen.

**Betroffene Dateien:**
- `/var/www/gridnetz-backend/src/routes/emailInbox.routes.ts`

**Soll:** `router.use(authenticate, requireStaff)` am Router-Anfang.

**Risiko:** Unbefugter Zugriff auf vertrauliche NB-Korrespondenz.
**Aufwand:** S (30 Min)

---

### K5: Cron-Jobs ohne Error-Isolation

**Problem:** Ca. 11 Cron-Jobs in `index.ts` verwenden einfache `async () => {}` Callbacks ohne `withCronGuard()`. Unbehandelte Promise-Rejections koennen den Node.js-Prozess zum Absturz bringen.

**Betroffene Dateien:**
- `/var/www/gridnetz-backend/src/index.ts` (Zeile ~568-890)

**Ist:**
```typescript
cron.schedule("*/5 * * * *", async () => {
  await someService.run(); // Kein try/catch, kein Guard
});
```

**Soll:**
```typescript
cron.schedule("*/5 * * * *", withCronGuard("someJob", async () => {
  await someService.run();
}));

function withCronGuard(name: string, fn: () => Promise<void>) {
  return async () => {
    const start = Date.now();
    try {
      log.info({ job: name }, "Cron started");
      await fn();
      log.info({ job: name, durationMs: Date.now() - start }, "Cron completed");
    } catch (err) {
      log.error({ err, job: name, durationMs: Date.now() - start }, "Cron failed");
      captureError(err, { cron: name });
    }
  };
}
```

**Risiko:** Server-Absturz durch unbehandelte Rejection. Keine Sichtbarkeit bei Cron-Fehlern.
**Aufwand:** M (2-3h)

---

### K6: NB-Portal-Credentials ohne verifizierbaren Encryption-Service

**Problem:** `NetzbetreiberCredential.passwordEnc` suggeriert Verschluesselung, aber es gibt keinen zentralen Encryption-Service. Die Proxy-Services nutzen Credentials direkt.

**Betroffene Dateien:**
- `/var/www/gridnetz-backend/prisma/schema.prisma` (Model `NetzbetreiberCredential`)
- `/var/www/gridnetz-backend/src/services/nbPortalProxy/proxyService.ts`

**Ist:**
```prisma
model NetzbetreiberCredential {
  passwordEnc String   // Unklar: Base64? AES? Klartext?
}
```

**Soll:**
```typescript
// src/services/encryption.service.ts
import crypto from "crypto";

const ALGORITHM = "aes-256-gcm";
const KEY = Buffer.from(process.env.ENCRYPTION_KEY!, "hex"); // 32 Bytes

export function encrypt(plaintext: string): { ciphertext: string; iv: string; tag: string } {
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv(ALGORITHM, KEY, iv);
  let ciphertext = cipher.update(plaintext, "utf8", "hex");
  ciphertext += cipher.final("hex");
  return { ciphertext, iv: iv.toString("hex"), tag: cipher.getAuthTag().toString("hex") };
}

export function decrypt(ciphertext: string, iv: string, tag: string): string {
  const decipher = crypto.createDecipheriv(ALGORITHM, KEY, Buffer.from(iv, "hex"));
  decipher.setAuthTag(Buffer.from(tag, "hex"));
  let plaintext = decipher.update(ciphertext, "hex", "utf8");
  plaintext += decipher.final("utf8");
  return plaintext;
}
```

**Risiko:** Bei DB-Leak sind NB-Portal-Zugangsdaten kompromittiert.
**Aufwand:** M (4-6h) — Encryption-Service, Migration bestehender Daten, Tests.

---

### K7: Race Condition bei Rechnungsnummer-Generierung

**Problem:** `invoice_counters` nutzt `key=YYYYMM` mit `next`-Counter. Ohne DB-Transaction-Lock bei gleichzeitigen Requests koennen doppelte Nummern entstehen (→ P2002 Unique Constraint Error, fehlgeschlagene Rechnung).

**Betroffene Dateien:**
- `/var/www/gridnetz-backend/src/services/autoInvoice.service.ts`

**Ist (vermutetes Pattern):**
```typescript
const counter = await prisma.invoiceCounter.findUnique({ where: { key: monthKey } });
const next = (counter?.next || 1);
await prisma.invoiceCounter.update({ where: { key: monthKey }, data: { next: next + 1 } });
// → Zeitfenster zwischen read und update = Race Condition
```

**Soll:**
```typescript
const result = await prisma.$transaction(async (tx) => {
  const counter = await tx.invoiceCounter.upsert({
    where: { key: monthKey },
    create: { key: monthKey, next: 2 },
    update: { next: { increment: 1 } },
  });
  return counter.next - 1; // Atomare Operation
});
```

**Risiko:** Doppelte Rechnungsnummern, fehlgeschlagene Rechnungserstellung.
**Aufwand:** S (1-2h)

---

### K8: Wise Webhook ohne Signatur-Verifizierung

**Problem:** `POST /api/wise/webhook/:accountId` ist `[PUBLIC]`. Ohne Webhook-Signatur-Verifizierung koennen gefaelschte Zahlungseingaenge gebucht werden.

**Betroffene Dateien:**
- `/var/www/gridnetz-backend/src/routes/wise.routes.ts`

**Ist:**
```typescript
router.post("/webhook/:accountId", asyncHandler(async (req, res) => {
  // Direkte Verarbeitung ohne Verifizierung
}));
```

**Soll:**
```typescript
function verifyWiseSignature(req: Request, res: Response, next: NextFunction) {
  const signature = req.headers["x-signature-sha256"];
  const payload = JSON.stringify(req.body);
  const expected = crypto.createHmac("sha256", WISE_WEBHOOK_SECRET).update(payload).digest("hex");
  if (signature !== expected) return res.status(401).json({ error: "Invalid signature" });
  next();
}

router.post("/webhook/:accountId", verifyWiseSignature, asyncHandler(async (req, res) => { ... }));
```

**Risiko:** Finanzieller Schaden durch gefaelschte Zahlungsbestaetigung.
**Aufwand:** S (1-2h)

---

### K9: Token in Query-Parameter mit 1h Grace Period

**Problem:** Auth-Middleware erlaubt JWT-Tokens ueber `?token=...` mit 1-Stunden-Grace-Period nach Ablauf. Query-Tokens landen in Server-Logs, Browser-Historie, Referrer-Headers.

**Betroffene Dateien:**
- `/var/www/gridnetz-backend/src/middleware/auth.ts` (Zeile 91-129)

**Ist:**
```typescript
if (!token && req.query.token) {
  token = String(req.query.token);
}
// Spaeter: 1h Grace Period fuer abgelaufene Query-Tokens
const MAX_GRACE_MS = 60 * 60 * 1000;
```

**Soll:**
```typescript
// Grace Period auf 5 Min reduzieren
const MAX_GRACE_MS = 5 * 60 * 1000;

// Query-Token nur fuer explizite Download-Routes erlauben
const ALLOWED_QUERY_TOKEN_PATHS = ["/api/rechnungen/", "/api/documents/"];
if (req.query.token && !ALLOWED_QUERY_TOKEN_PATHS.some(p => req.path.startsWith(p))) {
  throw new ApiError(401, "Token in URL nicht erlaubt fuer diesen Endpoint");
}
```

**Risiko:** Token-Leak via Server-Logs, Browser-Historie, Referrer-Headers.
**Aufwand:** S (1-2h)

---

### K10: Terminal WebSocket ohne ausreichende Haertung

**Problem:** Terminal-WebSocket-Service bietet SSH-Shell im Browser. JWT-Validierung existiert, aber es fehlen: Rate-Limiting, Command-Audit-Log, Session-Timeout, zusaetzliche 2FA-Validierung.

**Betroffene Dateien:**
- `/var/www/gridnetz-backend/src/services/terminalWebSocket.ts`

**Soll:** Admin-only + 2FA-Pflicht. Audit-Log aller Befehle. Session-Timeout (10 Min Inaktivitaet). Input-Laengen-Limit.

**Risiko:** Vollzugriff auf Server bei kompromittiertem Admin-Token.
**Aufwand:** L (1-2 Tage)

---

### K11: Login-Endpoints ohne Rate-Limiter

**Problem:** `/api/auth/login` und `/api/auth/v2/login` haben keinen dedizierten Rate-Limiter. `LoginAttempt`-Tracking existiert, aber kein automatisches IP-Blocking. Auch `/api/auth/forgot-password` ist ungeschuetzt gegen Enumeration.

**Betroffene Dateien:**
- `/var/www/gridnetz-backend/src/routes/auth.routes.ts`
- `/var/www/gridnetz-backend/src/routes/auth.session.routes.ts`
- `/var/www/gridnetz-backend/src/middleware/rateLimiter.ts` (vorhanden)

**Ist:**
```typescript
router.post("/login", asyncHandler(async (req, res) => { ... }));
```

**Soll:**
```typescript
import { loginLimiter } from "../middleware/rateLimiter.js";
// Max 5 Versuche pro IP in 15 Min, danach 15 Min Sperre
router.post("/login", loginLimiter, asyncHandler(async (req, res) => { ... }));
router.post("/forgot-password", loginLimiter, asyncHandler(async (req, res) => { ... }));
```

**Risiko:** Brute-Force-Angriffe auf Accounts.
**Aufwand:** S (1h) — `rateLimiter.ts` existiert bereits, nur anwenden.

---

## 2. HOCH

### H1: 6 verschiedene API-Clients im Frontend

**Problem:** 6 HTTP-Client-Implementierungen mit unterschiedlichem Auth-, Error-, und Retry-Verhalten. `lib/api.ts` hat KEINEN Auth-Header (nutzt fragilen globalen fetch-Interceptor).

**Betroffene Dateien:**
- `/var/www/gridnetz-frontend/src/api/client.ts` (Primary, Fetch)
- `/var/www/gridnetz-frontend/src/api/api.ts` (Axios, Legacy)
- `/var/www/gridnetz-frontend/src/modules/api/client.ts` (Axios + CSRF)
- `/var/www/gridnetz-frontend/src/services/apiClient.ts` (Minimaler Fetch)
- `/var/www/gridnetz-frontend/src/lib/api.ts` (Legacy Fetch, KEIN Auth-Header!)
- `/var/www/gridnetz-frontend/src/features/netzanmeldungen/services/api.ts` (Eigener Client)

**Ist:**
```
6 Clients → 6 verschiedene Verhaltensweisen bei 401, Retry, Token-Refresh
lib/api.ts nutzt globalen window.fetch Monkey-Patch → fragil, schwer zu debuggen
```

**Soll:**
```typescript
// src/api/client.ts — Einziger Client
export const apiClient = {
  async request<T>(url: string, options?: RequestInit): Promise<T> {
    const token = getAccessToken();
    const headers = { "Content-Type": "application/json", ...(token && { Authorization: `Bearer ${token}` }) };
    const res = await fetch(`${API_BASE}${url}`, { ...options, headers, credentials: "include" });
    if (res.status === 401) { await refreshToken(); return apiClient.request(url, options); }
    if (!res.ok) throw new ApiError(res.status, await res.text());
    return res.json();
  },
  get: <T>(url: string) => apiClient.request<T>(url),
  post: <T>(url: string, body: unknown) => apiClient.request<T>(url, { method: "POST", body: JSON.stringify(body) }),
  // ...
};
```

**Risiko:** Inkonsistentes Auth-Verhalten, fehlende Token-Erneuerung, ungeschuetzte Requests.
**Aufwand:** L (2-3 Tage, schrittweiser Umbau)

---

### H2: Stilles Versagen bei fire-and-forget Prisma-Calls

**Problem:** Diverse `.catch(() => {})` Bloecke verschlucken Fehler komplett. Session-Activity-Updates, Audit-Logs und andere Side-Effects versagen unbemerkt.

**Betroffene Dateien:**
- `/var/www/gridnetz-backend/src/middleware/auth.ts` (Zeile 58, 64)
- Vermutlich weitere Services mit gleichem Pattern

**Ist:**
```typescript
prisma.userSession.update({ where: { id: session.id }, data: { isValid: false } }).catch(() => {});
prisma.userSession.update({ where: { id: session.id }, data: { lastActivity: now } }).catch(() => {});
```

**Soll:**
```typescript
prisma.userSession.update({ where: { id: session.id }, data: { isValid: false } })
  .catch((err) => log.warn({ err, sessionId: session.id }, "Session-Invalidierung fehlgeschlagen"));
prisma.userSession.update({ where: { id: session.id }, data: { lastActivity: now } })
  .catch((err) => log.debug({ err, sessionId: session.id }, "Activity-Update fehlgeschlagen"));
```

**Risiko:** Unerkannte DB-Probleme, Sessions werden nicht korrekt invalidiert.
**Aufwand:** S (1-2h) — Globaler Grep nach `.catch(() =>` und Logging ergaenzen.

---

### H3: Doppelte Route-Pfade / Route-Konflikte

**Problem:** Mehrere Route-Dateien registrieren identische Pfade:
- `installationsMeta.routes.ts` UND `installationsNbCase.routes.ts` → `PATCH /:id/nb-case`
- `netzanmeldungen.enterprise.routes.ts` UND `installation.routes.ts` → `GET /:id`
- Enterprise-Routes werden VOR Legacy gemountet → Enterprise gewinnt, Legacy ist toter Code

**Betroffene Dateien:**
- `/var/www/gridnetz-backend/src/routes/installationsMeta.routes.ts`
- `/var/www/gridnetz-backend/src/routes/installationsNbCase.routes.ts`
- `/var/www/gridnetz-backend/src/routes/netzanmeldungen.enterprise.routes.ts`
- `/var/www/gridnetz-backend/src/routes/installation.routes.ts`

**Soll:** Doppelte Routes konsolidieren. Legacy-Routes explizit als `/legacy/` kennzeichnen oder entfernen.

**Risiko:** Undefiniertes Verhalten bei Route-Matching, verwirrende Debugging-Erfahrung.
**Aufwand:** M (3-4h)

---

### H4: Fehlende Error-Boundaries in Frontend-Features

**Problem:** Nur globaler `ErrorBoundary` in `main.tsx`. Features (Netzanmeldungen ~120 Dateien, Email-Center, Factro-Center) haben keine eigenen. Ein Rendering-Fehler in einem Tab crasht die gesamte Seite.

**Betroffene Dateien:**
- `/var/www/gridnetz-frontend/src/features/netzanmeldungen/NetzanmeldungenEnterprise.tsx`
- `/var/www/gridnetz-frontend/src/features/control-center/components/ControlCenterPage.tsx`
- `/var/www/gridnetz-frontend/src/main.tsx`

**Ist:**
```tsx
<ErrorBoundary> {/* Nur global */}
  <App />
</ErrorBoundary>
```

**Soll:**
```tsx
import { ErrorBoundary } from "react-error-boundary";

function FeatureErrorFallback({ feature }: { feature: string }) {
  return <div className="p-8 text-center text-red-500">
    <h2>Fehler in {feature}</h2>
    <button onClick={() => window.location.reload()}>Seite neu laden</button>
  </div>;
}

// In router.tsx pro Feature
<ErrorBoundary fallback={<FeatureErrorFallback feature="Netzanmeldungen" />}>
  <NetzanmeldungenEnterprise />
</ErrorBoundary>
```

**Risiko:** Full-Page-Crash durch einzelnen Feature-Bug.
**Aufwand:** S (2-3h)

---

### H5: N+1 Query-Problem bei Listen-Endpoints

**Problem:** Listen-Endpoints laden Hauptentitaeten und machen dann pro Eintrag separate DB-Calls fuer Relations/Counts. Prisma `include` und `_count` werden inkonsistent genutzt.

**Betroffene Dateien:**
- `/var/www/gridnetz-backend/src/routes/installation.routes.ts`
- `/var/www/gridnetz-backend/src/routes/netzanmeldungen.enterprise.routes.ts`
- Diverse Services die findMany + Loop-Queries nutzen

**Ist (typisches Pattern):**
```typescript
const installations = await prisma.installation.findMany({ where: { ... } });
for (const inst of installations) {
  inst.documentCount = await prisma.document.count({ where: { installationId: inst.id } });
  inst.kunde = await prisma.kunde.findUnique({ where: { id: inst.kundeId } });
}
```

**Soll:**
```typescript
const installations = await prisma.installation.findMany({
  where: { ... },
  include: {
    _count: { select: { documents: true, comments: true, tasks: true } },
    kunde: { select: { id: true, name: true } },
    netzbetreiber: { select: { id: true, name: true } },
  },
});
```

**Risiko:** Langsame Response-Zeiten bei wachsender Datenmenge, hohe DB-Last.
**Aufwand:** M (4-6h) — Betroffene Endpoints identifizieren und optimieren.

---

### H6: Fehlende Pagination bei grossen Abfragen

**Problem:** Einige Abfragen nutzen `findMany()` ohne `take`/`skip`. Bei wachsender Datenmenge → OOM, >5s Responses.

**Betroffene Dateien:**
- Diverse Route-Handler die `prisma.*.findMany()` ohne Limit aufrufen
- Besonders: Email-Listen, TrackingEvents, Audit-Logs, RAG-Query-Logs

**Soll:** Alle List-Endpoints mit Pagination (default: 25, max: 200). Cursor-basiert fuer Tabellen >10K Rows.

**Aufwand:** M (1-2 Tage)

---

### H7: pgvector Connection-Pool ohne explizite Limits

**Problem:** pgvector-Pool (PostgreSQL fuer RAG) nutzt vermutlich Default-Settings (max 10). Auto-Reindex alle 60 Min + parallele RAG-Queries koennen Pool erschoepfen → haengende Requests.

**Betroffene Dateien:**
- `/var/www/gridnetz-backend/src/services/rag/embeddingService.ts`
- `/var/www/gridnetz-backend/src/services/rag/indexingService.ts`
- `/var/www/gridnetz-backend/src/services/rag/enterpriseRagService.ts`

**Soll:**
```typescript
const pool = new Pool({
  connectionString: process.env.PGVECTOR_URL,
  max: 5,
  connectionTimeoutMillis: 5000,
  idleTimeoutMillis: 30000,
});
// Separater Pool fuer Reindex-Jobs mit max: 2
```

**Risiko:** Haengende RAG-Queries, Timeout-Kaskade.
**Aufwand:** S (1-2h)

---

### H8: CompanySettings als God-Object (120 Felder)

**Problem:** `CompanySettings` hat ~120 Felder in einem Singleton (id=1). Jede Aenderung fuehrt zu vollstaendigem Row-Update. Unwartbar bei steigendem Feature-Umfang.

**Betroffene Dateien:**
- `/var/www/gridnetz-backend/prisma/schema.prisma` (Model `CompanySettings`)

**Ist:**
```prisma
model CompanySettings {
  id Int @id @default(1)
  // ~120 Felder: Firma, Bank, SMTP, IMAP, Rechnungen, Integrationen, Features ...
}
```

**Soll:** Aufsplitten in kategorisierte Settings oder Key-Value-Store:
```prisma
model SystemSetting {
  id       Int    @id @default(autoincrement())
  category String // "email", "billing", "integrations", "security"
  key      String
  value    Json
  @@unique([category, key])
}
```

**Risiko:** Schema wird mit jedem Feature groesser, Migrationen bei jeder neuen Einstellung.
**Aufwand:** L (1-2 Tage)

---

### H9: Map-basierter Cache ohne LRU/Monitoring

**Problem:** Zentraler CacheService (100 Entries), plus Feature-eigene `Map()`-Caches (VNBdigital: 500 Entries, 24h TTL). Kein LRU-Eviction, kein Monitoring, keine Invalidierung bei DB-Aenderungen.

**Betroffene Dateien:**
- `/var/www/gridnetz-backend/src/services/cacheService.ts`
- `/var/www/gridnetz-backend/src/services/vnbdigital.service.ts` (eigener Cache)

**Soll:** Zentraler Cache-Service (oder Redis) mit LRU, konfigurierbarem TTL, Metriken.

**Aufwand:** M (3-4h fuer LRU-Upgrade, L fuer Redis-Migration)

---

### H10: Verwaiste Dateien und toter Code

**Problem:** Funktional toter Code erhoet Bundle-Groesse und verwirrt Entwickler:
- `src/App.tsx` — Verwaist (main.tsx baut eigene Provider-Struktur)
- `src/services/installationsDelete.ts` — Nirgendwo importiert
- `src/services/installationsUpdate.ts` — Nirgendwo importiert
- `src/services/anlagen.service.ts` — Nirgendwo importiert
- `ActivityLog` Model — UNUSED, Duplikat von AuditLog
- Legacy PV*SOL-Tabellen: `WechselrichterPvsol`, `SpeicherPvsol`, `BatterieSystemRaw`
- `Batteriesystem` Model — Standalone ohne FK-Relationen

**Betroffene Dateien:**
- `/var/www/gridnetz-frontend/src/App.tsx`
- `/var/www/gridnetz-frontend/src/services/installationsDelete.ts`
- `/var/www/gridnetz-frontend/src/services/installationsUpdate.ts`
- `/var/www/gridnetz-frontend/src/services/anlagen.service.ts`
- `/var/www/gridnetz-backend/prisma/schema.prisma` (6+ Models)

**Soll:** Toten Code entfernen. Unused DB-Tabellen per Migration droppen (nach Backup).

**Aufwand:** M (3-4h) — Dateien loeschen, Schema-Migration erstellen.

---

## 3. MITTEL

### M1: 3-fache Installation-Detail-Implementierung

**Problem:** Drei verschiedene Versionen der Installation-Detail-Ansicht mit je eigenen API-Calls, State-Management, Tabs und Styling.

**Betroffene Dateien:**
- `/var/www/gridnetz-frontend/src/modules/installations/detail/` (v1, ~20 Dateien)
- `/var/www/gridnetz-frontend/src/modules/installations/detail-v2/` (v2, ~15 Dateien)
- `/var/www/gridnetz-frontend/src/features/netzanmeldungen/components/DetailModal/` (Enterprise, ~30 Dateien)

**Soll:** Enterprise-Version als einzige beibehalten. V1 und V2 entfernen. Shared Components extrahieren.

**Aufwand:** L (3-5 Tage)

---

### M2: 4-fache StatusPill + weitere Komponenten-Duplikate

**Problem:** Zahlreiche UI-Komponenten existieren 3-4 Mal:

| Komponente | Instanzen |
|------------|-----------|
| StatusPill | 4 (ui/, DashboardV2/, netzanmeldungen/DashboardV2/, ZaehlerwechselCenter/) |
| TopBar | 3 (layout/, DashboardV2/, netzanmeldungen/DashboardV2/) |
| CommandPalette | 4 (features/, finanzen-module/, installations/detail-v2/, dashboard/) |
| AdminLayout | 3 (components/layout/, layout/, modules/layout/) |
| WorkflowPipeline | 3 (components/workflow/, components/, control-center/) |
| RequireAuth | 2 (pages/, modules/auth/) |
| AuthContext | 3 (pages/, modules/auth/, netzanmeldungen/contexts/) |
| Toast | 2 (modules/ui/toast/, netzanmeldungen/components/) |

**Soll:** Shared-Component-Library unter `src/shared/ui/` mit strenger Import-Policy. ESLint-Regel gegen Feature-interne UI-Duplikate.

**Aufwand:** M (1-2 Tage) pro Komponenten-Gruppe

---

### M3: 3-fache Rechnungs-API im Frontend

**Problem:** Drei separate API-Module fuer Rechnungen mit unterschiedlichen Interfaces.

**Betroffene Dateien:**
- `/var/www/gridnetz-frontend/src/services/rechnungen.service.ts`
- `/var/www/gridnetz-frontend/src/finanzen-module/api.ts`
- `/var/www/gridnetz-frontend/src/modules/rechnungen/api.ts`

**Soll:** Ein einziger Rechnungs-API-Service mit React Query Hooks (`useInvoices`, `useCreateInvoice` etc.).

**Aufwand:** M (4-6h)

---

### M4: Doppelte Enum-Systeme (Deutsch + Englisch)

**Problem:** Parallele Enums fuer gleiche Konzepte:
- `TaskStatus` (EN) vs. `AufgabenStatus` (DE)
- `TaskPriority` (EN) vs. `AufgabenPrioritaet` (DE)
- `DocumentKategorie` vs. `DokumentKategorie`
- `ProduktTyp` (DE) vs. `ProductType` (EN)

**Betroffene Dateien:**
- `/var/www/gridnetz-backend/prisma/schema.prisma`

**Soll:** Langfristig ein einheitliches Enum-Set (Empfehlung: Englisch). Mapping-Layer fuer deutsche UI-Texte.

**Aufwand:** L (3-5 Tage) — Viele Abhaengigkeiten, DB-Migration erforderlich.

---

### M5: Fehlende Request-Validierung

**Problem:** Die meisten Route-Handler nehmen `req.body` direkt ohne Schema-Validierung. `validate.ts` Middleware existiert, wird aber kaum genutzt.

**Betroffene Dateien:**
- `/var/www/gridnetz-backend/src/middleware/validate.ts` (vorhanden, kaum genutzt)
- Alle Route-Dateien unter `/var/www/gridnetz-backend/src/routes/`

**Ist:**
```typescript
router.post("/", authenticate, asyncHandler(async (req, res) => {
  const { name, email } = req.body; // Keine Validierung!
  const kunde = await prisma.kunde.create({ data: { name, email } });
}));
```

**Soll:**
```typescript
import { z } from "zod";
import { validate } from "../middleware/validate.js";

const createKundeSchema = z.object({
  name: z.string().min(2).max(100),
  email: z.string().email().optional(),
});

router.post("/", authenticate, validate(createKundeSchema), asyncHandler(async (req, res) => {
  const data = req.validatedBody; // Typsicher
}));
```

**Aufwand:** L (3-5 Tage) — Schrittweise Zod-Schemas fuer kritische Endpoints.

---

### M6: Keine Unit-/Integration-Tests

**Problem:** Weder Backend noch Frontend haben erkennbare Test-Infrastruktur. Kein `jest.config`, kein `vitest.config`, keine `*.test.ts`-Dateien. Bei 120 Models, 96 Route-Dateien, ~120 Frontend-Feature-Dateien ein erhebliches Regressionsrisiko.

**Soll:** Vitest fuer Backend + Frontend. Mindest-Coverage fuer:
- Auth-Flow (JWT + Session)
- Rechnungs-Erstellung (Counter, Nummernformat)
- Status-Transitionen (WorkflowV2)
- Rollen-Middleware
- Email-Pipeline (Klassifikation)
- Provisions-Berechnung

**Aufwand:** L (fortlaufend) — Setup 4h, dann 2-4h pro Feature.

---

### M7: WorkflowV2 Dual-Write vereinfachen

**Problem:** Legacy-Status und V2-Phase/Zustand werden parallel geschrieben. Feature-Flags steuern welches System aktiv ist. Erhoehte Komplexitaet und Fehleranfaelligkeit.

**Betroffene Dateien:**
- `/var/www/gridnetz-backend/src/services/workflowV2/dualWrite.ts`
- `/var/www/gridnetz-backend/src/services/workflowV2/statusMapping.ts`

**Soll:** Migration zu WorkflowV2 abschliessen, Legacy-Status-Felder entfernen, Dual-Write-Layer entfernen.

**Aufwand:** L (1-2 Wochen)

---

### M8: Inkonsistente API-Pfad-Konventionen

**Problem:** Gemischte Patterns:
- `/api/accounts:id` statt `/api/accounts/:id` (fehlender Slash)
- `/api/installations` (Plural) vs. `/api/installation/:id/send-email` (Singular)
- Deutsch: `/api/rechnungen`, `/api/kunden` vs. Englisch: `/api/installations`, `/api/documents`

**Betroffene Dateien:**
- `/var/www/gridnetz-backend/src/routes/accounting.routes.ts`
- `/var/www/gridnetz-backend/src/routes/emailSend.routes.ts`
- `/var/www/gridnetz-backend/src/routes/rechnung.routes.ts`

**Soll:** Einheitlich: Plural, immer mit `/:id`, eine Sprachentscheidung.
```
GET    /api/accounts/:id      (nicht /accounts:id)
GET    /api/netzbetreiber?plz=... (nicht /by-plz:plz)
POST   /api/installations/:id/send-email (nicht /installation/:id/...)
```

**Aufwand:** M (1 Tag) — API-Versioning empfohlen.

---

### M9: Mixed Auth-Strategien (JWT + Session)

**Problem:** Backend unterstuetzt gleichzeitig JWT + Session-Cookie-Auth. Einige Routes: `authenticate` (JWT + Cookie-Fallback), andere: `authenticateSession` (nur Cookie). Frontend: globaler fetch-Interceptor fuer Bearer + `credentials: include`.

**Betroffene Dateien:**
- `/var/www/gridnetz-backend/src/middleware/auth.ts` (JWT + Session)
- `/var/www/gridnetz-backend/src/middleware/session.ts` (Session-only)

**Soll:** Langfristig auf eine Strategie konsolidieren (Session-Cookies empfohlen). Kurzfristig: Dokumentation welche Routes welche Auth erwarten.

**Aufwand:** L (3-5 Tage)

---

### M10: Fehlende Rate-Limits auf nicht-AI-Endpoints

**Problem:** `aiLimiter` existiert fuer AI-Endpoints, aber kein generelles Rate-Limiting fuer Rechnungs-Erstellung, Email-Versand, Bulk-Operationen.

**Soll:** Globaler Rate-Limiter (100 req/min pro User). Strengere Limits fuer sensible Endpoints (Email-Versand: 10/min, Bulk-Ops: 5/min).

**Aufwand:** M (3-4h)

---

## 4. NICE TO HAVE

### N1: Frontend-Ordnerstruktur vereinheitlichen

**Problem:** 6+ verschiedene Top-Level-Verzeichnisse: `pages/`, `modules/`, `features/`, `components/`, `admin-center/`, `portal/`, `finanzen-module/`, `wizard/`. Kein einheitliches Muster.

**Soll:** Konsequente Feature-basierte Architektur:
```
src/
  features/
    installations/     (Pages, Components, Hooks, API, Types)
    rechnungen/        (aktuell: finanzen-module/ + modules/rechnungen/)
    accounting/
    auth/              (aktuell: pages/ + modules/auth/)
    portal/
    ...
  shared/
    ui/                (Button, Modal, Tabs, StatusPill)
    hooks/
    api/               (Einziger Client)
    utils/
```

**Aufwand:** L (fortlaufend, schrittweises Refactoring)

---

### N2: TypeScript-Typen fuer JSON-Felder

**Problem:** `technicalData`, `wizardContext`, `whiteLabelConfig`, `plzBereiche` etc. sind als `Json` definiert. Frontend muss raten was drinsteckt.

**Soll:** Shared Types fuer alle JSON-Felder:
```typescript
// shared/types/installation.ts
export interface TechnicalData {
  totalPvKwPeak: number;
  moduleCount: number;
  inverterModel: string;
  batteryCapacityKwh?: number;
}
```

**Aufwand:** M (1-2 Tage)

---

### N3: Magische Zahlen und Strings extrahieren

**Problem:** Hartcodierte Werte: Cache TTLs, Offsets (17000 fuer Rechnungsnr.), Grace Periods, Max-Entries.

**Soll:** Zentrale Konstanten-Datei:
```typescript
// src/constants/config.ts
export const CACHE = { DEFAULT_TTL_MS: 3600000, MAX_ENTRIES: 100 } as const;
export const INVOICE = { NUMBER_OFFSET: 17000, BASE: 36 } as const;
export const AUTH = { QUERY_TOKEN_GRACE_MS: 300000, SESSION_INACTIVITY_MS: 14400000 } as const;
```

**Aufwand:** S (2-3h)

---

### N4: Health-Check / Readiness-Probe Endpoint

**Problem:** Kein dedizierter `GET /health` oder `GET /ready` Endpoint fuer Monitoring/Load-Balancer.

**Soll:**
```typescript
router.get("/health", (req, res) => {
  res.json({ status: "ok", uptime: process.uptime(), timestamp: new Date() });
});

router.get("/ready", asyncHandler(async (req, res) => {
  const dbOk = await prisma.$queryRaw`SELECT 1`.then(() => true).catch(() => false);
  const pgvOk = await pgPool.query("SELECT 1").then(() => true).catch(() => false);
  res.status(dbOk && pgvOk ? 200 : 503).json({ database: dbOk, pgvector: pgvOk });
}));
```

**Aufwand:** S (1h)

---

### N5: TypeScript `any` Audit

**Problem:** `any` Types sind laut CLAUDE.md verboten, aber `Record<string, any>` wird in der Praxis verwendet.

**Soll:** ESLint-Rule `@typescript-eslint/no-explicit-any` auf `error`. Schrittweise durch spezifische Types ersetzen.

**Aufwand:** L (fortlaufend)

---

### N6: Frontend Bundle-Groesse optimieren

**Problem:** Three.js (3D-Visualisierungen), grosse PDF-Bibliotheken erhoehen Bundle. 3D-Features (HouseVisualization3D, Pipeline3D, Background3D) sind schwer.

**Soll:** Three.js per Dynamic Import nur bei Bedarf laden. PDF-Generierung serverseitig.

**Aufwand:** M (2-3 Tage)

---

### N7: OpenAPI/Swagger-Dokumentation

**Problem:** 96 Route-Dateien, hunderte Endpoints, keine maschinenlesbare API-Dokumentation.

**Soll:** OpenAPI 3.0 Spec, Swagger-UI unter `/api-docs`.

**Aufwand:** L (3-5 Tage)

---

### N8: Konsistente Fehler-Responses

**Problem:** Verschiedene Error-Response-Formate im Frontend und Backend.

**Ist:** `errorHandler.ts` hat einheitliches Format, aber nicht alle Endpoints nutzen `asyncHandler`/`ApiError`.

**Soll:** Strikt alle Endpoints ueber `asyncHandler` wrappen. Ein Response-Format:
```json
{
  "success": false,
  "error": "Menschenlesbare Nachricht",
  "statusCode": 400,
  "requestId": "abc123"
}
```

**Aufwand:** M (1 Tag)

---

### N9: Frontend Error-Tracking (Sentry)

**Problem:** Kein Frontend-Error-Tracking. Fehler gehen in Browser-Konsole unter.

**Soll:** Sentry SDK einbinden, ErrorBoundary konfigurieren, Source Maps hochladen.

**Aufwand:** M (4-6h)

---

### N10: Logging-Standardisierung

**Problem:** Pino-Logger via `createLogger()` existiert, aber nicht alle Services nutzen es. Manche verwenden `console.log`.

**Soll:** Alle `console.log/warn/error` durch Pino ersetzen. ESLint-Regel `no-console`.

**Aufwand:** M (4-6h)

---

## 5. Zusammenfassung

### Nach Aufwand und Prioritaet

| Prio | ID | Thema | Aufwand | Risiko |
|------|----|-------|---------|--------|
| KRITISCH | K1 | Admin-Users ohne Rollen-Check | S | Privilege Escalation |
| KRITISCH | K2 | Accounting ohne Rollen-Check | S | Datenschutz, Manipulation |
| KRITISCH | K3 | Rechnungen ohne Rollen-Check | S | Status-Manipulation |
| KRITISCH | K4 | Email-Inbox ohne Rollen-Check | S | Unbefugter Zugriff |
| KRITISCH | K7 | Race Condition Rechnungsnr. | S | Doppelte Nummern |
| KRITISCH | K8 | Wise Webhook ohne Signatur | S | Gefaelschte Zahlungen |
| KRITISCH | K9 | Token in Query-Parameter | S | Token-Leak |
| KRITISCH | K11 | Login ohne Rate-Limit | S | Brute-Force |
| KRITISCH | K5 | Cron-Jobs ohne Guard | M | Server-Absturz |
| KRITISCH | K6 | NB-Credentials Encryption | M | Credential-Leak |
| KRITISCH | K10 | Terminal WebSocket | L | Server-Kompromittierung |
| HOCH | H2 | Stille catch-Bloecke | S | Unerkannte Fehler |
| HOCH | H4 | Error-Boundaries | S | Full-Page-Crash |
| HOCH | H7 | pgvector Pool-Limits | S | Haengende Queries |
| HOCH | H3 | Route-Konflikte | M | Undefiniertes Verhalten |
| HOCH | H5 | N+1 Queries | M | Langsame Responses |
| HOCH | H6 | Fehlende Pagination | M | OOM bei grossen Daten |
| HOCH | H9 | Cache ohne LRU | M | Memory-Leak |
| HOCH | H10 | Verwaiste Dateien | M | Bundle, Verwirrung |
| HOCH | H1 | 6 API-Clients | L | Inkonsistentes Auth |
| HOCH | H8 | CompanySettings 120 Felder | L | Unwartbar |

### Empfohlene Reihenfolge

**Tag 1 — Sofort (alle S-Aufwand KRITISCH):**
1. K1 + K2 + K3 + K4 → Rollen-Middleware ergaenzen (2h)
2. K7 → Transaction um Counter-Logik (1h)
3. K8 → Wise Webhook Signatur (1h)
4. K9 → Grace Period reduzieren (1h)
5. K11 → Login Rate-Limiter anwenden (30min)

**Tag 2 — Stabilisierung:**
6. K5 → Cron-Guards einbauen (2-3h)
7. H2 → Stille catches durch Logging ersetzen (1-2h)
8. H4 → Error-Boundaries (2h)
9. H7 → pgvector Pool konfigurieren (1h)

**Woche 1:**
10. K6 → Encryption-Service (4-6h)
11. H3 → Route-Konflikte aufloesen (3-4h)
12. H5 → N+1 Queries optimieren (4-6h)
13. H10 → Verwaiste Dateien entfernen (3-4h)

**Danach nach Business-Value priorisieren.**
