# GridNetz Frontend - Vollstaendige Analyse

**Stand:** 2026-03-11
**Pfad:** `/var/www/gridnetz-frontend/src/`
**Stack:** React 18, TypeScript, Vite, Tailwind CSS, React Router, TanStack Query, Zustand

---

## 1. EINSTIEGSPUNKTE & ARCHITEKTUR

### `src/main.tsx`
- **Beschreibung:** Haupt-Entry-Point. Rendert React-App in DOM.
- **Provider-Hierarchie:** `ErrorBoundary` > `QueryClientProvider` > `AuthProvider` > `RealtimeProvider` > `WhiteLabelProvider` > `AppRouter`
- **Besonderheiten:** Globaler `window.fetch` Interceptor fuer Bearer-Token, Service Worker fuer PWA, Vite Chunk-Error Handler
- **API:** React Query Client (staleTime 30s, gcTime 5min, retry 1)

### `src/App.tsx`
- **Beschreibung:** Minimaler Wrapper, importiert nur `WhiteLabelProvider` + `AppRouter`. Wird NICHT in main.tsx genutzt (main.tsx baut Providers selbst).
- **Status:** VERWAIST - main.tsx nutzt eigene Provider-Struktur

### `src/router.tsx`
- **Beschreibung:** Zentraler Router mit allen Routen. Lazy-Loading fuer alle geschuetzten Seiten.
- **Child-Komponenten:** `RequireAuth`, `AdminLayout`, `RoleGuard`, `TrackingProvider`
- **Electron-Support:** HashRouter fuer Desktop, BrowserRouter fuer Web

---

## 2. API-LAYER

### 2.1 API Clients (4 verschiedene - DUPLIKATION!)

#### `src/api/client.ts` (PRIMARY)
- **Typ:** Fetch-basiert mit `apiGet`, `apiPost`, `apiPatch`, `apiPut`, `apiDelete`
- **Auth:** Bearer Token via `getAccessToken()`, Cookies via `credentials: "include"`
- **Genutzt von:** `api/admin.ts`, `api/accounting.ts`, `api/aiAssistant.ts`, `api/anlagen.ts`, `api/emailInbox.ts`, `api/evu.ts`, `portal/api.ts`, `finanzen-module/api.ts`, `features/rag-admin`, `features/brain-admin`, `features/agent-center`, `features/claude-ai-dashboard`, `modules/rechnungen/api.ts`

#### `src/api/api.ts` (AXIOS)
- **Typ:** Axios-Instanz mit Bearer-Token Interceptor
- **Genutzt von:** Wenige Legacy-Komponenten

#### `src/modules/api/client.ts` (AXIOS)
- **Typ:** Axios-Instanz mit CSRF-Token Support
- **Genutzt von:** `pages/AuthContext.tsx`, `contexts/WhiteLabelContext.tsx`, `services/*.service.ts`, `features/hv-center`, `features/control-center`

#### `src/services/apiClient.ts` (FETCH)
- **Typ:** Minimaler Fetch-Wrapper, `/api`-Prefix fest eingebaut
- **Genutzt von:** Vereinzelt

#### `src/lib/api.ts` (LEGACY FETCH)
- **Typ:** Roher Fetch ohne Auth-Header
- **Genutzt von:** Wizard-Komponenten (10 Dateien)
- **Status:** LEGACY - kein Auth-Header, nutzt globalen Fetch-Interceptor

#### `src/features/netzanmeldungen/services/api.ts` (EIGENER CLIENT)
- **Typ:** Eigener Fetch-Client mit Bearer + FormData Support
- **Beschreibung:** Umfangreicher API-Layer fuer Netzanmeldungen Enterprise
- **Sub-APIs:** `installationsApi`, `timelineApi`, `commentsApi`, `documentsApi`, `checklistApi`, `gridOperatorsApi`, `emailApi`, `tasksApi`, `teamApi`, `analyticsApi`, `produkteApi`, `vdeGeneratorApi`, `vdeFormularApi`

### 2.2 API Module

#### `src/api/accounting.ts`
- **Endpoints:** `/api/accounting/*` (accounts, journal, expenses, vendors, reports, AI features, exchange rates, fiscal years)
- **~40 Funktionen:** getAccounts, getJournalEntries, createExpense, getDashboardSummary, getIncomeStatement, getBalanceSheet, extractInvoiceData, getAIInsights, getAnomalies, sendChatMessage, etc.

#### `src/api/admin.ts`
- **Endpoints:** `/api/admin/anlagen/*/status`, `/api/admin/anlagen/*/rechnungen`, `/api/admin/users/`
- **Funktionen:** updateAnlageStatus, fetchRechnungenForAnlage, createRechnungForAnlage, downloadRechnungPdf, fetchUsers, toggleUser, createUser

#### `src/api/aiAssistant.ts`
- **Endpoints:** `/api/ai-assistant/*` (email, document, workflow, chat, search, validate)
- **~20 Funktionen:** analyzeRueckfrage, generateEmailResponse, getWorkflowInsights, semanticSearch, validateInstallation, etc.

#### `src/api/anlagen.ts`
- **Endpoints:** `/api/portal/anlagen`, `/api/portal/anlagen/:id`, `/api/portal/anlagen/:id/dokumente`
- **Funktionen:** fetchAnlagenList, fetchAnlageDetail, fetchAnlageDokumente

#### `src/api/emailInbox.ts`
- **Endpoints:** `/api/email-inbox/*`
- **Funktionen:** getEmailInboxStatus, triggerEmailPoll, getUnassignedEmails, getEmailDetail, assignEmailToInstallation, archiveEmail, getInstallationEmails

#### `src/api/evu.ts`
- **Endpoints:** `/api/evu/*`, `/api/netzbetreiber/*/workflow`, `/api/netzbetreiber/*/few-shot-examples`
- **Funktionen:** getEvuWarnings, getEvuProfile, getEvuDashboard, analyzeAllEvus, updateNbWorkflow, CRUD FewShotExamples

#### `src/api/types.ts`
- **Beschreibung:** Zentrale Typdefinitionen fuer API-Responses

### 2.3 Feature-APIs

#### `src/admin-center/api/admin-center.api.ts`
- **Endpoints:** `/api/admin/dashboard`, `/api/admin/logs`, `/api/admin/bugs`, `/api/admin/announcements`
- **Objekt:** `adminCenterApi` mit getDashboard, getLogs, getBugs, getAnnouncements, createBug, etc.

#### `src/admin-center/api/automations.api.ts`
- **Endpoints:** Automatisierungs-Regeln API
- **Genutzt von:** AutomationenTab

#### `src/features/control-center/api/control-center.api.ts`
- **Endpoints:** `/api/control-center/overview`, `/api/control-center/quick-stats`, `/api/control-center/health`
- **Objekt:** `controlCenterApi`

#### `src/features/hv-center/api/hv-center.api.ts`
- **Endpoints:** `/hv/*` (Self-Service) + `/admin/hv/*` (Admin)
- **Objekte:** `hvCenterApi` (Dashboard, Profil, Kunden, Provisionen, Auszahlungen, Benutzer) + `adminHvApi` (CRUD, Provisionen, Auszahlungen)

#### `src/features/hv-center/api/hv-contract.api.ts`
- **Endpoints:** HV-Vertragsmanagement

#### `src/features/rag-admin/api/rag.api.ts`
- **Endpoints:** `/api/rag/*` (status, health, index, search, query-logs, metrics, changes, feedback, cache, ab-tests, backup, versions)
- **Objekt:** `ragApi`

#### `src/features/brain-admin/api/brain.api.ts`
- **Endpoints:** `/api/brain/*` (stats, insights, knowledge, patterns, rules, events, feedback, action, learn)
- **Objekt:** `brainApi`

#### `src/features/agent-center/api/agent.api.ts`
- **Endpoints:** `/api/agent/*` (stats, tasks, task/:id/logs, cancel, confirm, input)
- **Objekt:** `agentApi`

#### `src/features/claude-ai-dashboard/api/claude.api.ts`
- **Endpoints:** `/api/claude-ai/*` (status, dashboard, analyze-email, batch, alerts, quality-check, insights, generate-response, assistant)
- **Objekt:** `claudeApi`

#### `src/features/nb-portal/nbPortalApi.ts`
- **Endpoints:** NB-Portal API

#### `src/features/calendar/api.ts`
- **Endpoints:** Kalender/Termin API

#### `src/portal/api.ts`
- **Endpoints:** `/api/portal/*` (installations, timeline, documents, email, messages, alerts, onboarding, whatsapp, notifications, rechnungen, settings, admin)
- **~25 Funktionen:** getPortalInstallations, getPortalTimeline, getPortalDocuments, sendPortalMessage, getPortalAlerts, etc.

#### `src/finanzen-module/api.ts`
- **Endpoints:** `/api/rechnungen`, `/api/kunden`
- **Funktionen:** fetchInvoices, createInvoice, markInvoicePaid, finalizeInvoice, sendInvoice, getInvoicePdfUrl, fetchCustomers

#### `src/modules/rechnungen/api.ts`
- **Endpoints:** `/rechnungen/*`, `/kunden/*`, `/admin/kunden/*/prices`, `/settings/company`, `/installations`, `/anlagen`
- **Funktionen:** fetchInvoices, createInvoiceDraft, finalizeInvoice, markPaid, createSammelrechnung, fetchUnbilledInstallations, fetchBillingOverview, sendWhatsApp, fetchAbrechnungOverview

#### `src/modules/emails/api.ts`
- **Endpoints:** Email-Verwaltung

#### `src/modules/rechnungs-ordner/api.ts`
- **Endpoints:** Rechnungsordner-Verwaltung

#### `src/modules/installations/services/installations.service.ts`
- **Endpoints:** Installationen CRUD

#### `src/modules/installations/detail/logic/api.ts`
- **Endpoints:** Installation Detail API

### 2.4 Services

#### `src/services/dashboard.service.ts`
- **Endpoints:** `/dashboard/summary`, `/dashboard/kpis`, `/dashboard/priorities`, `/dashboard/activity-feed`, `/dashboard/alerts`, `/netzbetreiber/performance`, `/emails/stats`
- **Objekt:** `dashboardApi`

#### `src/services/documents.service.ts`
- **Endpoints:** `/documents`, `/documents/upload`, `/documents/upload-multiple`, `/documents/:id`
- **Funktionen:** fetchDocuments, uploadDocument, uploadDocuments, updateDocument, deleteDocument

#### `src/services/emails.service.ts`
- **Endpoints:** `/emails`, `/emails/unassigned`, `/emails/:id`, `/emails/:id/assign`, `/emails/:id/archive`
- **Funktionen:** fetchEmails, fetchUnassignedEmails, fetchEmailById, assignEmail, archiveEmail

#### `src/services/kunden.service.ts`
- **Endpoints:** `/kunden`, `/kunden/:id`, `/admin/hv`
- **Funktionen:** fetchKunden, fetchKundeById, createKunde, updateKunde, deleteKunde, fetchHandelsvertreter

#### `src/services/rechnungen.service.ts`
- **Endpoints:** `/rechnungen`, `/rechnungen/:id`, `/rechnungen/:id/send`, `/rechnungen/:id/mark-paid`, `/rechnungen/:id/cancel`
- **Funktionen:** listRechnungen, getRechnung, createRechnung, sendRechnung, markRechnungPaid, cancelRechnung

#### `src/services/apiClient.ts`
- **Beschreibung:** Minimaler fetch-Wrapper (apiGet, apiPost)

#### `src/services/installationAi.ts`
- **Beschreibung:** AI-Funktionen fuer Installationen
- **Genutzt von:** modules/installations/detail (KiTab, useInstallationDetail)

#### `src/services/installationsDelete.ts`
- **Status:** VERWAIST - nirgendwo importiert

#### `src/services/installationsUpdate.ts`
- **Status:** VERWAIST - nirgendwo importiert

#### `src/services/anlagen.service.ts`
- **Status:** VERWAIST - nirgendwo importiert

---

## 3. STATE MANAGEMENT

### 3.1 Contexts

#### `src/pages/AuthContext.tsx` (PRIMARY AUTH)
- **State:** user, loading, preferences
- **API:** `/auth/v2/me`, `/auth/v2/login`, `/auth/v2/logout`, `/me/preferences/*/*`
- **Exports:** `AuthProvider`, `useAuth`, `useIsAdmin`, `useIsMitarbeiter`, `useIsKunde`, `useIsHandelsvertreter`, `useIsHvOrAbove`
- **Genutzt von:** Fast alle Komponenten

#### `src/modules/auth/AuthContext.tsx`
- **Beschreibung:** Re-Export von `pages/AuthContext.tsx` (Alias)

#### `src/contexts/WhiteLabelContext.tsx`
- **State:** WhiteLabel-Konfiguration (companyName, logoUrl, primaryColor, accentColor)
- **API:** `/me` (WhiteLabel-Config aus User-Daten)
- **Exports:** `WhiteLabelProvider`, `useWhiteLabel`

#### `src/contexts/TrackingContext.tsx`
- **State:** sessionId, isActive, Event-Buffer
- **API:** `/api/tracking/session/start`, `/api/tracking/session/associate`, `/api/tracking/session/heartbeat`, `/api/tracking/session/end`, `/api/tracking/batch`, `/api/tracking/page-view`, `/api/tracking/search`
- **Exports:** `TrackingProvider`, `useTracking`

#### `src/portal/PortalContext.tsx`
- **Beschreibung:** Context fuer Endkunden-Portal

#### `src/features/netzanmeldungen/contexts/AuthContext.tsx`
- **Beschreibung:** Feature-spezifischer Auth-Context

#### `src/modules/installations/context/GlobalEmailStore.tsx`
- **Beschreibung:** Globaler Email-State fuer Installationen

#### `src/modules/installations/detail/context/InstallationDetailContext.tsx`
- **Beschreibung:** Context fuer Installation-Detail-Ansicht

#### `src/modules/installations/detail-v2/context/DetailContext.tsx`
- **Beschreibung:** Context fuer Installation-Detail v2

#### `src/modules/performance/PerformanceModeContext.tsx`
- **Beschreibung:** Performance-Modus (reduzierte Animationen)

#### `src/modules/ui/toast/ToastContext.tsx`
- **Beschreibung:** Toast-Notifications Context

### 3.2 Stores (Zustand)

#### `src/features/netzanmeldungen/stores/index.ts`
- **Beschreibung:** Zustand-Store fuer Netzanmeldungen

#### `src/admin-center/stores/index.ts`
- **Beschreibung:** Zustand-Store fuer Admin Center

#### `src/features/nb-portal/forms/store/dynamicFormStore.ts`
- **Beschreibung:** Zustand-Store fuer dynamische NB-Formulare

#### `src/debug/store.ts`
- **Beschreibung:** Debug-Panel State

---

## 4. HOOKS

### Globale Hooks (`src/hooks/`)

#### `src/hooks/usePermissions.ts`
- **Beschreibung:** Zentrale Berechtigungs-Logik (canChangeStatus, canUploadDocuments, canWriteComments, isAdmin, etc.)
- **Abhaengigkeit:** useAuth

#### `src/hooks/useDashboard.ts`
- **Beschreibung:** Dashboard-Daten Hook (Summary, KPIs, Alerts, GridOperators, EmailStats)
- **API:** dashboardApi (5 parallele Requests)
- **Exports:** `useDashboardData`, `useRelativeTime`, `useLocalStorage`, `useDashboardPreferences`

#### `src/hooks/useWebSocket.tsx`
- **Beschreibung:** WebSocket-Verbindung mit Auto-Reconnect, Channel-Subscription, Token-Refresh
- **URL:** `wss://gridnetz.de/ws/installations`
- **Exports:** `useWebSocket`, `WebSocketProvider`, `useWebSocketContext`, `useWebSocketEvent`, `useInstallationUpdates`, `useStatsUpdates`, `useAlertUpdates`

#### `src/hooks/useAutoLogout.tsx`
- **Beschreibung:** Automatischer Logout bei Inaktivitaet

#### `src/hooks/useDebounce.ts`
- **Beschreibung:** Debounce-Hook

#### `src/hooks/useDesktopIntegration.ts`
- **Beschreibung:** Electron Desktop Integration

#### `src/hooks/usePreferences.ts`
- **Beschreibung:** User Preferences Hook

#### `src/hooks/useRealtimeUpdates.ts`
- **Beschreibung:** Echtzeit-Update Hook

#### `src/hooks/useTracking.ts`
- **Beschreibung:** Tracking-Event Hook

### Feature Hooks

#### `src/features/netzanmeldungen/hooks/useEnterpriseApi.ts`
- **Beschreibung:** Enterprise API Hook fuer Netzanmeldungen

#### `src/features/netzanmeldungen/hooks/useSubOverview.ts`
- **Beschreibung:** Subunternehmer-Uebersicht Hook

#### `src/features/netzanmeldungen/hooks/useWebSocket.ts`
- **Beschreibung:** Feature-spezifischer WebSocket Hook

#### `src/features/control-center/hooks/useControlCenter.ts`
- **Beschreibung:** Control Center Daten Hook

#### `src/features/hv-center/hooks/useHvCenter.ts`, `useHvContract.ts`
- **Beschreibung:** HV Center Hooks

#### `src/wizard/hooks/*.ts`
- `useDocuments.ts` - Dokument-Management im Wizard
- `useLearning.ts` - Lern-Engine Hook
- `usePLZ.ts` - PLZ-Suche/Netzbetreiber
- `useProduktDB.ts` - Produktdatenbank-Suche
- `useValidation.ts` - Formular-Validierung
- `useVisibleSteps.ts` - Sichtbare Wizard-Steps

#### `src/finanzen-module/hooks/*.ts`
- `useInvoices.ts` - Rechnungsliste
- `useKeyboard.ts` - Keyboard Shortcuts
- `useToast.ts` - Toast-Notifications

---

## 5. SEITEN (PAGES)

### 5.1 Oeffentliche Seiten

| Datei | Route | Beschreibung |
|-------|-------|-------------|
| `src/pages/LandingPage.tsx` | `/` | Landing Page (Web), Redirect zu /dashboard (Desktop) |
| `src/modules/auth/LoginPage.tsx` | `/login` | Login-Formular |
| `src/modules/auth/ForgotPasswordPage.tsx` | `/forgot-password` | Passwort vergessen |
| `src/modules/auth/ResetPasswordPage.tsx` | `/reset-password` | Passwort zuruecksetzen |
| `src/modules/auth/VerifyEmailPage.tsx` | `/verify-email` | E-Mail-Verifizierung |
| `src/modules/auth/ResendVerificationPage.tsx` | `/resend-verification` | Verifizierung erneut senden |
| `src/pages/AGBPage.tsx` | `/agb` | AGB |
| `src/pages/DatenschutzPage.tsx` | `/datenschutz` | Datenschutzerklaerung |
| `src/pages/ImpressumPage.tsx` | `/impressum` | Impressum |
| `src/pages/DownloadPage.tsx` | `/download` | Desktop-App Download |
| `src/pages/PublicFormularPage.tsx` | `/formular/:slug` | Oeffentliche Formulare |
| `src/pages/PartnerPage.tsx` | `/partner` | Partner-Seite |
| `src/pages/UnternehmenPage.tsx` | `/unternehmen` | Unternehmen-Seite |
| `src/pages/PaymentPage.tsx` | `/pay/:token` | Payment-Link Seite |
| `src/features/calendar/BookingPage.tsx` | `/termin` | Terminbuchung |

### 5.2 Authentifizierte Seiten (Alle Rollen)

| Datei | Route | Beschreibung |
|-------|-------|-------------|
| `src/modules/dashboard/Dashboard.tsx` | `/dashboard` | Haupt-Dashboard |
| `src/features/netzanmeldungen/NetzanmeldungenEnterprise.tsx` | `/netzanmeldungen` | Netzanmeldungen Enterprise (Hauptansicht) |
| `src/pages/AnlagenWizardPage.tsx` | `/anlagen-wizard` | Anlagen-Wizard Wrapper |
| `src/pages/DokumentenCenterPage.tsx` | `/dokumente` | Dokumenten-Center |
| `src/pages/RechnungenPage.tsx` | `/rechnungen` | Rechnungen |
| `src/pages/RechnungsOrdnerPage.tsx` | `/rechnungs-ordner` | Rechnungs-Ordner |
| `src/pages/NbWissenPage.tsx` | `/nb-wissen` | Netzbetreiber-Wissen |
| `src/pages/ArchivPage.tsx` | `/archiv` | Archiv |
| `src/pages/MyCompanySettingsPage.tsx` | `/settings/me` | Eigene Einstellungen |
| `src/features/calendar/CalendarPage.tsx` | `/calendar` | Kalender |
| `src/features/hv-center/components/HvCenterPage.tsx` | `/hv-center` | HV Self-Service Center |
| `src/features/hv-center/components/HvContractPage.tsx` | `/hv-center/vertrag` | HV Vertrag |
| `src/pages/ProdukteDatenbankPage.tsx` | `/produkte-db` | Produktdatenbank |
| `src/pages/ProjektePage.tsx` | `/projekte` | Projekte (Factro) |
| `src/pages/ProjektDetailPage.tsx` | `/projekte/:id` | Projekt-Detail |
| `src/pages/KundenOnboardingPage.tsx` | `/onboarding` | Kunden-Onboarding |

### 5.3 Staff-Only (ADMIN + MITARBEITER)

| Datei | Route | Beschreibung |
|-------|-------|-------------|
| `src/features/netzanmeldungen/components/ZaehlerwechselCenter/ZaehlerwechselCenter.tsx` | `/zaehlerwechsel-center` | Zaehlerwechsel-Center |
| `src/pages/VDEFormularePage.tsx` | `/vde-formulare` | VDE-Formulare |
| `src/pages/admin/Netzanmeldungen.tsx` | `/netzanmeldungen-legacy` | Legacy Netzanmeldungen |
| `src/pages/NetzbetreiberCenterPage.tsx` | `/netzbetreiber` | Netzbetreiber-Verwaltung |
| `src/pages/admin/KundenPage.tsx` | `/kunden` | Kunden-Verwaltung |
| `src/pages/UserManagementPage.tsx` | `/benutzer` | Benutzerverwaltung |
| `src/pages/EmailCommandCenter.tsx` | `/emails` | Email Command Center |
| `src/pages/admin/DokumenteMatrix.tsx` | `/dokumente/matrix` | Dokumenten-Matrix |
| `src/pages/LogsPage.tsx` | `/logs` | System-Logs |
| `src/pages/RegelnPage.tsx` | `/regeln` | Automatisierungsregeln |
| `src/pages/CompanySettingsPage.tsx` | `/settings/company` | Firmeneinstellungen |
| `src/pages/Importpage.tsx` | `/import` | Datenimport |
| `src/modules/admin/emails/EmailsPage.tsx` | `/email-inbox` | Email-Inbox |
| `src/features/finanzen/FinanzenPage.tsx` | `/finanzen` | Finanzen |
| `src/features/nb-portal/NbPortalAuswahl.tsx` | `/nb-portal/:portalId` | NB-Portal Auswahl |
| `src/features/nb-portal/ProxyFormPage.tsx` | `/nb-portal/:portalId/form/:typeId` | NB-Portal Proxy-Formular |
| `src/features/nb-portal/forms/DynamicFormPage.tsx` | `/nb-portal/:portalId/dynamic/:typeId` | NB-Portal Dynamisches Formular |
| `src/pages/OpsCenterPage.tsx` | `/ops-center` | Operations Center |
| `src/pages/admin/Analytics.tsx` | `/analytics` | Analytics |
| `src/pages/FormularLinksPage.tsx` | `/formulare` | Formular-Links |

### 5.4 Admin-Only

| Datei | Route | Beschreibung |
|-------|-------|-------------|
| `src/admin-center/pages/AdminCenter/AdminCenterPage.tsx` | `/admin/center` | Admin Center |
| `src/features/control-center/components/ControlCenterPage.tsx` | `/control-center` | Control Center |
| `src/pages/IntelligenceDashboard.tsx` | `/intelligence` | Intelligence Dashboard |
| `src/features/admin/handelsvertreter/HandelsvertreterPage.tsx` | `/admin/handelsvertreter` | HV-Verwaltung |
| `src/features/admin/provisionen/ProvisionenPage.tsx` | `/admin/provisionen` | Provisionen |
| `src/pages/EvuDashboardPage.tsx` | `/evu-dashboard` | EVU-Dashboard |
| `src/pages/MaStRAdminPage.tsx` | `/mastr-admin` | MaStR Admin |
| `src/pages/AICenterPage.tsx` | `/ai-center` | AI Center |
| `src/pages/FactroCenterPage.tsx` | `/factro-center` | Factro Center (+ KUNDE 24) |
| `src/components/desktop/OfflineBriefcase.tsx` | `/offline` | Offline-Koffer (Desktop) |

### 5.5 Endkunden-Portal

| Datei | Route | Beschreibung |
|-------|-------|-------------|
| `src/portal/pages/LoginPage.tsx` | `/portal/login` | Portal Login |
| `src/portal/pages/ForgotPasswordPage.tsx` | `/portal/forgot-password` | Portal Passwort vergessen |
| `src/portal/pages/ImpersonatePage.tsx` | `/portal/impersonate` | Admin-Impersonation |
| `src/portal/pages/DashboardPage.tsx` | `/portal` | Portal Dashboard |
| `src/portal/pages/MessagesPage.tsx` | `/portal/messages` | Portal Nachrichten |
| `src/portal/pages/DocumentsPage.tsx` | `/portal/documents` | Portal Dokumente |
| `src/portal/pages/SettingsPage.tsx` | `/portal/settings` | Portal Einstellungen |
| `src/portal/pages/NotificationsPage.tsx` | `/portal/notifications` | Portal Benachrichtigungen |
| `src/portal/pages/OnboardingPage.tsx` | `/portal/onboarding` | Portal Onboarding |

---

## 6. KOMPONENTEN

### 6.1 Layout (`src/components/layout/`)

| Datei | Beschreibung | Genutzt in |
|-------|-------------|-----------|
| `AdminLayout.tsx` | Haupt-Layout mit Sidebar (geschuetzte Seiten) | router.tsx |
| `Sidebar.tsx` | Seitennavigation | AdminLayout |
| `TopBar.tsx` | Obere Leiste mit User-Info | AdminLayout |
| `LayoutShell.tsx` | Shell-Wrapper | Diverse |
| `DesktopTitlebar.tsx` | Electron Desktop Titelleiste | AdminLayout |

#### `src/layout/AdminLayout.tsx`
- **Status:** Separater Layout-Ordner, moeglicherweise DUPLIKAT von components/layout/AdminLayout.tsx

#### `src/modules/layout/AdminShell.tsx`
- **Beschreibung:** Alternative Layout-Shell

### 6.2 Auth (`src/components/auth/`)

#### `src/components/auth/RoleGuard.tsx`
- **Beschreibung:** Route-Schutz nach Rollen
- **Props:** `allowed: string[]`, `allowedKundeIds?: number[]`
- **Genutzt in:** router.tsx (vielfach)

#### `src/pages/RequireAuth.tsx`
- **Beschreibung:** Auth-Guard (Outlet)
- **Genutzt in:** router.tsx

#### `src/modules/auth/RequireAuth.tsx`
- **Beschreibung:** Separater Auth-Guard

#### `src/portal/PortalRequireAuth.tsx`
- **Beschreibung:** Portal-spezifischer Auth-Guard

### 6.3 UI-Komponenten (`src/components/ui/`)

| Datei | Beschreibung |
|-------|-------------|
| `KpiCard.tsx` | KPI-Karte |
| `Modal.tsx` | Modal-Dialog |
| `StatusPill.tsx` | Status-Badge |
| `Tabs.tsx` | Tab-Navigation |

#### `src/modules/ui/`
| Datei | Beschreibung |
|-------|-------------|
| `Button.tsx` | Button-Komponente |
| `tabs/MemoizedTabs.tsx` | Memoized Tab-Komponente |
| `toast/ToastContainer.tsx` | Toast-Container |
| `toast/ToastContext.tsx` | Toast-Context |
| `toast/useToast.ts` | Toast-Hook |

### 6.4 Dashboard (`src/components/DashboardV2/`)

| Datei | Beschreibung |
|-------|-------------|
| `DashboardV2.tsx` | Dashboard Hauptkomponente (V2) |
| `components/AlertBar.tsx` | Alert-Leiste |
| `components/Box.tsx` | Dashboard-Box |
| `components/Btn.tsx` | Dashboard-Button |
| `components/CopyField.tsx` | Copy-to-Clipboard Feld |
| `components/DocCheck.tsx` | Dokument-Check Anzeige |
| `components/EmailIndicator.tsx` | Email-Indikator |
| `components/StatusPill.tsx` | Status-Pill (DUPLIKAT zu ui/StatusPill) |
| `components/TabBar.tsx` | Tab-Leiste |
| `components/TopBar.tsx` | Top-Bar (DUPLIKAT) |
| `constants.ts` | Konstanten |
| `tabs/DatenTab.tsx` | Daten-Tab |
| `tabs/DokumenteTab.tsx` | Dokumente-Tab |
| `tabs/KommunikationTab.tsx` | Kommunikation-Tab |

### 6.5 Workflow-Komponenten (`src/components/workflow/`)

| Datei | Beschreibung |
|-------|-------------|
| `WorkflowRouter.tsx` | Workflow-Router |
| `PipelineBoard.tsx` | Kanban-Pipeline Board |
| `PipelineCard.tsx` | Pipeline-Karte |
| `PipelineColumn.tsx` | Pipeline-Spalte |
| `InboxList.tsx` | Inbox-Liste |
| `InboxCard.tsx` | Inbox-Karte |
| `ActionButton.tsx` | Aktions-Button |
| `ActionFormModal.tsx` | Aktions-Formular Modal |
| `DeadlineIndicator.tsx` | Deadline-Anzeige |
| `TimelineDrawer.tsx` | Timeline-Drawer |
| `TimelineEntry.tsx` | Timeline-Eintrag |

#### `src/components/WorkflowPipeline.tsx`
- **Beschreibung:** Standalone Workflow-Pipeline (DUPLIKAT?)

### 6.6 Features (`src/components/features/`)

| Datei | Beschreibung |
|-------|-------------|
| `AIAssistant.tsx` | KI-Assistent Widget |
| `CommandPalette.tsx` | Command Palette (Cmd+K) |
| `FlyingAI.tsx` | Fliegendes AI-Widget |
| `QuickPreview.tsx` | Schnellvorschau |

### 6.7 Factro (`src/components/factro/`)

#### `BatchNetzanfrageModal.tsx`
- **Beschreibung:** Batch-Netzanfrage Modal

### 6.8 EVU (`src/components/evu/`)

#### `EvuWarningsCard.tsx`
- **Beschreibung:** EVU-Warnungen Karte

### 6.9 Three.js / 3D (`src/components/three/`)

| Datei | Beschreibung |
|-------|-------------|
| `DashboardBackground.tsx` | 3D Dashboard-Hintergrund |
| `backgrounds/EnergyNetworkBackground.tsx` | Energie-Netzwerk Animation |
| `cards/KPI3DCard.tsx` | 3D KPI-Karte |
| `core/Canvas3D.tsx` | Three.js Canvas |
| `core/ThreeProvider.tsx` | Three.js Provider |
| `pipeline/PipelineFlow3D.tsx` | 3D Pipeline-Visualisierung |
| `hooks/usePerformanceTier.ts` | Performance-Erkennung |
| `hooks/useReducedMotion.ts` | Reduced Motion Erkennung |
| `hooks/useWebGLSupport.ts` | WebGL Support Check |

### 6.10 Weitere Standalone-Komponenten

| Datei | Beschreibung |
|-------|-------------|
| `src/components/ActivityFeed.tsx` | Aktivitaets-Feed |
| `src/components/AlertBox.tsx` | Alert-Box |
| `src/components/BankIntegration.tsx` | Bank-Integration (Wise) |
| `src/components/billing/AbrechnungOverview.tsx` | Abrechnungsuebersicht |
| `src/components/EmailVerificationBanner.tsx` | E-Mail-Verifizierung Banner |
| `src/components/EmailWidget.tsx` | E-Mail Widget |
| `src/components/GridOperatorRanking.tsx` | Netzbetreiber-Ranking |
| `src/components/InstallationDetailModal.tsx` | Installation Detail Modal |
| `src/components/KPICards.tsx` | KPI-Karten |
| `src/components/NetzbetreiberConfig.tsx` | NB-Konfiguration |
| `src/components/PaymentWarningBanner.tsx` | Zahlungswarnung |
| `src/components/ReferenceManager.tsx` | Referenz-Manager |
| `src/components/SubcontractorAssignment.tsx` | Sub-Zuweisung |

---

## 7. FEATURES

### 7.1 Netzanmeldungen (`src/features/netzanmeldungen/`)
**Groesstes Feature-Modul mit ~120 Dateien**

#### Hauptseiten
- `NetzanmeldungenPage.tsx` - Legacy-Seite
- `NetzanmeldungenEnterprise.tsx` - Aktive Enterprise-Ansicht

#### Enterprise-Liste
- `components/EnterpriseList.tsx` - Haupt-Installationsliste
- `components/StatusBar.tsx` - Status-Filter-Leiste
- `components/CustomerDashboard.tsx` - Kunden-Dashboard
- `components/CustomerGroupedList.tsx` - Kunden-gruppierte Liste
- `components/SubunternehmerOverview.tsx` - Sub-Uebersicht
- `components/WorkflowOverview.tsx` - Workflow-Uebersicht
- `components/WorkPrioritySections.tsx` - Arbeits-Prioritaeten
- `components/AnimatedNumber.tsx` - Animierte Zahlen
- `components/Toast.tsx` - Toast-Komponente
- `components/ActionRequired.tsx` - Handlungsbedarf

#### Detail-Modal (`components/DetailModal/`)
- `DetailModal.tsx` - Haupt-Detail-Modal
- `PremiumOverviewTab.tsx` - Premium-Uebersicht Tab
- `EmailTabView.tsx` - Email-Tab

##### DashboardV2 (im Detail-Modal)
- `DashboardV2/GridNetzDashboard.tsx` - Dashboard im Detail
- `DashboardV2/columns/LeftColumn.tsx`, `CenterColumn.tsx`, `RightColumn.tsx`
- `DashboardV2/sections/AlertBar.tsx`, `CopyField.tsx`, `DocumentGrid.tsx`, `HealthScore.tsx`, `MaStrInline.tsx`, `PortalCard.tsx`, `StatusPill.tsx`, `TimelineCompact.tsx`, `TopBar.tsx`, `WorkflowVertical.tsx`
- `DashboardV2/hooks/useCopyToClipboard.ts`, `useDashboardData.ts`
- `DashboardV2/utils/formatters.ts`, `normalizeWizardData.ts`, `statusConfig.ts`

##### HouseVisualization3D
- `HouseVisualization3D/index.tsx` - 3D Haus-Visualisierung
- `Battery.tsx`, `EnergyFlow.tsx`, `EnergyLabel.tsx`, `Ground.tsx`, `HeatPump.tsx`, `House.tsx`, `Inverter.tsx`, `PowerGrid.tsx`, `SolarPanels.tsx`, `Sun.tsx`, `Wallbox.tsx`

##### EnergyDashboard
- `EnergyDashboard/index.tsx`, `EnergyCard.tsx`, `EnergyFlowLines.tsx`

##### AnlageVisualisierung
- `AnlageVisualisierung.tsx` - Anlagen-Visualisierung

#### Detail-Panel (`components/DetailPanel/`)
- `index.tsx` - Haupt-Panel
- `hooks/useInstallationDetail.ts`
- `tabs/AlertCenter.tsx`, `ChatTab.tsx`, `DatabaseAlerts.tsx`, `DocumentsTab.tsx`, `EmailsTab.tsx`, `KommunikationTab.tsx`, `OverviewTab.tsx`, `TasksTab.tsx`, `TechTab.tsx`, `TimelineTab.tsx`, `WhatsAppTab.tsx`
- `components/TaskTemplates.tsx`

#### DetailView3D
- `DetailView3D.tsx`, `DetailView3DWrapper.tsx`, `Background3D.tsx`, `Timeline3D.tsx`

#### AI-Komponenten
- `components/ai/AIInsightsPanel.tsx` - AI-Einsichten
- `components/ai/AIQuickActions.tsx` - AI-Schnellaktionen
- `components/ai/AISearchBar.tsx` - AI-Suchleiste
- `components/ai/AIValidationBadge.tsx` - AI-Validierung Badge

#### Bulk Actions
- `components/BulkActions/index.tsx` - Massenaktionen

#### Kommentare
- `components/Comments/CommentsSection.tsx`, `CommentsPreview.tsx`, `utils.ts`

#### Analytics
- `components/Analytics/index.tsx` - Analyse-Dashboard

#### Email
- `components/EmailCenter/index.tsx` - Email-Center
- `components/EmailComposer/index.tsx` - Email-Composer

#### Signatur
- `components/SignaturePad/index.tsx` - Signatur-Pad

#### Tasks
- `components/TaskManager/index.tsx` - Task-Manager

#### VDE
- `components/VDEFormularWizard/index.tsx` - VDE-Formular-Wizard
- `components/VDEGeneratorModal/index.tsx` - VDE-Generator Modal

#### Zaehlerwechsel-Center (`components/ZaehlerwechselCenter/`)
- `ZaehlerwechselCenter.tsx` - Hauptkomponente
- `components/HeaderStats.tsx`, `TerminCalendar.tsx`, `TerminCard.tsx`, `TermineOverview.tsx`, `EmailPreview.tsx`, `InstallationMatchDropdown.tsx`, `StatusPill.tsx`, `StepTrack.tsx`
- `hooks/useInstallationMatch.ts`, `useTerminActions.ts`, `useTerminParser.ts`
- `utils/dateHelpers.ts`, `fuzzyMatch.ts`, `terminParser.ts`

#### Services & Libs
- `services/api.ts` - Umfangreicher Enterprise API Client
- `services/dokumenteGenerator.ts` - Dokument-Generator
- `services/vdeGenerator.ts` - VDE-Generator
- `lib/pdf/VDEFormularePremium.ts` - VDE PDF Generator

### 7.2 Control Center (`src/features/control-center/`)

- `components/ControlCenterPage.tsx` - Hauptseite
- `components/SmartDashboard.tsx` - Smart Dashboard
- `components/KpiCard.tsx` - KPI-Karte
- `components/ActivityFeed.tsx` - Aktivitaets-Feed
- `components/AlertsPanel.tsx` - Alerts-Panel
- `components/InsightsPanel.tsx` - Einsichten-Panel
- `components/LongestWaiting.tsx` - Laengste Wartezeit
- `components/PredictionsPanel.tsx` - Vorhersagen-Panel
- `components/QuickActions.tsx` - Schnellaktionen
- `components/WorkflowPipeline.tsx` - Pipeline (DUPLIKAT zu components/WorkflowPipeline)

#### Tabs
- `tabs/OperationsTab.tsx`, `NetworkTab.tsx`, `FinanzenTab.tsx`, `SystemTab.tsx`, `UsersTab.tsx`, `SettingsTab.tsx`, `LogsTab.tsx`

#### Communication Tab (umfangreich)
- `tabs/communication/index.tsx` - Email-Center
- `InboxTable.tsx`, `SentTable.tsx`, `EmailDetailPanel.tsx`, `EmailComposeModal.tsx`, `EmailFilterBar.tsx`, `EmailListToolbar.tsx`, `EmailStatsBar.tsx`, `EmailTemplateSelector.tsx`, `MailboxSidebar.tsx`, `FilterChips.tsx`, `EscalationPanel.tsx`, `AssignmentModal.tsx`, `BatchToolbar.tsx`
- `useEmailCenter.ts`, `useKeyboardNav.ts`
- `grouping.ts`, `styles.ts`, `types.ts`

### 7.3 HV Center (`src/features/hv-center/`)

- `components/HvCenterPage.tsx` - HV Self-Service
- `components/HvContractPage.tsx` - HV Vertrag
- `components/SignatureCanvas.tsx` - Unterschrift-Canvas
- `tabs/HvDashboardTab.tsx`, `HvKundenTab.tsx`, `HvProvisionenTab.tsx`, `HvAuszahlungenTab.tsx`, `HvProfilTab.tsx`, `HvBenutzerTab.tsx`, `HvVertragTab.tsx`

### 7.4 RAG Admin (`src/features/rag-admin/`)

- `components/RagAdminPage.tsx` - RAG Admin Dashboard
- `tabs/DashboardTab.tsx`, `IndexingTab.tsx`, `QueriesTab.tsx`, `SearchTestTab.tsx`, `FeedbackTab.tsx`, `ABTestsTab.tsx`, `BackupsTab.tsx`

### 7.5 Brain Admin (`src/features/brain-admin/`)

- `components/BrainAdminPage.tsx` - Brain Admin Dashboard
- `tabs/DashboardTab.tsx`, `KnowledgeTab.tsx`, `PatternsRulesTab.tsx`, `EventsTab.tsx`

### 7.6 Agent Center (`src/features/agent-center/`)

- `components/AgentCenterPage.tsx` - Agent Center
- `tabs/DashboardTab.tsx`, `TasksTab.tsx`, `NewTaskTab.tsx`

### 7.7 Claude AI Dashboard (`src/features/claude-ai-dashboard/`)

- `components/ClaudeAIDashboardPage.tsx` - Claude AI Dashboard
- `tabs/DashboardTab.tsx`, `EmailAnalysisTab.tsx`, `AlertsTab.tsx`, `AssistantTab.tsx`

### 7.8 Accounting (`src/features/accounting/`)

- `AccountingPage.tsx` - Buchhaltung Hauptseite
- `components/AccountingDashboard.tsx` - Dashboard
- `tabs/ExpensesTab.tsx`, `JournalTab.tsx`, `ReportsTab.tsx`, `VendorsTab.tsx`, `WiseTab.tsx`, `AIInsightsTab.tsx`

### 7.9 Finanzen (`src/features/finanzen/`)

- `FinanzenPage.tsx` - Finanzen-Uebersicht
- `tabs/UebersichtTab.tsx`, `AusgabenTab.tsx`

### 7.10 NB-Portal (`src/features/nb-portal/`)

- `NbPortalPage.tsx` - NB-Portal Hauptseite
- `NbPortalAuswahl.tsx` - Portal-Auswahl
- `NbPortalFrame.tsx` - Portal iFrame
- `ProxyFormPage.tsx` - Proxy-Formular
- `NewAnmeldungModal.tsx` - Neue Anmeldung
- `forms/DynamicFormPage.tsx` - Dynamisches Formular
- `forms/DynamicFormRenderer.tsx` - Formular-Renderer
- `forms/FormPlaceholder.tsx` - Platzhalter
- `forms/components/CircuitDiagramField.tsx`, `FieldWrapper.tsx`, `FileUploadField.tsx`, `FloorplanField.tsx`, `FormSection.tsx`, `RadioGroupField.tsx`

### 7.11 Calendar (`src/features/calendar/`)

- `CalendarPage.tsx` - Kalender
- `BookingPage.tsx` - Terminbuchung (oeffentlich)

### 7.12 Admin Features

#### Handelsvertreter (`src/features/admin/handelsvertreter/`)
- `HandelsvertreterPage.tsx` - HV-Admin
- `HvContractAdminTab.tsx` - HV-Vertrag Admin

#### Provisionen (`src/features/admin/provisionen/`)
- `ProvisionenPage.tsx` - Provisionen-Admin

### 7.13 Anlagen (`src/features/anlagen/`)

- `AnlageDetailModal.tsx` - Anlagen-Detail Modal

---

## 8. MODULES

### 8.1 Dashboard (`src/modules/dashboard/`)

- `DashboardPage.tsx` - Dashboard Page
- `Dashboard.tsx` - Dashboard Hauptkomponente
- `statusMapper.ts` - Status-Mapping
- `hooks/useDashboardData.ts` - Dashboard-Daten Hook
- `components/DashboardHeader.tsx`, `AnimatedCounter.tsx`, `KundenDashboard.tsx`, `QuickActions.tsx`
- `components/AnimatedPipeline/AnimatedPipeline.tsx`, `FlowingParticles.tsx`
- `components/ActionRequired/ActionRequired.tsx`
- `components/Calendar/WeekCalendar.tsx`
- `components/Insights/ActivityFeedCard.tsx`, `NBPerformance.tsx`, `UpcomingTermine.tsx`
- `components/TaskList/AdminTaskList.tsx`, `CustomerAnlagen.tsx`

#### Admin Dashboard (`src/modules/dashboard/admin/`)
- `AdminDashboard.tsx`, `LECADashboard.tsx`, `App.tsx`, `router.tsx`
- `features/dashboard/Dashboard.tsx`, `features/ai/AIAssistantLocal.tsx`, `features/analytics/Analytics.tsx`, `features/automation/WorkflowAutomation.tsx`, `features/kanban/KanbanBoard.tsx`, `features/notifications/NotificationCenter.tsx`
- `components/layout/AdminLayout.tsx`, `components/ui/CommandPalette.tsx`, `components/ui/UIComponents.tsx`

#### User Dashboard (`src/modules/dashboard/user/`)
- `UserDashboard.tsx`

### 8.2 Auth (`src/modules/auth/`)

- `AuthContext.tsx` - Re-Export von pages/AuthContext
- `LoginPage.tsx`, `ForgotPasswordPage.tsx`, `ResetPasswordPage.tsx`, `VerifyEmailPage.tsx`, `ResendVerificationPage.tsx`
- `RequireAuth.tsx`, `tokenStorage.ts`

### 8.3 Installations (`src/modules/installations/`)

#### Detail (v1)
- `detail/InstallationDetailModal.tsx`
- `detail/tabs/AdminTab.tsx`, `AiTab.tsx`, `DocumentsTab.tsx`, `EmailsTab.tsx`, `HistoryTab.tsx`, `KiTab.tsx`, `OverviewTab.tsx`, `RawTab.tsx`
- `detail/header/DetailHeader.tsx`
- `detail/sidebar/WorkflowSidebar.tsx`, `WorkflowStep.tsx`
- `detail/smart/SmartActions.tsx`
- `detail/logic/api.ts`, `permissions.ts`, `statusEngine.ts`, `utils.ts`
- `detail/hooks/useInstallationDetail.ts`

#### Detail-v2
- `detail-v2/InstallationDetailPanel.tsx`
- `detail-v2/components/AIAssistantPanel.tsx`, `CommandPalette.tsx`, `DocumentPreview.tsx`, `Header.tsx`, `SmartSidebar.tsx`, `Tabs.tsx`
- `detail-v2/tabs/AdminTab.tsx`, `CommunicationTab.tsx`, `DataTab.tsx`, `DocumentsTab.tsx`, `EmailsTab.tsx`, `IntelligenceTab.tsx`, `OverviewTab.tsx`, `TimelineTab.tsx`
- `detail-v2/context/DetailContext.tsx`
- `detail-v2/hooks/useKeyboard.ts`

#### Standalone Components
- `components/CommentBox.tsx`, `DetailHeader.tsx`, `DocumentInspector.tsx`, `EmailActions.tsx`, `RawDataViewer.tsx`, `SmartActions.tsx`, `StatusBadge.tsx`, `VirtualizedInstallationList.tsx`

#### Tabs (standalone)
- `tabs/AdminInboxTab.tsx`, `AdminTab.tsx`, `AiTab.tsx`, `DocumentsTab.tsx`, `EmailsTab.tsx`, `HistoryTab.tsx`, `OverviewTab.tsx`

#### Pages
- `pages/InstallationDetailPage.tsx`

#### AI
- `ai/categorizeDocument.ts`, `DocumentAIEngine.ts`, `documentCategories.ts`

#### Automation
- `automation/applyStatusAutomation.ts`, `detectStatusFromEmail.ts`, `statusRules.ts`

#### Email
- `email/matching.ts`

### 8.4 Admin Module (`src/modules/admin/`)

| Datei | Beschreibung |
|-------|-------------|
| `ai/KiConfigPage.tsx` | KI-Konfiguration |
| `billing/BillingPage.tsx` | Billing-Verwaltung |
| `customers/CustomersPage.tsx` | Kunden-Verwaltung |
| `documents/DocumentsPage.tsx` | Dokumente-Verwaltung |
| `emails/EmailsPage.tsx` | Email-Inbox |
| `logs/LogsPage.tsx` | Logs |
| `rules/RulesPage.tsx` | Regeln |
| `rules/RuleEditor.tsx` | Regel-Editor |
| `system/SystemDashboardPage.tsx` | System Dashboard |
| `tasks/TasksPage.tsx` | Aufgaben |
| `webhooks/WebhooksPage.tsx` | Webhooks |

### 8.5 Rechnungen (`src/modules/rechnungen/`)

- `InvoiceCreateModal.tsx` - Rechnung erstellen
- `InvoicePreview.tsx` - Rechnungsvorschau
- `SammelrechnungModal.tsx` - Sammelrechnung
- `useKundenSearch.ts` - Kunden-Suche Hook
- `api.ts`, `types.ts`

### 8.6 Rechnungs-Ordner (`src/modules/rechnungs-ordner/`)

- `CustomerFolderTree.tsx` - Kunden-Ordnerstruktur
- `InstallationInvoicePanel.tsx` - Installation-Rechnungen
- `InvoiceUploadZone.tsx` - Rechnungs-Upload
- `api.ts`

### 8.7 Emails (`src/modules/emails/`)

- `components/EmailBodyViewer.tsx` - Email-Body Anzeige
- `api.ts`, `types.ts`

### 8.8 Benutzer (`src/modules/benutzer/`)

- `BenutzerPage.tsx` - Benutzerverwaltung

### 8.9 Anlagen (`src/modules/anlagen/`)

- `AnlagenPage.tsx` - Anlagen-Seite

### 8.10 Abrechnung (`src/modules/abrechnung/`)

- `AbrechnungPage.tsx` - Abrechnungsseite

### 8.11 Wizard (`src/modules/wizard/`)

- `WizardPage.tsx` - Wizard-Seite
- `domain/wizardDomain.types.ts` - Wizard-Typen

### 8.12 Upload Queue (`src/modules/uploadQueue/`)

- `uploadQueue.ts` - Upload-Queue Logik
- `useUploadQueueRunner.ts` - Upload-Runner Hook

---

## 9. FINANZEN-MODUL (`src/finanzen-module/`)

| Datei | Beschreibung |
|-------|-------------|
| `index.tsx` | Hauptkomponente (Finanzen-Dashboard) |
| `api.ts` | API (fetchInvoices, createInvoice, etc.) |
| `types.ts` | Typen |
| `styles.ts` | Styled Components |
| `utils.ts` | Hilfsfunktionen |
| `hooks/useInvoices.ts` | Rechnungs-Hook |
| `hooks/useKeyboard.ts` | Keyboard Shortcuts |
| `hooks/useToast.ts` | Toast-Hook |
| `components/CommandPalette.tsx` | Command Palette (Cmd+K) |
| `components/FilterBar.tsx` | Filter-Leiste |
| `components/InvoiceCreateModal.tsx` | Rechnung erstellen |
| `components/InvoiceDetail.tsx` | Rechnungsdetail |
| `components/InvoiceGrid.tsx` | Rechnungs-Grid |
| `components/InvoiceTable.tsx` | Rechnungs-Tabelle |
| `components/KPICards.tsx` | KPI-Karten |
| `components/common/index.tsx` | Gemeinsame Komponenten |

---

## 10. ADMIN CENTER (`src/admin-center/`)

| Datei | Beschreibung |
|-------|-------------|
| `pages/AdminCenter/AdminCenterPage.tsx` | Hauptseite |
| `pages/AdminCenter/components/ActivityLogsComponent.tsx` | Aktivitaets-Logs |
| `pages/AdminCenter/components/AnnouncementsComponent.tsx` | Ankuendigungen |
| `pages/AdminCenter/components/BugReportsComponent.tsx` | Bug-Reports |
| `components/AutomationenTab.tsx` | Automatisierungen |
| `components/BankIntegrationTab.tsx` | Bank-Integration |
| `components/DocumentsTab.tsx` | Dokumente |
| `components/FieldsTab.tsx` | Felder-Konfiguration |
| `components/GridOperatorsTab.tsx` | Netzbetreiber |
| `components/OverviewTab.tsx` | Uebersicht |
| `components/PasswordsTab.tsx` | Passwoerter |
| `components/PlzMappingsTab.tsx` | PLZ-Zuordnungen |
| `components/RulesTab.tsx` | Regeln |
| `components/SettingsTab.tsx` | Einstellungen |
| `components/AnnouncementPopup/AnnouncementPopup.tsx` | Popup |

---

## 11. PORTAL (`src/portal/`)

| Datei | Beschreibung |
|-------|-------------|
| `PortalContext.tsx` | Portal Auth/State Context |
| `PortalLayout.tsx` | Portal Layout mit Navigation |
| `PortalRequireAuth.tsx` | Portal Auth-Guard |
| `api.ts` | Umfangreicher Portal API Client (~25 Funktionen) |
| `data/guideData.ts` | Hilfe-Texte |
| `components/AlertBanner.tsx` | Alert-Banner |
| `components/EmailModal.tsx` | Email-Detail Modal |
| `components/GuideDrawer.tsx` | Hilfe-Drawer |
| `components/InstallationCard.tsx` | Installation-Karte |
| `components/KundenfreigabeBanner.tsx` | Kundenfreigabe-Banner |
| `components/NotificationBell.tsx` | Benachrichtigungs-Glocke |
| `components/PortalStatusCard.tsx` | Status-Karte |
| `components/StatusTimeline.tsx` | Status-Timeline |

---

## 12. WIZARD (`src/wizard/`)

### Komponenten

#### Steps
- `components/wizard/steps/index.tsx` - Step-Router
- `components/wizard/step4/Step4Netzbetreiber.tsx` - NB-Eingabe
- `components/wizard/step4/NetzbetreiberPanel.tsx`, `NetzanschlussPanel.tsx`, `ZaehlerPanel.tsx`, `ZaehlerBestandItem.tsx`, `ZaehlerNeuConfig.tsx`, `MultiZaehlerPanel.tsx`
- `components/wizard/step4/useNetzbetreiber.ts`
- `components/wizard/step5/Step5Technik.tsx` - Technik-Eingabe
- `components/wizard/step5/SystemBuilder.tsx`, `ComponentRow.tsx`, `SystemStrip.tsx`, `SystemValidierung.tsx`, `AnalyseDashboard.tsx`, `ErtragsChart.tsx`, `WirtschaftlichkeitPanel.tsx`, `MesskonzeptPanel.tsx`, `BetriebsweisePanel.tsx`, `HybridSystemBanner.tsx`, `BuilderSection.tsx`, `VerbraucherRow.tsx`
- `components/wizard/step5/useHybridSystem.ts`, `useSolarAnalyse.ts`, `useSystemValidierung.ts`

#### AI
- `components/wizard/ai/AIAssistent.tsx`, `WizardSmartPanel.tsx`

#### Admin
- `components/wizard/admin/AdminModePanel.tsx`, `AdminUserSelector.tsx`

#### Shared
- `components/wizard/shared/CollapsibleSection.tsx`
- `components/wizard/shared/KompatibleSpeicherVorschlaege.tsx`
- `components/wizard/shared/ProduktAutocomplete.tsx`
- `components/wizard/shared/StreetAutocomplete.tsx`
- `components/wizard/shared/produktsuche/*.tsx` (ProduktSuchfeld, ProduktDropdownItem, TechDatenKarte, SearchStatusIndicator, useProduktSuche)

#### Sidebars
- `components/wizard/sidebars/LeftSidebar.tsx`, `RightSidebar.tsx`

#### Generators
- `components/wizard/generators/LageplanGenerator.ts`, `LageplanGeneratorV2.ts`, `SchaltplanGenerator.ts`, `StringplanGenerator.ts`, `VollmachtGenerator.ts`

#### Sonstige
- `components/wizard/WizardMain.tsx` - Wizard Hauptkomponente
- `components/wizard/LageplanEditor.tsx`
- `components/wizard/SmartSuggestions.tsx`
- `components/wizard/WizardInlineSuggestions.tsx`
- `components/wizard/UploadStatusNotification.tsx`
- `components/3d/Background3D.tsx`
- `components/ui/index.tsx`

### Libs
- `lib/api/` - API Client (client.ts, harmonized-client.ts, wizard.ts, netzbetreiber.ts, produkte.ts)
- `lib/intelligence/` - Intelligenz-Engine (analytics, compatibility, detector, ertrag, formulare, learningEngine, messkonzept, netzbetreiber, produktSync, scenarios, tipps, validation, wirtschaftlichkeit)
- `lib/maps/` - Kartengeneratoren (LageplanGenerator V1-V5, maptiler, openstreetmap)
- `lib/pdf/` - PDF-Generatoren (pdfGenerator V1+V2, LageplanPDF, SchaltplanPDF, VDEFormularePDF, VollmachtPDF, ProjektmappePDF)
- `lib/formulare/` - Formular-Generatoren (vdeGenerator, projektmappeGenerator)
- `lib/here.ts` - HERE Maps API
- `lib/plz/` - PLZ-Suche
- `lib/regelwerk/` - Regelwerk-Engine
- `lib/storage/` - Dokumenten-Speicher
- `lib/technik/` - Technik-Berechnungen
- `lib/stubs/` - Stubs fuer SSR (company, storage, tokenStorage, whiteLabel)
- `lib/netzbetreiber/` - NB-Logik
- `lib/utils/` - Hilfsfunktionen

---

## 13. DEBUG (`src/debug/`)

| Datei | Beschreibung |
|-------|-------------|
| `DebugPanel.tsx` | Debug-Panel (Entwicklung) |
| `ErrorBoundary.tsx` | Error Boundary |
| `logger.ts` | Debug-Logger |
| `store.ts` | Debug-State |

---

## 14. PROVIDERS

#### `src/providers/RealtimeProvider.tsx`
- **Beschreibung:** Echtzeit-Updates Provider (WebSocket)

---

## 15. CONFIG & UTILS

| Datei | Beschreibung |
|-------|-------------|
| `src/config/company.ts` | Firmen-Konfiguration |
| `src/config/storage.ts` | Storage Keys |
| `src/utils/autoLogout.ts` | Auto-Logout Timer |
| `src/utils/desktopClipboard.ts` | Desktop Clipboard |
| `src/utils/desktopDownload.ts` | Desktop Download |
| `src/utils/helpers.ts` | Allgemeine Helfer |
| `src/utils/sanitizeHtml.ts` | HTML Sanitizer |
| `src/utils/tokenRefresh.ts` | Token Refresh |
| `src/utils/userTracker.ts` | User Tracking |
| `src/shared/data/grid-operators.ts` | Netzbetreiber-Daten |
| `src/shared/data/seed-data.ts` | Seed-Daten |
| `src/shared/types/documents.ts` | Dokument-Typen |
| `src/shared/types/index.ts` | Shared Types |
| `src/shared/utils/index.ts` | Shared Utils |
| `src/types/dashboard.types.ts` | Dashboard-Typen |
| `src/lib/queryClient.ts` | React Query Client |
| `src/lib/sentry.ts` | Sentry Integration |
| `src/lib/serviceCatalog.ts` | Service-Katalog |
| `src/lib/generators/` | PDF-Generatoren (adapter, LageplanGenerator, SchaltplanGenerator, VDEFormulareGenerator, VollmachtGenerator) |
| `src/ai/mkEngine.ts` | AI-Engine |

---

## 16. VERWAISTE DATEIEN (nirgendwo importiert/geroutet)

### Seiten ohne Route im Router

| Datei | Grund |
|-------|-------|
| `src/pages/AlertsPage.tsx` | Deaktiviert: "Alert-System wird komplett ueberarbeitet" |
| `src/pages/WhatsAppIntegrationPage.tsx` | Entfernt: "Feature noch nicht ausgereift" |
| `src/pages/admin/EmailLearningCenter.tsx` | Deaktiviert: "wird neu konzipiert" |
| `src/pages/NbResponsePage.tsx` | Deaktiviert: "wird neu konzipiert" |
| `src/pages/AufgabenPage.tsx` | Entfernt: "ersetzt durch Ops Center" |
| `src/pages/WorkflowPage.tsx` | Entfernt: "ersetzt durch Ops Center" |
| `src/pages/WorkflowV2Page.tsx` | Nur Self-Import (WorkflowRouter) |
| `src/pages/DashboardPage.legacy.tsx` | Legacy-Dashboard, nicht geroutet |
| `src/pages/StammdatenPage.tsx` | Nur Self-Import |
| `src/pages/PasswordCenterPage.tsx` | Nicht geroutet |
| `src/pages/BenutzerPage.tsx` | Nicht geroutet (modules/benutzer/BenutzerPage existiert) |
| `src/pages/UsersPage.tsx` | Nicht geroutet |
| `src/pages/InstallationsPage.tsx` | Nicht geroutet |
| `src/pages/Netzbetreiber.tsx` | Nicht geroutet (NetzbetreiberCenterPage wird genutzt) |
| `src/pages/NetzanmeldungenPage.tsx` | Nicht geroutet (NetzanmeldungenEnterprise wird genutzt) |
| `src/pages/AbrechnungPage.tsx` | Nicht geroutet (modules/abrechnung und features/finanzen existieren) |
| `src/pages/AnlagenPage.tsx` | Nicht geroutet |
| `src/pages/MyPasswordPage.tsx` | Nicht geroutet |

### Verwaiste Services

| Datei | Grund |
|-------|-------|
| `src/services/installationsDelete.ts` | Nirgendwo importiert |
| `src/services/installationsUpdate.ts` | Nirgendwo importiert |
| `src/services/anlagen.service.ts` | Nirgendwo importiert |

### Verwaiste Komponente

| Datei | Grund |
|-------|-------|
| `src/App.tsx` | main.tsx nutzt eigene Provider-Struktur ohne App.tsx |

---

## 17. DUPLIZIERTE FUNKTIONALITAET

### API Clients (6-fach!)
1. `src/api/client.ts` - Fetch-basiert (PRIMARY)
2. `src/api/api.ts` - Axios (LEGACY)
3. `src/modules/api/client.ts` - Axios mit CSRF
4. `src/services/apiClient.ts` - Minimaler Fetch
5. `src/lib/api.ts` - Legacy Fetch ohne Auth
6. `src/features/netzanmeldungen/services/api.ts` - Eigener Fetch

**Empfehlung:** Konsolidierung auf 1-2 Clients (Fetch-basiert + Axios fuer Legacy)

### Rechnungen API (3-fach!)
1. `src/services/rechnungen.service.ts` - Service-Layer
2. `src/finanzen-module/api.ts` - Finanzen-Modul
3. `src/modules/rechnungen/api.ts` - Rechnungen-Modul

### Email-Verwaltung (3-fach!)
1. `src/api/emailInbox.ts` - Email-Inbox API
2. `src/services/emails.service.ts` - Email-Service
3. `src/features/control-center/components/tabs/communication/` - Vollstaendiges Email-Center

### StatusPill (3-fach!)
1. `src/components/ui/StatusPill.tsx`
2. `src/components/DashboardV2/components/StatusPill.tsx`
3. `src/features/netzanmeldungen/components/DashboardV2/sections/StatusPill.tsx`
4. `src/features/netzanmeldungen/components/ZaehlerwechselCenter/components/StatusPill.tsx`

### Installation Detail (3 Versionen!)
1. `src/modules/installations/detail/` - v1
2. `src/modules/installations/detail-v2/` - v2
3. `src/features/netzanmeldungen/components/DetailModal/` - Enterprise

### Dashboard (mehrfach!)
1. `src/modules/dashboard/Dashboard.tsx` - Aktiv
2. `src/modules/dashboard/admin/` - Admin Dashboard Modul
3. `src/components/DashboardV2/` - Dashboard V2 Komponenten
4. `src/pages/DashboardPage.legacy.tsx` - Legacy

### CommandPalette (3-fach!)
1. `src/components/features/CommandPalette.tsx`
2. `src/finanzen-module/components/CommandPalette.tsx`
3. `src/modules/installations/detail-v2/components/CommandPalette.tsx`
4. `src/modules/dashboard/admin/components/ui/CommandPalette.tsx`

### WorkflowPipeline (2-fach!)
1. `src/components/WorkflowPipeline.tsx`
2. `src/features/control-center/components/WorkflowPipeline.tsx`

### ActivityFeed (2-fach!)
1. `src/components/ActivityFeed.tsx`
2. `src/features/control-center/components/ActivityFeed.tsx`

---

## 18. STATISTIK

| Metrik | Wert |
|--------|------|
| **Gesamtdateien (ohne node_modules)** | ~822 |
| **Pages** | ~65 |
| **Features** | 15 Module |
| **API-Funktionen** | ~200+ |
| **Verwaiste Seiten** | ~18 |
| **Verwaiste Services** | 3 |
| **API-Endpoints (Backend)** | ~150+ verschiedene |
| **Duplizierte Bereiche** | 8+ signifikante |

---

## 19. ARCHITEKTUR-DIAGRAMM

```
main.tsx
  ErrorBoundary
    QueryClientProvider (TanStack Query)
      AuthProvider (pages/AuthContext.tsx)
        RealtimeProvider (WebSocket)
          WhiteLabelProvider
            AppRouter (router.tsx)
              TrackingProvider
                Routes
                  Oeffentliche Seiten (Login, Landing, AGB, etc.)
                  RequireAuth
                    AdminLayout (Sidebar + TopBar)
                      Alle Rollen: Dashboard, Netzanmeldungen, Wizard, etc.
                      Staff-Only: Emails, Kunden, NB, etc.
                      Admin-Only: Control Center, Admin Center, etc.
                  Portal
                    PortalRequireAuth
                      PortalProvider
                        PortalLayout
                          Portal-Seiten
```
