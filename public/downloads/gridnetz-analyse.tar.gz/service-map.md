# GridNetz Backend — Service-Map

> Stand: 2026-03-11 | Pfad: `/var/www/gridnetz-backend/src/services/`

---

## Inhaltsverzeichnis

1. [accounting/](#1-accounting)
2. [ai/](#2-ai)
3. [automations/](#3-automations)
4. [brain/](#4-brain)
5. [claude/](#5-claude)
6. [documentGenerator/](#6-documentgenerator)
7. [nbPortalProxy/](#7-nbportalproxy)
8. [nbPortal/](#8-nbportal)
9. [rag/](#9-rag)
10. [stromnetzBot/](#10-stromnetzbot)
11. [vdeFormular/](#11-vdeformular)
12. [whatsapp/](#12-whatsapp)
13. [workflowV2/](#13-workflowv2)
14. [Root-Level Services](#14-root-level-services)

---

## 1. accounting/

### accounting/index.ts
Re-exportiert alle Accounting-Sub-Services.

### accounting/account.service.ts
- **Zweck:** Kontenrahmen-Verwaltung (Chart of Accounts), Trial Balance
- **Prisma-Models:** `account`, `journalEntryLine`, `expenseCategory`
- **Imports:** prisma, @prisma/client
- **Externe APIs:** Keine
- **Cron-Jobs:** Keine
- **Exportierte Funktionen:**
  - `getAllAccounts()` — Alle Konten mit optionalem Balance abrufen
  - `getAccountById()` / `getAccountByCode()` — Einzelkonto-Abfrage
  - `createAccount()` / `updateAccount()` / `deactivateAccount()` — CRUD
  - `getAccountLedger()` — Kontobewegungen (General Ledger) mit Running Balance
  - `getTrialBalance()` — Saldenbilanz (Debit/Credit Prüfung)
  - `getExpenseCategories()` / `createExpenseCategory()` — Expense-Kategorien

### accounting/journal.service.ts
- **Zweck:** Doppelte Buchführung — Journal Entries erstellen und verwalten
- **Prisma-Models:** `journalEntry`, `journalEntryLine`, `account`, `rechnung`, `expense`, `wiseTransaction`
- **Imports:** prisma, accountService
- **Externe APIs:** Keine
- **Cron-Jobs:** Keine
- **Exportierte Funktionen:**
  - `createJournalEntry()` — Buchungssatz erstellen (Debit=Credit Validierung)
  - `postJournalEntry()` — Buchung finalisieren
  - `reverseJournalEntry()` — Storno-Buchung
  - `getJournalEntries()` / `getJournalEntryById()` — Abfrage
  - `bookInvoiceIssued()` — Automatische Buchung bei Rechnungsstellung (AR)
  - `bookPaymentReceived()` — Buchung bei Zahlungseingang
  - `bookExpenseCreated()` — Buchung bei Eingangsrechnung
  - `bookExpensePaid()` — Buchung bei Expense-Zahlung
  - `bookBankFee()` — Wise Bankgebühren buchen
  - `bookCurrencyConversion()` — Währungsumrechnung buchen
  - `bookIntercompanyExpense()` — Inter-Company Expense buchen

### accounting/expense.service.ts
- **Zweck:** Eingangsrechnungen (Accounts Payable) verwalten
- **Prisma-Models:** `expense`, `vendor`, `journalEntry`, `wiseTransaction`
- **Imports:** prisma, journalService
- **Externe APIs:** Keine
- **Cron-Jobs:** Keine
- **Exportierte Funktionen:**
  - `getExpenses()` / `getExpenseById()` — Abfrage mit Filter
  - `createExpense()` — Erstellen + automatische Buchung
  - `updateExpense()` / `markExpenseAsPaid()` — Status-Management
  - `voidExpense()` — Stornieren (inkl. Journal-Storno)
  - `deleteExpense()` — Löschen (nur ohne Buchungen)
  - `attachDocument()` — Dokument anhängen
  - `getExpenseStats()` — Statistiken (by Category, by Vendor, Overdue)
  - `createExpenseFromWiseTransaction()` — Expense aus Wise-Transaktion anlegen

### accounting/vendor.service.ts
- **Zweck:** Lieferanten-Verwaltung
- **Prisma-Models:** `vendor`, `expense`, `legalEntity`
- **Imports:** prisma
- **Externe APIs:** Keine
- **Cron-Jobs:** Keine
- **Exportierte Funktionen:**
  - `getVendors()` / `getVendorById()` — CRUD
  - `createVendor()` / `updateVendor()` / `deleteVendor()`
  - `getVendorStats()` — Statistiken pro Vendor (by Month, by Category)
  - `searchVendors()` — Autocomplete-Suche
  - `getOrCreateIntercompanyVendor()` — IC-Vendor für Legal Entity

### accounting/reports.service.ts
- **Zweck:** Finanzberichte: P&L, Bilanz, Cash Flow, Dashboard
- **Prisma-Models:** `rechnung`, `expense`, `wiseAccount`, `journalEntry`
- **Imports:** prisma, accountService
- **Externe APIs:** Keine
- **Cron-Jobs:** Keine
- **Exportierte Funktionen:**
  - `getIncomeStatement()` — Gewinn- und Verlustrechnung (P&L)
  - `getBalanceSheet()` — Bilanz
  - `getDashboardSummary()` — Dashboard (YTD, MTD, AR, AP, Cash)
  - `getIntercompanyReport()` — Inter-Company Transaktions-Report
  - `getGeneralLedgerExport()` — General Ledger für CSV
  - `getCashFlowStatement()` — Cash Flow (vereinfacht)

### accounting/exchangeRate.service.ts
- **Zweck:** Wechselkurse verwalten, von Wise API abrufen
- **Prisma-Models:** `exchangeRate`
- **Imports:** prisma
- **Externe APIs:** `https://api.wise.com/v1/rates` (Wechselkurse)
- **Cron-Jobs:** Keine (manuell via `syncExchangeRates()`)
- **Exportierte Funktionen:**
  - `getExchangeRate()` — Kurs für Datum (DB → Wise API → Fallback)
  - `convertAmount()` — Betrag umrechnen
  - `getExchangeRateHistory()` — Kurs-Historie
  - `syncExchangeRates()` — EUR/USD Kurse synchronisieren
  - `setExchangeRate()` — Manuellen Kurs setzen
  - `getAverageRate()` — Durchschnittskurs für Zeitraum

### accounting/yearEnd.service.ts
- **Zweck:** Jahresabschluss, Closing Entries, Tax Package Export
- **Prisma-Models:** `fiscalYear`, `journalEntry`, `wiseTransaction`, `rechnung`, `expense`
- **Imports:** prisma, accountService, journalService, reportsService, archiver
- **Externe APIs:** Keine
- **Cron-Jobs:** Keine
- **Exportierte Funktionen:**
  - `getFiscalYears()` / `createFiscalYear()` — Fiscal Year Management
  - `validateYearEnd()` — Validierung vor Abschluss
  - `createClosingEntries()` — Revenue/Expense → Retained Earnings
  - `closeFiscalYear()` — Kompletter Jahresabschluss
  - `generateTaxPackage()` — ZIP mit CSVs + PDFs für Steuer

### accounting/aiChat.service.ts
- **Zweck:** Buchhaltungs-Chat-Assistent
- **Prisma-Models:** `rechnung`, `expense` (via reportsService)
- **Imports:** prisma, OpenAI, reportsService, aiInsightsService
- **Externe APIs:** OpenAI gpt-4o-mini
- **Cron-Jobs:** Keine
- **Exportierte Funktionen:**
  - `processChat()` — Chat-Nachricht verarbeiten (mit Finanzkontext)

### accounting/aiExtraction.service.ts
- **Zweck:** PDF-Rechnungen auslesen mit KI
- **Prisma-Models:** `vendor`
- **Imports:** prisma, OpenAI, pdf-parse
- **Externe APIs:** OpenAI gpt-4o-mini (Rechnungsdaten-Extraktion)
- **Cron-Jobs:** Keine
- **Exportierte Funktionen:**
  - `extractInvoiceData()` — PDF → strukturierte Daten (KI oder Regex-Fallback)
  - `matchVendor()` — Vendor-Zuordnung (exakt + fuzzy)

### accounting/aiInsights.service.ts
- **Zweck:** Finanz-Analysen, Anomalie-Erkennung
- **Prisma-Models:** `rechnung`, `expense`, `wiseTransaction`, `accountingAnomaly`, `kunde`
- **Imports:** prisma, reportsService
- **Externe APIs:** Keine
- **Cron-Jobs:** Keine (detectAnomalies() wird extern aufgerufen)
- **Exportierte Funktionen:**
  - `getMonthlyInsights()` — Monatliche Zusammenfassung + Insights
  - `detectAnomalies()` — Duplikate, hohe Ausgaben, ungematchte TX erkennen
  - `getActiveAnomalies()` / `resolveAnomaly()` — Anomalie-Management
  - `getTopExpenseCategories()` / `getTopCustomers()` — Ranking

### accounting/aiMatching.service.ts
- **Zweck:** Intelligentes Matching von Wise-Transaktionen zu Rechnungen
- **Prisma-Models:** `wiseTransaction`, `rechnung`, `kunde`
- **Imports:** prisma
- **Externe APIs:** Keine
- **Cron-Jobs:** Keine
- **Exportierte Funktionen:**
  - `getMatchSuggestions()` — Match-Vorschläge mit Scoring (0-100)
  - `getUnmatchedWithSuggestions()` — Alle ungematchten TX analysieren
  - `runAutoMatching()` — Auto-Match bei hoher Konfidenz (>=90)
  - `getMatchingStats()` — Statistiken (Match-Rate, Auto vs Manual)

---

## 2. ai/

### ai/index.ts
Re-exportiert emailAutomationService, localAIService.

### ai/emailAutomation.service.ts
- **Zweck:** Email-Automatisierung, NB-Response-Orchestrierung, Factro-Kommentar-Erstellung
- **Prisma-Models:** `email`, `installation`, `netzbetreiber`, `document`, `nbResponseTask`, `factroProject`, `emailClassification`
- **Imports:** prisma, OpenAI, emailPipelineService, emailMatcherService
- **Externe APIs:** OpenAI gpt-4o-mini, `https://cloud.factro.com/api/core` (Kommentar-Erstellung)
- **Cron-Jobs:** Keine
- **Exportierte Funktionen:**
  - `processIncomingEmail()` — Eingehende NB-Email verarbeiten
  - `generateNbResponse()` — NB-Antwort generieren
  - `createNbResponseTask()` — NB-Response-Task erstellen
  - `executeNbResponseTask()` — Task ausführen (Email senden)

### ai/openaiClassifier.service.ts
- **Zweck:** Email-Klassifikation mit OpenAI (Primary LLM)
- **Prisma-Models:** Keine direkt
- **Imports:** OpenAI
- **Externe APIs:** `https://api.openai.com/v1/chat/completions` (gpt-4o-mini)
- **Cron-Jobs:** Keine
- **Exportierte Funktionen:**
  - `classifyEmail()` — Email klassifizieren (Kategorie, Sentiment, Dringlichkeit)

### ai/localAI.service.ts
- **Zweck:** Lokale KI mit Ollama (llama3.1:8b, Parallel-LLM)
- **Prisma-Models:** Keine
- **Imports:** Keine Service-Imports
- **Externe APIs:** `http://localhost:11434/api/generate` (Ollama), `/api/tags`
- **Cron-Jobs:** Keine
- **Exportierte Funktionen:**
  - `classifyEmailLocal()` — Lokale Email-Klassifikation
  - `isAvailable()` — Ollama-Verfügbarkeit prüfen

---

## 3. automations/

### automations/index.ts
Re-exportiert alle Automation-Sub-Services.

### automations/bulkNbSubmission.ts
- **Zweck:** Bulk-Netzanmeldung (Status WARTEN_AUF_NB automatisch setzen)
- **Prisma-Models:** `installation`, `document`
- **Imports:** prisma, documentCompleteness, brainEventHooks
- **Externe APIs:** Keine
- **Cron-Jobs:** Keine (von extern aufgerufen)
- **Exportierte Funktionen:**
  - `bulkSubmitToNb()` — Alle bereiten Installationen an NB senden

### automations/documentCompleteness.ts
- **Zweck:** Dokument-Vollständigkeitsprüfung
- **Prisma-Models:** `installation`, `document`
- **Imports:** prisma, featureFlags
- **Externe APIs:** Keine
- **Cron-Jobs:** Keine
- **Exportierte Funktionen:**
  - `checkDocumentCompleteness()` — Prüft ob alle Pflichtdokumente vorhanden

### automations/healthMonitor.ts
- **Zweck:** System-Health-Checks (DB, Redis, Disk, Cron-Status)
- **Prisma-Models:** `cronJobLog`
- **Imports:** prisma, execSync, emailGateway, redis
- **Externe APIs:** Slack Webhook (Alerts)
- **Cron-Jobs:** Alle 5 Minuten
- **Exportierte Funktionen:**
  - `runAllHealthChecks()` — Kompletter Health-Check

### automations/hvReport.ts
- **Zweck:** Handelsvertreter-Reports (monatlich)
- **Prisma-Models:** `handelsvertreter`, `installation`, `provision`
- **Imports:** prisma, PDFKit, emailGateway, featureFlags
- **Externe APIs:** Keine
- **Cron-Jobs:** 5. des Monats um 7:00
- **Exportierte Funktionen:**
  - `generateHvReport()` — PDF-Report generieren
  - `sendHvReports()` — Reports an alle HV versenden

### automations/mahnwesen.ts
- **Zweck:** Automatisches Mahnwesen (Zahlungserinnerungen)
- **Prisma-Models:** `rechnung`, `kunde`, `mahnung`
- **Imports:** prisma, emailGateway, featureFlags
- **Externe APIs:** Keine
- **Cron-Jobs:** Täglich um 8:00
- **Exportierte Funktionen:**
  - `findOverdueInvoices()` — Überfällige Rechnungen finden
  - `escalateInvoice()` — Mahnstufe erhöhen
  - `runMahnwesenCron()` — Cron-Hauptfunktion

### automations/nbEmailRecognition.ts
- **Zweck:** Automatische NB-Email-Erkennung (Genehmigung/Rückfrage/Ablehnung)
- **Prisma-Models:** `email`, `installation`, `netzbetreiber`
- **Imports:** prisma, featureFlags, inboxItemGenerator, brainEventHooks, evuLearning, workflowV2/eventService
- **Externe APIs:** Keine
- **Cron-Jobs:** Alle 30 Minuten
- **Exportierte Funktionen:**
  - `recognizeNbEmails()` — NB-Emails analysieren und klassifizieren

### automations/provisionPayout.ts
- **Zweck:** Provisions-Auszahlung (monatlich)
- **Prisma-Models:** `provision`, `handelsvertreter`, `provisionAuszahlung`
- **Imports:** prisma, emailGateway, featureFlags
- **Externe APIs:** Keine
- **Cron-Jobs:** 1. des Monats um 6:00
- **Exportierte Funktionen:**
  - `processProvisionPayouts()` — Fällige Provisionen auszahlen

### automations/reminderCron.ts
- **Zweck:** Erinnerungs-Crons (Rückfrage-Reminder, IBN-Protokoll-Reminder)
- **Prisma-Models:** `installation`, `email`
- **Imports:** prisma, emailGateway, featureFlags, redis
- **Externe APIs:** Keine
- **Cron-Jobs:** Täglich um 9:00
- **Exportierte Funktionen:**
  - `sendRueckfrageReminders()` — Rückfrage-Erinnerungen
  - `sendIbnProtokollReminders()` — IBN-Protokoll-Erinnerungen

---

## 4. brain/

### brain/brainEventHooks.ts
- **Zweck:** Event-Tracking für Self-Learning Brain (Status-Änderungen, Emails, etc.)
- **Prisma-Models:** `learningEvent`, `brainKnowledge`
- **Imports:** prisma
- **Externe APIs:** Keine
- **Cron-Jobs:** Keine
- **Exportierte Funktionen:**
  - `trackInstallationStatusChanged()` — Status-Änderung tracken
  - `trackEmailReceived()` / `trackEmailSent()` — Email-Events
  - `trackNbSuggestion()` / `trackNbAlert()` — NB-Events
  - `trackEvuEventLearned()` / `trackEvuAnalysisCompleted()` / `trackEvuWarningsGenerated()`
  - `deriveBusinessKnowledge()` — Geschäftswissen aus Events ableiten

---

## 5. claude/

### claude/claudeCodeClient.ts
- **Zweck:** Claude Code CLI Client für Terminal-Integration
- **Prisma-Models:** Keine
- **Imports:** child_process
- **Externe APIs:** Claude CLI (lokaler Prozess)
- **Cron-Jobs:** Keine
- **Exportierte Funktionen:**
  - `executeClaudeCommand()` — Claude Code Befehl ausführen

---

## 6. documentGenerator/

### documentGenerator/index.ts
- **Zweck:** Orchestrator für Dokument-Generierung
- **Prisma-Models:** `document`, `installation`
- **Imports:** prisma, dataAdapter, schaltplanGenerator, vollmacht, lageplan
- **Externe APIs:** Keine
- **Cron-Jobs:** Keine
- **Exportierte Funktionen:**
  - `generateDocuments()` — Alle Dokumente für Installation generieren
  - `generateSingleDocument()` — Einzelnes Dokument generieren

### documentGenerator/dataAdapter.ts
- **Zweck:** Installationsdaten für Dokumentgenerierung aufbereiten
- **Prisma-Models:** `installation`, `kunde`, `netzbetreiber`, `document`
- **Imports:** prisma
- **Externe APIs:** Keine
- **Exportierte Funktionen:**
  - `assembleDocumentData()` — Daten aus DB zusammenstellen

### documentGenerator/lageplan.ts
- **Zweck:** Lageplan-PDF generieren (mit Satellitenbild)
- **Prisma-Models:** Keine
- **Imports:** PDFKit, pdfHelpers
- **Externe APIs:**
  - `https://maps.googleapis.com/maps/api/geocode/json` (Geocoding)
  - `https://maps.googleapis.com/maps/api/staticmap` (Satellitenbild)
  - `https://nominatim.openstreetmap.org/search` (Fallback Geocoding)
  - `https://api.maptiler.com/maps/satellite/static/` (Fallback Satellitenbild)
- **Exportierte Funktionen:**
  - `generateLageplan()` — Lageplan-PDF erstellen

### documentGenerator/schaltplan.ts
- **Zweck:** Schaltplan-PDF generieren (PDFKit-Version)
- **Prisma-Models:** Keine
- **Imports:** PDFKit, pdfHelpers, symbols
- **Externe APIs:** Keine
- **Exportierte Funktionen:**
  - `generateSchaltplanPdf()` — Schaltplan-PDF erstellen

### documentGenerator/schaltplanGeneratorPython.ts
- **Zweck:** Schaltplan via Python-Script generieren
- **Prisma-Models:** Keine
- **Imports:** execFile, child_process
- **Externe APIs:** Keine (lokaler Python-Prozess)
- **Exportierte Funktionen:**
  - `generateSchaltplan()` — Python-Schaltplan-Generator aufrufen

### documentGenerator/vollmacht.ts
- **Zweck:** Vollmacht-PDF generieren
- **Prisma-Models:** Keine
- **Imports:** PDFKit, pdfHelpers
- **Externe APIs:** Keine
- **Exportierte Funktionen:**
  - `generateVollmacht()` — Vollmacht-PDF erstellen

### documentGenerator/shared/constants.ts, pdfHelpers.ts, symbols.ts, types.ts
- Shared Utilities: Farben, Fonts, Margins, PDF-Helper-Funktionen, Symbole, TypeScript-Types.

---

## 7. nbPortalProxy/

### nbPortalProxy/index.ts
Re-exportiert proxyService, sessionPool.

### nbPortalProxy/proxyService.ts
- **Zweck:** Netzbetreiber-Portal Proxy (Stromnetz Berlin, E.DIS, Westnetz)
- **Prisma-Models:** Keine
- **Imports:** Keine Prisma-Imports
- **Externe APIs:**
  - `https://kundenportal.stromnetz.berlin`
  - `https://www.e-dis-netz.de`
  - `https://www.westnetz.de`
- **Exportierte Funktionen:**
  - `createSession()` — Portal-Session erstellen
  - `submitForm()` — Formular an NB-Portal senden
  - `getPortalStatus()` — Status im Portal abrufen

### nbPortalProxy/reverseProxy.ts
- **Zweck:** Reverse Proxy für Stromnetz Berlin Portal
- **Prisma-Models:** Keine
- **Externe APIs:** `https://kundenportal.stromnetz.berlin` (Login, Page-Fetching)
- **Exportierte Funktionen:**
  - `login()` — Portal-Login
  - `getPage()` / `getResource()` — Seiten/Ressourcen abrufen
  - `submitForm()` — Formular absenden

### nbPortalProxy/sessionPool.ts
- **Zweck:** Session-Pool für NB-Portal-Verbindungen
- **Prisma-Models:** Keine
- **Imports:** Keine Prisma-Imports
- **Cron-Jobs:** `setInterval` alle 60s für Session-Cleanup
- **Exportierte Funktionen:**
  - `getSession()` / `createSession()` / `destroySession()`
  - `cleanupExpiredSessions()`

### nbPortalProxy/securityFilter.ts
- **Zweck:** Sicherheitsfilter für Proxy-Requests (XSS, CSRF)
- **Prisma-Models:** Keine
- **Exportierte Funktionen:**
  - `filterHtml()` — HTML filtern und Sicherheits-Scripts injizieren

### nbPortalProxy/types.ts
Type-Definitionen für NB-Portal-Proxy.

---

## 8. nbPortal/

### nbPortal/stromnetzBerlin.ts
- **Zweck:** Stromnetz Berlin Portal-Integration (API-Client)
- **Prisma-Models:** Keine
- **Externe APIs:** `https://kundenportal.stromnetz.berlin`, `https://api.stromnetz.berlin`
- **Exportierte Funktionen:**
  - `login()`, `getApplications()`, `submitApplication()`, `getStatus()`, `uploadDocument()`

---

## 9. rag/

### rag/autoReindexService.ts
- **Zweck:** Auto-Reindex Scheduler mit Change Detection
- **Prisma-Models:** Diverse (je nach Kategorie — installation, email, netzbetreiber, etc.)
- **Imports:** pgvector Pool, embeddingService, indexingService
- **Externe APIs:** Keine
- **Cron-Jobs:** `setInterval` alle 60 Minuten
- **Exportierte Funktionen:**
  - `runIncrementalReindex()` — Inkrementeller Reindex
  - `startAutoReindexScheduler()` / `stopAutoReindexScheduler()`

### rag/chunkingService.ts
- **Zweck:** Text-Chunking für RAG (Splitting + Overlap)
- **Prisma-Models:** Keine
- **Exportierte Funktionen:**
  - `chunkText()` — Text in Chunks aufteilen
  - `chunkDocuments()` — Dokumente chunken

### rag/embeddingService.ts
- **Zweck:** OpenAI Embeddings generieren (text-embedding-3-small)
- **Prisma-Models:** Keine
- **Imports:** OpenAI
- **Externe APIs:** OpenAI Embeddings API
- **Exportierte Funktionen:**
  - `generateEmbedding()` — Einzelnes Embedding
  - `generateEmbeddings()` — Batch-Embeddings

### rag/enterpriseRagService.ts
- **Zweck:** Enterprise RAG mit Query-Router, Reranking, Contextual Compression
- **Prisma-Models:** `ragQueryLog`
- **Imports:** pgvector Pool, embeddingService, chunkingService
- **Externe APIs:** OpenAI (Embeddings)
- **Exportierte Funktionen:**
  - `getSmartContext()` — Enterprise Entry-Point für RAG-Queries
  - `queryWithReranking()` — Query mit heuristischem Reranking

### rag/indexingService.ts
- **Zweck:** Dokumente in pgvector indexieren
- **Prisma-Models:** Diverse (je nach Kategorie)
- **Imports:** pgvector Pool, embeddingService, chunkingService
- **Externe APIs:** Keine
- **Exportierte Funktionen:**
  - `indexCategory()` — Kategorie indexieren
  - `reindexAll()` — Alle Kategorien neu indexieren

---

## 10. stromnetzBot/

### stromnetzBot/index.ts
Re-exportiert StromnetzBerlinBot.

### stromnetzBot/StromnetzBerlinBot.ts
- **Zweck:** Puppeteer-Bot für Stromnetz Berlin Portal-Automation
- **Prisma-Models:** Keine
- **Imports:** puppeteer
- **Externe APIs:** `https://kundenportal.stromnetz.berlin`
- **Exportierte Funktionen:**
  - `login()` — Browser-Login
  - `submitApplication()` — Antrag einreichen
  - `checkStatus()` — Status prüfen

---

## 11. vdeFormular/

### vdeFormular/installationDataAssembler.ts
- **Zweck:** Installationsdaten für VDE-Formulare aufbereiten
- **Prisma-Models:** `installation`, `kunde`, `netzbetreiber`, `document`
- **Imports:** prisma
- **Exportierte Funktionen:**
  - `assembleInstallationData()` — Daten aus DB für VDE-Formular zusammenstellen

---

## 12. whatsapp/

### whatsapp/claudeBot.service.ts
- **Zweck:** Claude-basierter WhatsApp-Bot
- **Prisma-Models:** `installation`, `whatsAppConversation`
- **Imports:** prisma, OpenAI/Anthropic, whatsappContext
- **Externe APIs:** Claude/OpenAI API
- **Exportierte Funktionen:**
  - `processMessage()` — Nachricht verarbeiten und Antwort generieren

### whatsapp/learningEngine.service.ts
- **Zweck:** WhatsApp Conversation Learning
- **Prisma-Models:** `whatsAppConversation`, `learningEvent`
- **Imports:** prisma
- **Exportierte Funktionen:**
  - `learnFromConversation()` — Aus Konversation lernen

### whatsapp/productMatcher.service.ts
- **Zweck:** Produkt-Matching aus WhatsApp-Nachrichten
- **Prisma-Models:** `produkt`, `wechselrichter`, `speicherSystem`
- **Imports:** prisma
- **Exportierte Funktionen:**
  - `matchProducts()` — Produkte in Nachricht erkennen

### whatsapp/whatsappContext.service.ts
- **Zweck:** Kontext-Aufbau für WhatsApp-Konversationen
- **Prisma-Models:** `installation`, `kunde`, `netzbetreiber`, `netzanfrageRequest`
- **Imports:** prisma
- **Exportierte Funktionen:**
  - `buildContext()` — Konversationskontext zusammenstellen

### whatsapp/whatsappConversation.service.ts
- **Zweck:** Konversations-Management (State Machine)
- **Prisma-Models:** `whatsAppConversation`, `whatsAppUserLink`
- **Imports:** prisma
- **Cron-Jobs:** Cleanup expired conversations
- **Exportierte Funktionen:**
  - `getOrCreateConversation()` — Konversation starten/fortsetzen
  - `updateConversationState()` — State aktualisieren
  - `cleanupExpiredConversations()`

### whatsapp/whatsappMedia.service.ts
- **Zweck:** WhatsApp Medien-Download und -Verarbeitung
- **Prisma-Models:** `document`
- **Imports:** prisma
- **Externe APIs:** Wassenger API (Medien-Download)
- **Exportierte Funktionen:**
  - `downloadMedia()` — Media-Datei herunterladen
  - `processMediaMessage()` — Medien-Nachricht verarbeiten

### whatsapp/whatsappMessage.service.ts
- **Zweck:** WhatsApp Nachrichten senden/empfangen via Wassenger
- **Prisma-Models:** Keine
- **Externe APIs:** `https://api.wassenger.com/v1/messages`, `/files`
- **Exportierte Funktionen:**
  - `sendMessage()` — Nachricht senden
  - `sendMediaMessage()` — Medien senden
  - `getMessageHistory()` — Verlauf abrufen

### whatsapp/whatsappRouter.service.ts
- **Zweck:** Routing eingehender WhatsApp-Nachrichten
- **Prisma-Models:** `whatsAppUserLink`
- **Imports:** prisma, claudeBot, productMatcher
- **Exportierte Funktionen:**
  - `routeMessage()` — Nachricht an richtigen Handler weiterleiten

### whatsapp/whatsappWebhook.service.ts
- **Zweck:** Wassenger Webhook-Verarbeitung
- **Prisma-Models:** `whatsAppMessage`
- **Imports:** prisma, redis, whatsappRouter
- **Externe APIs:** Wassenger Webhook (eingehend)
- **Exportierte Funktionen:**
  - `handleWebhook()` — Webhook verarbeiten

---

## 13. workflowV2/

### workflowV2/types.ts
Type-Definitionen: Phase, Zustand, PhaseZustand, EventType, DeadlineType, InboxPriority, InboxAction, SourceType.

### workflowV2/statusMapping.ts
- **Zweck:** Mapping zwischen Legacy-Status und Phase/Zustand
- **Exportierte Funktionen:**
  - `statusToPhaseZustand()` — Legacy → V2
  - `phaseZustandToStatus()` — V2 → Legacy

### workflowV2/dualWrite.ts
- **Zweck:** Dual-Write Bridge (Legacy + V2 synchron halten)
- **Prisma-Models:** `installation`, `installationEvent`
- **Imports:** prisma, featureFlags, statusMapping, eventService
- **Exportierte Funktionen:**
  - `dualWriteStatus()` — Status in beiden Systemen schreiben

### workflowV2/eventService.ts
- **Zweck:** Event-System für WorkflowV2
- **Prisma-Models:** `installationEvent`
- **Imports:** prisma, inboxItemFactory, automationEngine
- **Exportierte Funktionen:**
  - `createEvent()` — Event erstellen und an Automations/InboxFactory weiterleiten

### workflowV2/transitionService.ts
- **Zweck:** Status-Transitionen mit Validierung und Deadline-Management
- **Prisma-Models:** `installation`, `installationEvent`, `inboxItem`
- **Imports:** prisma, eventService, statusMapping, workflow.service, portalNotificationCreator
- **Exportierte Funktionen:**
  - `transition()` — Status-Transition ausführen
  - `canTransition()` — Transition validieren

### workflowV2/automationEngine.ts
- **Zweck:** Automatische Aktionen bei Events (Notifications, Tasks)
- **Prisma-Models:** `installation`
- **Imports:** prisma
- **Exportierte Funktionen:**
  - `runAutomations()` — Automationen für Event ausführen

### workflowV2/inboxItemFactory.ts
- **Zweck:** InboxItems aus Events generieren (Aufgaben-Queue)
- **Prisma-Models:** `inboxItem`, `installation`
- **Imports:** prisma
- **Cron-Jobs:** Deadline-Check alle 15 Min
- **Exportierte Funktionen:**
  - `processEvent()` — Event → InboxItem
  - `checkDeadlines()` — Überfällige Deadlines prüfen

---

## 14. Root-Level Services

### anomalyDetection.service.ts
- **Zweck:** Anomalie-Erkennung in Installation-Daten
- **Prisma-Models:** `installation`, `statusHistory`
- **Exportierte Funktionen:** `detectAnomalies()`, `getAnomalyReport()`

### autoInvoice.service.ts
- **Zweck:** Automatische Rechnungserstellung bei Status-Änderung
- **Prisma-Models:** `installation`, `rechnung`, `kunde`, `invoiceCounter`
- **Exportierte Funktionen:** `generateInvoiceForInstallation()`, `runAutoInvoiceCron()`

### backupService.ts
- **Zweck:** Datenbank- und Upload-Backups
- **Prisma-Models:** Keine (direkter pg_dump)
- **Externe APIs:** Keine
- **Cron-Jobs:** `runFullBackup()` ist Cron-ready
- **Exportierte Funktionen:** `createDatabaseBackup()`, `backupUploads()`, `listBackups()`, `cleanupOldBackups()`, `runFullBackup()`

### betreiberChat.service.ts
- **Zweck:** Chat zwischen Betreiber und Installation (via WhatsApp/Portal)
- **Prisma-Models:** `installation`, `whatsAppUserLink`, `installationMessage`, `document`, `messageTemplate`
- **Imports:** whatsappMessageService, whatsappMediaService
- **Exportierte Funktionen:** `sendMessage()`, `getMessages()`, `handleIncomingWhatsApp()`

### bookingEmail.service.ts
- **Zweck:** Booking-Bestätigungs-Emails
- **Prisma-Models:** `installation`, `kunde`
- **Exportierte Funktionen:** `sendBookingConfirmation()`

### cacheService.ts
- **Zweck:** Map-basierter Cache mit TTL (max 100 Entries)
- **Prisma-Models:** Keine
- **Exportierte Funktionen:** `get()`, `set()`, `delete()`, `clear()`

### claudeAI.service.ts
- **Zweck:** Claude AI Integration für Installation-Insights
- **Prisma-Models:** `installation`, `document`, `email`, `statusHistory`
- **Externe APIs:** Anthropic Claude API
- **Exportierte Funktionen:** `getInstallationInsights()`, `generateSummary()`

### cronRegistry.ts
- **Zweck:** Cron-Job-Registry für Monitoring
- **Prisma-Models:** Keine
- **Exportierte Funktionen:** `register()`, `markStarted()`, `markCompleted()`, `getAll()`

### documentBatchProcessor.ts
- **Zweck:** Batch-Verarbeitung von Dokumenten (Email-Versand gesammelt)
- **Prisma-Models:** `document`, `installation`
- **Exportierte Funktionen:** `processBatch()`, `queueDocument()`

### documentType.service.ts
- **Zweck:** Dokumenttyp-Erkennung und -Verwaltung
- **Prisma-Models:** `documentType`, `document`
- **Exportierte Funktionen:** `detectDocumentType()`, `getDocumentTypes()`

### efkSignature.service.ts
- **Zweck:** EFK-Unterschriften-Verwaltung (PNG/JPEG)
- **Prisma-Models:** `efkSignature`
- **Exportierte Funktionen:** `createSignature()`, `getSignatures()`, `setDefault()`, `deleteSignature()`

### emailAttachment.service.ts
- **Zweck:** Email-Anhänge mit SHA-256 Duplikaterkennung
- **Prisma-Models:** `emailAttachment`
- **Exportierte Funktionen:** `saveAttachment()`, `getAttachments()`, `downloadAttachment()`

### emailAutoreply.service.ts
- **Zweck:** Automatische Email-Antworten
- **Prisma-Models:** `email`, `installation`
- **Exportierte Funktionen:** `checkAndSendAutoreply()`

### emailEscalation.service.ts
- **Zweck:** Email-Eskalation (unbeantwortete Emails)
- **Prisma-Models:** `email`, `emailEscalation`, `installation`
- **Cron-Jobs:** Täglich 10:00 Check, alle 30 Min Execution
- **Exportierte Funktionen:** `checkForEscalations()`, `executeScheduledEscalations()`

### emailGateway.service.ts
- **Zweck:** Email-Versand via Nodemailer (SMTP)
- **Prisma-Models:** `emailLog`
- **Externe APIs:** SMTP (smtp.gridnetz.de o.ä.)
- **Exportierte Funktionen:** `send()` — Email versenden

### emailInbox.service.ts
- **Zweck:** IMAP Email-Inbox (Polling + Verarbeitung)
- **Prisma-Models:** `email`, `emailClassification`, `installation`
- **Imports:** ImapFlow, mailparser, emailAutomationService, localAIService, emailPipeline, emailMatcher, brainEventHooks
- **Cron-Jobs:** `setInterval` (Poll-Interval)
- **Exportierte Funktionen:** `start()`, `stop()`, `poll()`

### emailMatcher.service.ts
- **Zweck:** Email-zu-Installation Matching (Domain-basiert, Betreff, Inhalt)
- **Prisma-Models:** `installation`, `netzbetreiber`, `email`
- **Exportierte Funktionen:** `matchEmailToInstallation()`, `getDomainMapping()`

### emailPipeline.service.ts
- **Zweck:** Email-Verarbeitungs-Pipeline (Dual-LLM Klassifikation, Guards)
- **Prisma-Models:** `email`, `emailClassification`, `nbResponseTask`, `installation`
- **Imports:** openaiClassifier, localAI, emailMatcher, zaehlerwechselTermin
- **Externe APIs:** Keine (delegiert an AI-Services)
- **Exportierte Funktionen:** `processEmail()` — Haupt-Pipeline

### emailSend.service.ts
- **Zweck:** Email-Versand Wrapper (mit Template-Rendering)
- **Prisma-Models:** `emailLog`
- **Imports:** emailGateway, emailTemplate
- **Exportierte Funktionen:** `sendTemplateEmail()`, `sendRawEmail()`

### email.service.ts
- **Zweck:** Email-Queue-System (PENDING → SCHEDULED → SENT)
- **Prisma-Models:** `emailQueueItem`, `emailTemplate`
- **Cron-Jobs:** Alle 2 Minuten Queue-Processing
- **Exportierte Funktionen:** `enqueueEmail()`, `processQueue()`

### emailTemplate.service.ts
- **Zweck:** Email-Template-Verwaltung (MJML + Handlebars)
- **Prisma-Models:** `emailTemplate`
- **Imports:** Handlebars, MJML
- **Exportierte Funktionen:** `renderTemplate()`, `getTemplate()`, `createTemplate()`

### endkundenContactGuard.ts
- **Zweck:** Consent-Prüfung vor Endkunden-Kontakt (Email/WhatsApp)
- **Prisma-Models:** `installation`, `kunde`
- **Exportierte Funktionen:** `checkEmailConsent()`, `checkWhatsAppConsent()`

### energyPrices.service.ts
- **Zweck:** Strompreise abrufen
- **Prisma-Models:** Keine
- **Externe APIs:** `https://api.energy-charts.info/price?bzn=DE-LU&resolution=year`
- **Exportierte Funktionen:** `getCurrentPrices()`

### evuLearning.service.ts
- **Zweck:** EVU/NB-spezifisches Learning (Anforderungen, Muster)
- **Prisma-Models:** `netzbetreiber`, `installation`, `email`, `evuProfile`
- **Imports:** OpenAI, brainEventHooks
- **Externe APIs:** OpenAI gpt-4o-mini
- **Exportierte Funktionen:** `analyzeNbBehavior()`, `getEvuProfile()`, `learnFromEmails()`

### factro.service.ts
- **Zweck:** Factro API-Client (Projekte, Tasks, Polling, Status-Sync)
- **Prisma-Models:** `factroConfig`, `factroProject`, `installation`
- **Externe APIs:** `https://cloud.factro.com/api/core` (api-key Auth)
- **Cron-Jobs:** Sold-Erkennung alle 10 Min
- **Exportierte Funktionen:** `pollProjects()`, `syncSoldStatus()`, `getProjectsForKunde()`

### factroCommentSync.ts
- **Zweck:** Kommentar-Import aus Factro
- **Prisma-Models:** `factroComment`, `factroProject`, `factroConfig`
- **Externe APIs:** `https://cloud.factro.com/api/core/tasks/{id}/comments`
- **Cron-Jobs:** Alle 10 Min (inkrementell)
- **Exportierte Funktionen:** `syncCommentsForProject()`, `syncAllComments()`

### factroCommentAnalyzer.ts
- **Zweck:** Factro-Kommentar-Analyse (Muster erkennen)
- **Prisma-Models:** `factroComment`, `factroProject`
- **Exportierte Funktionen:** `analyzeComments()`, `getPatterns()`

### factroDocumentImporter.ts
- **Zweck:** Dokumente aus Factro importieren
- **Prisma-Models:** `document`, `factroProject`, `factroConfig`
- **Externe APIs:** `https://cloud.factro.com/api/core` (Datei-Download)
- **Exportierte Funktionen:** `importDocuments()`, `importAllDocuments()`

### factroParser.ts
- **Zweck:** Factro-Daten parsen (Projekt-Metadaten extrahieren)
- **Prisma-Models:** `factroProject`
- **Exportierte Funktionen:** `parseFactroProject()`, `extractTechnicalData()`

### formularLink.service.ts
- **Zweck:** Formular-Links generieren (z.B. für Kunden-Self-Service)
- **Prisma-Models:** `formularLink`, `installation`
- **Imports:** crypto, netzbetreiberMatcher
- **Exportierte Funktionen:** `createFormularLink()`, `validateLink()`, `processSubmission()`

### formularPdf.service.ts
- **Zweck:** PDF-Formulare generieren
- **Prisma-Models:** `installation`, `document`
- **Exportierte Funktionen:** `generateFormularPdf()`

### funnelAnalysis.service.ts
- **Zweck:** Conversion-Funnel Analyse
- **Prisma-Models:** `installation`, `statusHistory`
- **Exportierte Funktionen:** `getFunnelData()`, `getConversionRates()`

### hvContract.service.ts
- **Zweck:** Handelsvertreter-Vertragsverwaltung
- **Prisma-Models:** `handelsvertreter`, `hvContract`
- **Exportierte Funktionen:** `getContractStatus()`, `createContract()`

### inboxItemGenerator.service.ts
- **Zweck:** InboxItem-Generierung aus verschiedenen Quellen (Email, Cron, Status-Change)
- **Prisma-Models:** `inboxItem`, `installation`, `email`
- **Cron-Jobs:** Overdue-Check, NB-Nachfassen (diverse Intervalle)
- **Exportierte Funktionen:**
  - `alertRueckfrageItem()`, `alertAblehnungItem()`, `alertGenehmigungItem()`
  - `createOverdueItem()`, `createNbNachfassItem()`
  - `runMaintenanceCron()` — Wartungs-Cron

### installationAI.service.ts
- **Zweck:** KI-Analyse für Installationen
- **Prisma-Models:** `installation`, `document`, `email`
- **Externe APIs:** OpenAI
- **Exportierte Funktionen:** `analyzeInstallation()`, `suggestNextSteps()`

### installationAutomation.service.ts
- **Zweck:** Installation-Automationen (Status-basiert)
- **Prisma-Models:** `installation`, `automationRule`
- **Exportierte Funktionen:** `runAutomations()`, `checkTriggers()`

### invoicePdf.service.ts
- **Zweck:** Rechnungs-PDF generieren
- **Prisma-Models:** `rechnung`, `kunde`, `rechnungPosition`
- **Imports:** PDFKit
- **Exportierte Funktionen:** `generateInvoicePdf()`

### mahnung.service.ts
- **Zweck:** Mahnungs-Erstellung und -Versand
- **Prisma-Models:** `rechnung`, `mahnung`, `kunde`
- **Exportierte Funktionen:** `createMahnung()`, `sendMahnung()`

### mastr.service.ts
- **Zweck:** MaStR API-Client (Marktstammdatenregister, SOAP)
- **Prisma-Models:** `installation`
- **Externe APIs:** `https://www.marktstammdatenregister.de/Services/Public/1_2/Modelle` (SOAP)
- **Exportierte Funktionen:** `searchByPlz()`, `getUnitDetails()`, `registerUnit()`

### mastrSync.service.ts
- **Zweck:** MaStR-Daten mit Installationen synchronisieren
- **Prisma-Models:** `installation`, `mastrUnit`
- **Cron-Jobs:** Manuell oder Cron-getriggert
- **Exportierte Funktionen:** `syncMastrData()`

### nbCommunication.service.ts
- **Zweck:** Kommunikation mit Netzbetreibern (Email-Versand, Nachfassen)
- **Prisma-Models:** `installation`, `netzbetreiber`, `email`
- **Cron-Jobs:** Automatische Nachfragen
- **Exportierte Funktionen:** `sendNbEmail()`, `sendNbReminder()`, `checkPendingReminders()`

### nbComplaintParser.service.ts
- **Zweck:** NB-Beanstandungen parsen (GPT-4o-mini)
- **Prisma-Models:** `nbComplaint`, `nbComplaintPattern`
- **Imports:** OpenAI, prisma
- **Externe APIs:** OpenAI gpt-4o-mini
- **Exportierte Funktionen:** `parseComplaints()`, `getComplaintTypes()`

### nbDomainMapping.service.ts
- **Zweck:** Domain-zu-Netzbetreiber Mapping
- **Prisma-Models:** `netzbetreiber`
- **Exportierte Funktionen:** `mapDomainToNb()`, `buildDomainMap()`

### nbLearning.service.ts
- **Zweck:** NB-Learning (Stats, Email-Learning, Rückfrage-Gründe)
- **Prisma-Models:** `netzbetreiber`, `installation`, `email`, `nbStats`
- **Cron-Jobs:** 3 separate Crons (NB-Stats, Email-Learning, Rückfragegründe)
- **Exportierte Funktionen:** `aggregateNbStats()`, `learnFromEmails()`, `aggregateRueckfrageGruende()`

### nbPortalAutomation.service.ts
- **Zweck:** NB-Portal-Automation (Status-Prüfung)
- **Prisma-Models:** `installation`
- **Externe APIs:** Diverse NB-Portal-URLs (fetch)
- **Exportierte Funktionen:** `checkPortalStatus()`, `submitToPortal()`

### nbResolveEngine.service.ts
- **Zweck:** Auto-Resolve Engine für NB-Beanstandungen
- **Prisma-Models:** `nbResponseTask`, `nbComplaint`, `nbComplaintPattern`, `efkSignature`
- **Externe APIs:** `https://api.openai.com/v1/chat/completions` (Draft-Generierung)
- **Exportierte Funktionen:** `resolveTask()`, `reResolveTask()`, `learnFromResolvedTask()`

### nbResponseOrchestrator.service.ts
- **Zweck:** NB-Response Orchestrierung (Thread aufbauen, Complaints parsen, Resolve)
- **Prisma-Models:** `nbResponseTask`, `email`, `installation`
- **Imports:** nbThreadAnalyzer, nbComplaintParser, nbResolveEngine
- **Exportierte Funktionen:** `orchestrateResponse()`, `processTask()`

### nbTaskComment.service.ts
- **Zweck:** Kommentare zu NB-Response-Tasks
- **Prisma-Models:** `nbTaskComment`
- **Exportierte Funktionen:** `addComment()`, `getComments()`

### nbThreadAnalyzer.service.ts
- **Zweck:** Email-Thread-Analyse (Zusammengehörende Emails finden)
- **Prisma-Models:** `email`, `emailAttachment`
- **Exportierte Funktionen:** `buildThread()`, `analyzeThread()`

### netzanfrage.service.ts
- **Zweck:** Netzanfrage-Versand + Tracking
- **Prisma-Models:** `factroProject`, `emailLog`, `installation`, `netzbetreiber`
- **Externe APIs:** `https://cloud.factro.com/api/core` (Kommentar schreiben)
- **Exportierte Funktionen:** `sendNetzanfrage()`, `trackNetzanfrage()`

### openai.service.ts
- **Zweck:** OpenAI Service (allgemeine KI-Funktionen, Geocoding)
- **Prisma-Models:** `installation`
- **Externe APIs:** OpenAI API, `https://nominatim.openstreetmap.org/reverse` (Geocoding)
- **Exportierte Funktionen:** `generateCompletion()`, `analyzeDocument()`, `reverseGeocode()`

### op.service.ts
- **Zweck:** Offene Posten Verwaltung (Accounts Receivable)
- **Prisma-Models:** `rechnung`, `kunde`, `wiseTransaction`
- **Exportierte Funktionen:** `getOpenItems()`, `getKundenMoralScore()`, `getOpOverview()`

### ops.service.ts
- **Zweck:** Operations Service (Dashboard, Reminder Engine)
- **Prisma-Models:** `installation`, `email`, `task`
- **Cron-Jobs:** Reminder Engine (von Cron aufgerufen)
- **Exportierte Funktionen:** `getOpsOverview()`, `sendReminder()`, `runReminderEngine()`

### paymentLink.service.ts
- **Zweck:** Zahlungslinks generieren
- **Prisma-Models:** `rechnung`, `paymentLink`
- **Externe APIs:** `https://app.gridnetz.de` (Frontend-URL)
- **Exportierte Funktionen:** `createPaymentLink()`, `validatePaymentLink()`, `processPayment()`

### portalNotification.service.ts
- **Zweck:** Portal-Benachrichtigungen (In-App)
- **Prisma-Models:** `portalNotification`, `portalUser`
- **Cron-Jobs:** Automatische Erinnerungen
- **Exportierte Funktionen:** `createNotification()`, `getNotifications()`, `markAsRead()`

### portalNotificationCreator.service.ts
- **Zweck:** Erstellt Portal-Notifications bei Status-Änderungen
- **Prisma-Models:** `portalNotification`, `installation`
- **Exportierte Funktionen:** `notifyStatusChange()`, `notifyDocumentReady()`

### portalUser.service.ts
- **Zweck:** Portal-User-Verwaltung (Kunden-Login)
- **Prisma-Models:** `portalUser`, `kunde`
- **Exportierte Funktionen:** `createPortalUser()`, `authenticatePortalUser()`

### predictionEngine.service.ts
- **Zweck:** Vorhersagen (Bearbeitungsdauer, Genehmigungswahrscheinlichkeit)
- **Prisma-Models:** `installation`, `statusHistory`
- **Exportierte Funktionen:** `predictProcessingTime()`, `predictApprovalChance()`

### pricing.service.ts
- **Zweck:** Preis-Berechnung
- **Prisma-Models:** `kunde`, `pricingRule`
- **Exportierte Funktionen:** `calculatePrice()`, `getPricingRules()`

### productEnrichment.service.ts
- **Zweck:** Produkt-Datenanreicherung (Technische Daten)
- **Prisma-Models:** `produkt`, `wechselrichter`, `speicherSystem`
- **Exportierte Funktionen:** `enrichProduct()`, `fetchTechnicalData()`

### product.service.ts
- **Zweck:** Produkt-Verwaltung (CRUD + AI-Suche)
- **Prisma-Models:** `produkt`, `wechselrichter`, `speicherSystem`, `hersteller`
- **Imports:** OpenAI
- **Exportierte Funktionen:** `searchProducts()`, `getProduct()`, `createProduct()`

### provisionAutomation.service.ts
- **Zweck:** Provisions-Automatisierung
- **Prisma-Models:** `provision`, `handelsvertreter`, `installation`
- **Exportierte Funktionen:** `calculateProvision()`, `runProvisionAutomation()`

### provision.service.ts
- **Zweck:** Provisions-Verwaltung (Berechnung, Auszahlung, SEPA-XML)
- **Prisma-Models:** `provision`, `handelsvertreter`, `rechnung`, `provisionAuszahlung`
- **Exportierte Funktionen:** `createProvision()`, `getProvisions()`, `generateSepaXml()`, `reconcileProvisions()`

### pushNotifications.ts
- **Zweck:** Push-Notifications via Expo
- **Prisma-Models:** Keine
- **Externe APIs:** `https://exp.host/--/api/v2/push/send`
- **Exportierte Funktionen:** `sendPushNotification()`

### pvgis.service.ts
- **Zweck:** PVGIS-API (EU Photovoltaic Geographical Information System)
- **Prisma-Models:** Keine
- **Externe APIs:** `https://re.jrc.ec.europa.eu/api/v5_3/PVcalc`
- **Exportierte Funktionen:** `calculatePvYield()`

### ruleEngine.ts
- **Zweck:** Regel-Engine für Automationen
- **Prisma-Models:** `automationRule`
- **Exportierte Funktionen:** `evaluateRules()`, `executeActions()`

### securityAudit.service.ts
- **Zweck:** Security Audit Logging
- **Prisma-Models:** `securityAuditLog`
- **Exportierte Funktionen:** `logSecurityEvent()`, `getAuditLog()`

### sessionTrackingService.ts
- **Zweck:** User-Session Tracking (Browser, OS, Geolocation)
- **Prisma-Models:** `userSession`
- **Imports:** uuid, ua-parser-js
- **Exportierte Funktionen:** `trackSession()`, `getActiveSessions()`

### solarCalculator.service.ts
- **Zweck:** Solar-Ertragsrechner
- **Prisma-Models:** Keine
- **Exportierte Funktionen:** `calculateYield()`, `estimateROI()`

### tabAnalysis.service.ts
- **Zweck:** TAB-Dokument-Analyse (Technische Anschlussbedingungen)
- **Prisma-Models:** `document`, `tabAnalysis`
- **Exportierte Funktionen:** `analyzeTabPdf()` — TAB-PDF analysieren

### terminalWebSocket.ts
- **Zweck:** Terminal WebSocket (Admin-SSH im Browser)
- **Prisma-Models:** Keine
- **Imports:** node-pty, ws, jwt
- **Exportierte Funktionen:** `handleTerminalConnection()`

### trackingService.ts
- **Zweck:** Event-Tracking (Pageviews, Clicks)
- **Prisma-Models:** `trackingEvent`
- **Cron-Jobs:** `setInterval` für Flush
- **Exportierte Funktionen:** `track()`, `flush()`

### twoFactor.service.ts
- **Zweck:** 2FA (TOTP)
- **Prisma-Models:** `user`
- **Exportierte Funktionen:** `generateSecret()`, `verifyToken()`, `enable2FA()`, `disable2FA()`

### userPreferences.service.ts
- **Zweck:** User-Einstellungen (Theme, Sprache, Notifications)
- **Prisma-Models:** `userPreference`
- **Exportierte Funktionen:** `getPreferences()`, `updatePreferences()`

### vdeFormularFetcher.service.ts
- **Zweck:** VDE-Formulare von gridnetz.de abrufen
- **Prisma-Models:** Keine
- **Externe APIs:** `https://gridnetz.de/vde-formulare` (PDF-Download)
- **Cron-Jobs:** 7-Tage Cache
- **Exportierte Funktionen:** `fetchVdeFormular()`, `getAvailableForms()`

### vde-pdf-service.ts
- **Zweck:** VDE-PDF-Generierung (Express-Router mit /e3, /all Endpoints)
- **Prisma-Models:** `installation`
- **Exportierte Funktionen:** Express Router mit POST `/e3` und POST `/all`

### vnbdigital.service.ts
- **Zweck:** VNBdigital.de Integration (GraphQL-Client)
- **Prisma-Models:** `netzbetreiber`
- **Externe APIs:** `https://www.vnbdigital.de/gateway/graphql`
- **Exportierte Funktionen:** `lookupByPlz()`, `enrichNetzbetreiber()`, `resolveVnbEmail()`

### websocket.service.ts
- **Zweck:** WebSocket-Server (Real-time Updates)
- **Prisma-Models:** `user` (JWT-Validierung)
- **Imports:** ws, jwt
- **Cron-Jobs:** Heartbeat-Interval
- **Exportierte Funktionen:** `broadcast()`, `sendToUser()`, `sendToRole()`

### wise.service.ts
- **Zweck:** Wise API-Client (Bankkonten, Transaktionen, Überweisungen)
- **Prisma-Models:** `wiseAccount`, `wiseTransaction`, `rechnung`
- **Externe APIs:** `https://api.wise.com` (diverse Endpoints)
- **Exportierte Funktionen:** `getAccounts()`, `getTransactions()`, `syncTransactions()`, `createTransfer()`, `matchTransactions()`

### workflow.service.ts
- **Zweck:** Haupt-Workflow (Status-Änderungen, Email-Queue, Automationen)
- **Prisma-Models:** `installation`, `statusHistory`, `email`, `emailQueueItem`, `document`, `rechnung`, `learningEvent`
- **Imports:** node-cron
- **Cron-Jobs:**
  - Alle 30s: Email Queue Processing
  - Alle 5 Min: Document Batch
  - Täglich 9:00: Rechnungs-Check (Überfällige)
  - Täglich 10:00: Dokument-Check (fehlende)
  - Montag 8:00: Inaktivitäts-Check
- **Exportierte Funktionen:**
  - `onStatusChange()` — Haupt-Handler bei Status-Änderung
  - `checkSubcontractorBlock()` — Sub-Sperre prüfen
  - `recordLearningEvent()` — Learning Event aufzeichnen
  - `processEmailQueue()` — Email-Queue verarbeiten
  - `initializeWorkflow()` — Crons starten

### zaehlerwechselTermin.service.ts
- **Zweck:** Zählerwechsel-Termine verwalten
- **Prisma-Models:** `zaehlerwechselAppointment`, `installation`
- **Cron-Jobs:** Erinnerungen (für Cron-Job)
- **Exportierte Funktionen:** `scheduleTermin()`, `confirmTermin()`, `cancelTermin()`, `getUpcomingTermine()`, `sendTerminReminders()`

### zerez.service.ts
- **Zweck:** ZEREZ-Registrierung (Stromnetz Berlin)
- **Prisma-Models:** `installation`
- **Externe APIs:** `https://mein.stromnetz.berlin/api/v1/zerez`
- **Exportierte Funktionen:** `searchZerez()`, `registerZerez()`

### zoom.service.ts
- **Zweck:** Zoom-Meeting Integration
- **Prisma-Models:** Keine
- **Externe APIs:** `https://zoom.us/oauth/token`, `https://api.zoom.us/v2/users/me/meetings`, `https://api.zoom.us/v2/meetings/{id}`
- **Exportierte Funktionen:** `createMeeting()`, `getMeeting()`, `deleteMeeting()`

---

## Zusammenfassung

### Service-Statistiken
| Kategorie | Anzahl Services |
|-----------|----------------|
| accounting/ | 12 (inkl. index) |
| ai/ | 4 (inkl. index) |
| automations/ | 9 (inkl. index) |
| brain/ | 1 |
| claude/ | 1 |
| documentGenerator/ | 9 (inkl. shared) |
| nbPortalProxy/ | 6 (inkl. types) |
| nbPortal/ | 1 |
| rag/ | 5 |
| stromnetzBot/ | 2 |
| vdeFormular/ | 1 |
| whatsapp/ | 9 |
| workflowV2/ | 7 (inkl. types) |
| Root-Level | ~60 |
| **Gesamt** | **~127** |

### Externe APIs
| API | Services |
|-----|----------|
| OpenAI (gpt-4o-mini) | aiChat, aiExtraction, emailAutomation, openaiClassifier, nbComplaintParser, nbResolveEngine, evuLearning, product, openai, claudeAI |
| Ollama (llama3.1:8b) | localAI |
| Factro | factro, factroCommentSync, factroDocumentImporter, netzanfrage, emailAutomation |
| Wise API | wise, exchangeRate |
| Wassenger (WhatsApp) | whatsappMessage, whatsappMedia, whatsappWebhook |
| Google Maps | documentGenerator/lageplan |
| Nominatim (OSM) | documentGenerator/lageplan, openai |
| MapTiler | documentGenerator/lageplan |
| VNBdigital (GraphQL) | vnbdigital |
| MaStR (SOAP) | mastr |
| PVGIS (EU) | pvgis |
| Energy Charts | energyPrices |
| Zoom | zoom |
| Expo Push | pushNotifications |
| Stromnetz Berlin | nbPortal/stromnetzBerlin, nbPortalProxy, stromnetzBot, zerez |
| GridNetz VDE | vdeFormularFetcher |
| Slack | automations/healthMonitor |

### Cron-Jobs
| Intervall | Service | Funktion |
|-----------|---------|----------|
| Alle 30s | workflow | processEmailQueue() |
| Alle 2 Min | email | processQueue() |
| Alle 5 Min | workflow | processDocumentEmailBatches() |
| Alle 5 Min | healthMonitor | runAllHealthChecks() |
| Alle 10 Min | factro | Sold-Erkennung Polling |
| Alle 10 Min | factroCommentSync | syncAllComments() |
| Alle 15 Min | workflowV2/inboxItemFactory | checkDeadlines() |
| Alle 30 Min | nbEmailRecognition | recognizeNbEmails() |
| Alle 30 Min | emailEscalation | executeScheduledEscalations() |
| Alle 60 Min | rag/autoReindex | runIncrementalReindex() |
| Täglich 8:00 | mahnwesen | runMahnwesenCron() |
| Täglich 9:00 | workflow | checkOverdueInvoices() |
| Täglich 9:00 | reminderCron | sendRueckfrageReminders() |
| Täglich 10:00 | workflow | checkMissingDocuments() |
| Täglich 10:00 | emailEscalation | checkForEscalations() |
| Montag 8:00 | workflow | checkInactiveInstallations() |
| 1. des Monats | provisionPayout | processProvisionPayouts() |
| 5. des Monats | hvReport | sendHvReports() |

### Meistgenutzte Prisma-Models
| Model | Nutzende Services (Top) |
|-------|------------------------|
| installation | ~30+ Services |
| email | ~15 Services |
| rechnung | ~12 Services |
| kunde | ~10 Services |
| netzbetreiber | ~10 Services |
| document | ~10 Services |
| expense | ~6 Services (Accounting) |
| wiseTransaction | ~5 Services |
| provision | ~4 Services |
| factroProject | ~5 Services |
| inboxItem | ~4 Services |
