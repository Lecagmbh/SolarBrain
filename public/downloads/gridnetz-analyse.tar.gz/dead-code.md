# GridNetz Portal - Dead-Code-Analyse

> Stand: 2026-03-11 | Systematische Analyse von Backend + Frontend

---

## Inhaltsverzeichnis

1. [Zusammenfassung](#1-zusammenfassung)
2. [Frontend: Dateien ohne Imports](#2-frontend-dateien-ohne-imports)
3. [Frontend: Verwaiste Module & Features](#3-frontend-verwaiste-module--features)
4. [Frontend: React-Native-Altlasten](#4-frontend-react-native-altlasten)
5. [Frontend: Duplikat-Komponenten](#5-frontend-duplikat-komponenten)
6. [Frontend: Ungenutzte npm-Packages](#6-frontend-ungenutzte-npm-packages)
7. [Backend: Isolierte Services (nie importiert)](#7-backend-isolierte-services-nie-importiert)
8. [Backend: API-Endpunkte ohne Frontend-Aufruf](#8-backend-api-endpunkte-ohne-frontend-aufruf)
9. [Backend: Ungenutzte npm-Packages](#9-backend-ungenutzte-npm-packages)
10. [Backend: Ungelesene ENV-Variablen](#10-backend-ungelesene-env-variablen)
11. [Verwaiste CSS-Dateien](#11-verwaiste-css-dateien)
12. [Empfehlungen nach Prioritaet](#12-empfehlungen-nach-prioritaet)

---

## 1. Zusammenfassung

| Kategorie | Anzahl | Geschaetzter Ballast |
|-----------|--------|---------------------|
| Verwaiste Frontend-Pages | 12 | ~8.000 Zeilen |
| React-Native-Altlasten | ~20 Dateien | ~5.000 Zeilen |
| Verwaiste Module/Features | 7 Verzeichnisse | ~15.000 Zeilen |
| Duplikat-Komponenten | 4 Gruppen | ~2.000 Zeilen |
| Ungenutzte Frontend-Packages | 11 | ~50 MB node_modules |
| Isolierte Backend-Services | 3 | ~1.800 Zeilen |
| Backend-APIs ohne Frontend | 4 | ~1.500 Zeilen |
| Ungenutzte Backend-Packages | 3 | ~5 MB node_modules |
| Tote ENV-Variablen | 3 | Konfigurationsrauschen |

**Gesamtschaetzung: ~33.000 Zeilen toter Code, ~55 MB unnoetige Dependencies**

---

## 2. Frontend: Dateien ohne Imports

### 2.1 Pages die im Router auskommentiert/entfernt sind

Diese Dateien existieren noch auf der Festplatte, werden aber im Router (`src/router.tsx`) nicht mehr geladen:

| Datei | Grund | Empfehlung |
|-------|-------|------------|
| `src/pages/AlertsPage.tsx` | Auskommentiert: "Alert-System wird komplett ueberarbeitet" | **LOESCHEN** - Bei Neuimplementierung neu schreiben |
| `src/pages/AufgabenPage.tsx` | Ersetzt durch OpsCenterPage | **LOESCHEN** |
| `src/pages/WhatsAppIntegrationPage.tsx` | "Feature noch nicht ausgereift" | **LOESCHEN** - Bei Bedarf neu bauen |
| `src/pages/NbResponsePage.tsx` | Auskommentiert: "wird neu konzipiert" | **LOESCHEN** |
| `src/pages/admin/EmailLearningCenter.tsx` | Auskommentiert: "wird neu konzipiert" | **LOESCHEN** |
| `src/pages/DashboardPage.legacy.tsx` | Legacy-Dashboard, nicht im Router | **LOESCHEN** |
| `src/pages/WorkflowPage.tsx` + `.css` | Nur noch ueber WorkflowRouter.tsx erreichbar, der selbst nicht im Router ist | **LOESCHEN** |
| `src/pages/WorkflowV2Page.tsx` + `.css` | Dto., nur via WorkflowRouter.tsx | **LOESCHEN** |

### 2.2 Pages die nirgends importiert werden

| Datei | Analyse | Empfehlung |
|-------|---------|------------|
| `src/pages/InstallationsPage.tsx` | Nicht im Router, nicht importiert | **LOESCHEN** - Ersetzt durch NetzanmeldungenEnterprise |
| `src/pages/NetzanmeldungenPage.tsx` (in `pages/`) | Nicht im Router. Es gibt `features/netzanmeldungen/NetzanmeldungenPage.tsx` (wird auch nicht direkt im Router genutzt, nur intern) und `pages/admin/Netzanmeldungen.tsx` (im Router als Legacy) | **LOESCHEN** - die `pages/`-Version ist obsolet |
| `src/pages/StammdatenPage.tsx` + `.css` | Nicht im Router, nirgends importiert | **LOESCHEN** |
| `src/pages/PasswordCenterPage.tsx` | Nicht im Router, nur in einem Kommentar in MyPasswordPage.tsx referenziert | **LOESCHEN** |
| `src/pages/BenutzerPage.tsx` | Nicht im Router. Es gibt auch `modules/benutzer/BenutzerPage.tsx` (ebenfalls ungenutzt) | **LOESCHEN** (beide Versionen) |
| `src/pages/UsersPage.tsx` | Nicht im Router, nicht importiert. Ersetzt durch admin/KundenPage | **LOESCHEN** |
| `src/pages/AnlagenPage.tsx` | Nicht im Router, importiert `InstallationDetailModal` | **LOESCHEN** - Ersetzt durch AnlagenWizardPage |
| `src/pages/AbrechnungPage.tsx` | Nicht im Router, nicht importiert | **LOESCHEN** |
| `src/pages/Netzbetreiber.tsx` | Nicht im Router (nur `NetzbetreiberCenterPage` ist aktiv) | **LOESCHEN** |
| `src/pages/admin/Dashboard.tsx` | Nicht im Router (Dashboard kommt aus `modules/dashboard/Dashboard`) | **LOESCHEN** |
| `src/App.tsx` | `main.tsx` baut eigene Provider-Hierarchie, nutzt App.tsx NICHT | **LOESCHEN** |

### 2.3 Verwaiste Komponenten

| Datei | Analyse | Empfehlung |
|-------|---------|------------|
| `src/components/features/FlyingAI.tsx` | Im AdminLayout explizit als "nicht verwendet" kommentiert | **LOESCHEN** |
| `src/components/features/AIAssistant.tsx` | Nirgends importiert (AIAssistantPanel und AIAssistantLocal sind die aktiven Versionen) | **LOESCHEN** |
| `src/components/features/QuickPreview.tsx` | Nirgends importiert | **LOESCHEN** |
| `src/components/ReferenceManager.tsx` | Nirgends importiert | **LOESCHEN** |
| `src/components/NetzbetreiberConfig.tsx` | Nirgends importiert | **LOESCHEN** |
| `src/components/SubcontractorAssignment.tsx` | Nirgends importiert | **LOESCHEN** |
| `src/components/billing/AbrechnungOverview.tsx` | Nirgends importiert | **LOESCHEN** |
| `src/components/layout/DesktopTitlebar.tsx` | Nirgends importiert | **LOESCHEN** |
| `src/components/workflow/WorkflowRouter.tsx` | Im Router als "entfernt" kommentiert, inkl. alle Workflow-Komponenten in `components/workflow/` | **LOESCHEN** (gesamtes Verzeichnis pruefen) |
| `src/components/InstallationDetailModal.tsx` | Nur von der verwaisten AnlagenPage.tsx importiert | **LOESCHEN** (mit AnlagenPage) |

---

## 3. Frontend: Verwaiste Module & Features

### Komplette Verzeichnisse ohne Import von aussen:

| Verzeichnis | Dateien | Analyse | Empfehlung |
|-------------|---------|---------|------------|
| `src/features/agent-center/` | ? | Nirgends importiert, nicht im Router | **LOESCHEN** |
| `src/features/brain-admin/` | ? | Nirgends importiert, nicht im Router | **LOESCHEN** |
| `src/features/claude-ai-dashboard/` | ? | Nirgends importiert, nicht im Router | **LOESCHEN** |
| `src/features/rag-admin/` | ? | Nirgends importiert, nicht im Router | **LOESCHEN** |
| `src/modules/abrechnung/` | AbrechnungPage.tsx | Nirgends importiert | **LOESCHEN** |
| `src/modules/anlagen/` | AnlagenPage.tsx | Nirgends importiert | **LOESCHEN** |
| `src/modules/benutzer/` | BenutzerPage.tsx | Nirgends importiert | **LOESCHEN** |
| `src/modules/emails/` | ? | Nicht im Router (EmailsPage kommt aus `modules/admin/emails/`) | **PRUEFEN** - Koennte von admin/emails importiert werden |
| `src/modules/performance/` | ? | Nirgends importiert | **LOESCHEN** |
| `src/modules/layout/` | ? | Nirgends importiert | **LOESCHEN** |
| `src/finanzen-module/` | Gesamtes Verzeichnis | Nirgends importiert (aktiv ist `features/finanzen/`) | **LOESCHEN** |

---

## 4. Frontend: React-Native-Altlasten

**Gesamtes React-Native-Code im Frontend-Repo** - offensichtlich von einer frueheren Mobile-App uebrig geblieben. Alle Dateien importieren `react-native`, was in einem Vite/Web-Projekt nicht funktioniert.

| Verzeichnis/Datei | Empfehlung |
|--------------------|------------|
| `src/screens/DashboardScreen.js` | **LOESCHEN** |
| `src/screens/InstallationsScreen.js` | **LOESCHEN** |
| `src/screens/InstallationDetailScreen.js` | **LOESCHEN** |
| `src/screens/InstallationWizardScreen.js` | **LOESCHEN** |
| `src/screens/LoginScreen.js` | **LOESCHEN** |
| `src/screens/DocumentsScreen.js` | **LOESCHEN** |
| `src/screens/SettingsScreen.js` | **LOESCHEN** |
| `src/screens/ScannerScreen.js` | **LOESCHEN** |
| `src/screens/BarcodeScannerScreen.js` | **LOESCHEN** |
| `src/screens/WizardScreen.js` | **LOESCHEN** |
| `src/contexts/NetworkContext.js` | **LOESCHEN** (React-Native) |
| `src/contexts/NotificationContext.js` | **LOESCHEN** (React-Native) |
| `src/contexts/AuthContext.js` | **LOESCHEN** (React-Native, aktiv ist AuthContext.tsx in pages/) |
| `src/hooks/index.js` | **LOESCHEN** (React-Native) |
| `src/navigation/index.js` | **LOESCHEN** (React-Native) |
| `src/services/pushNotifications.js` | **LOESCHEN** (React-Native) |
| `src/services/offlineQueue.js` | **LOESCHEN** (React-Native) |
| `src/services/biometric.js` | **LOESCHEN** (React-Native) |
| `src/components/ui.js` | **LOESCHEN** (React-Native) |
| `src/theme/index.js` | **LOESCHEN** (React-Native) |

**Empfehlung: Gesamte Verzeichnisse `src/screens/`, `src/navigation/`, `src/theme/` loeschen.**

---

## 5. Frontend: Duplikat-Komponenten

### 5.1 StatusPill (4 Implementierungen!)

| Datei | Genutzt von |
|-------|-------------|
| `src/components/ui/StatusPill.tsx` | AnlageDetailModal |
| `src/components/DashboardV2/components/StatusPill.tsx` | DashboardV2 TopBar |
| `src/features/netzanmeldungen/.../DashboardV2/sections/StatusPill.tsx` | Netzanmeldungen DetailModal |
| `src/features/netzanmeldungen/.../ZaehlerwechselCenter/components/StatusPill.tsx` | ZaehlerwechselCenter |

**Empfehlung:** Eine einzige `StatusPill` in `src/components/ui/` mit konfigurierbaren Status-Maps. Die anderen 3 loeschen und Imports umbiegen.

### 5.2 CommandPalette (5 Implementierungen!)

| Datei | Genutzt von |
|-------|-------------|
| `src/components/features/CommandPalette.tsx` | AdminLayout (aktiv) |
| `src/finanzen-module/components/CommandPalette.tsx` | finanzen-module (tot) |
| `src/modules/dashboard/admin/components/ui/CommandPalette.tsx` | modules/dashboard AdminLayout |
| `src/modules/installations/detail-v2/components/CommandPalette.tsx` | InstallationDetailPanel |
| `src/pages/UserManagementPage.tsx` (inline) | UserManagementPage |

**Empfehlung:** `src/finanzen-module/components/CommandPalette.tsx` loeschen (gesamtes finanzen-module ist tot). Die UserManagementPage-Inline-Version in eigene Datei extrahieren. Die restlichen 3 haben unterschiedliche Kontexte und sind OK.

### 5.3 AdminLayout (2 Implementierungen)

| Datei | Status |
|-------|--------|
| `src/components/layout/AdminLayout.tsx` | **AKTIV** - im Router verwendet |
| `src/modules/dashboard/admin/components/layout/AdminLayout.tsx` | Nur intern im Dashboard-Modul, nicht im Router |

**Empfehlung:** **PRUEFEN** ob das Dashboard-Admin-Layout intern genutzt wird. Falls ja, umbenennen um Verwechslung zu vermeiden.

### 5.4 API-Clients (3 aktive, 1 Legacy)

| Datei | Status |
|-------|--------|
| `src/api/client.ts` | **PRIMARY** - Fetch-basiert, von allen Features genutzt |
| `src/modules/api/client.ts` | **SEKUNDAER** - Fetch-basiert, von 58 Dateien importiert |
| `src/api/api.ts` | **LEGACY** - Axios-basiert, nur noch 2 Imports |

**Empfehlung:** `src/api/api.ts` (Axios-Version) **LOESCHEN** und die 2 verbliebenen Imports auf `src/api/client.ts` oder `src/modules/api/client.ts` umstellen.

---

## 6. Frontend: Ungenutzte npm-Packages

| Package | In package.json | Tatsaechliche Imports | Empfehlung |
|---------|-----------------|----------------------|------------|
| `@anthropic-ai/sdk` | dependencies | 0 Imports im Frontend-Code | **LOESCHEN** - Nur im Backend gebraucht |
| `sharp` | dependencies | 0 Imports | **LOESCHEN** - Node.js-only, gehoert nicht ins Frontend |
| `node-cron` | dependencies | 0 Imports | **LOESCHEN** - Node.js-only, gehoert nicht ins Frontend |
| `cors` | dependencies | 0 Imports | **LOESCHEN** - Express-Middleware, gehoert nicht ins Frontend |
| `pdf-parse` | dependencies | 0 Imports | **LOESCHEN** - Node.js-only |
| `pdfkit` | dependencies | 0 Imports | **LOESCHEN** - Node.js-only (jspdf wird stattdessen genutzt) |
| `xstate` + `@xstate/react` | dependencies | 0 Imports | **LOESCHEN** - Nie implementiert |
| `react-icons` | dependencies | 0 Imports | **LOESCHEN** - lucide-react wird stattdessen genutzt |
| `cmdk` | dependencies | 0 Imports | **LOESCHEN** - Eigene CommandPalette implementiert |
| `ical-generator` | dependencies | 0 Imports | **LOESCHEN** |
| `exceljs` | dependencies | 0 Imports | **LOESCHEN** |
| `@dnd-kit/core` + `@dnd-kit/sortable` | dependencies | 0 Imports | **LOESCHEN** - Nie implementiert |
| `qrcode` + `@types/qrcode` | dependencies | 0 Imports im Frontend | **LOESCHEN** |

**Hinweis:** `axios` hat noch 2 Imports (in `api/api.ts` und `modules/api/client.ts`). Wenn `api/api.ts` geloescht wird, pruefen ob `modules/api/client.ts` es noch braucht.

---

## 7. Backend: Isolierte Services (nie importiert)

| Service | Zeilen | Analyse | Empfehlung |
|---------|--------|---------|------------|
| `src/services/anomalyDetection.service.ts` | ~580 | Exportiert `anomalyDetectionService`, wird aber nirgends importiert | **LOESCHEN** - Nie in Betrieb genommen |
| `src/services/predictionEngine.service.ts` | ~630 | Exportiert `predictionEngineService`, wird aber nirgends importiert | **LOESCHEN** - Nie in Betrieb genommen |
| `src/services/funnelAnalysis.service.ts` | ~490 | Exportiert `funnelAnalysisService`, wird aber nirgends importiert | **LOESCHEN** - Nie in Betrieb genommen |
| `src/services/productEnrichment.service.ts` | ~595 | Exportiert `productEnrichmentService`, wird aber nirgends importiert | **LOESCHEN** - Nie angebunden |

---

## 8. Backend: API-Endpunkte ohne Frontend-Aufruf

### 8.1 Endpunkte die im Backend registriert sind, aber vom Frontend nie aufgerufen werden:

| Route | Base-Path | Analyse | Empfehlung |
|-------|-----------|---------|------------|
| `solar.routes.ts` | `/api/solar` | 0 Frontend-Aufrufe, PVGIS + Wirtschaftlichkeitsrechner | **BEHALTEN** - Koennte extern genutzt werden (Wizard) |
| `featureBuilder.routes.ts` | `/api/feature-builder` | 0 Frontend-Aufrufe | **LOESCHEN** - Experimentelles Feature, nie fertig |
| `openaiTest.routes.ts` | `/api/openai-test` | 0 Frontend-Aufrufe | **LOESCHEN** - Nur Dev/Test, gehoert nicht in Produktion |
| `dsgvo.routes.ts` | `/api/dsgvo` | 0 Frontend-Aufrufe | **PRUEFEN** - Koennte noch geplant sein (DSGVO-Pflicht) |
| `zerez.routes.ts` | `/api/zerez` | 0 Frontend-Aufrufe | **PRUEFEN** - ZEREZ-Datenbank koennte noch integriert werden |

### 8.2 Endpunkte die existieren, deren zugehoerige Frontend-Page deaktiviert ist:

| Route | Frontend-Page | Status |
|-------|---------------|--------|
| `alert.routes.ts` (`/api/alerts`) | `AlertsPage.tsx` auskommentiert | **BEHALTEN** - Wird von DetailModal noch direkt genutzt |
| `nbResponse.routes.ts` | `NbResponsePage.tsx` auskommentiert | **BEHALTEN** - Auto-Resolve-System laeuft im Backend weiter |

---

## 9. Backend: Ungenutzte npm-Packages

| Package | In package.json | Tatsaechliche Imports | Empfehlung |
|---------|-----------------|----------------------|------------|
| `@anthropic-ai/claude-code` | dependencies | 0 Imports (nur `@anthropic-ai/sdk` wird genutzt) | **LOESCHEN** - SDK reicht |
| `fuse.js` | dependencies | 0 Imports | **LOESCHEN** - Nie implementiert |
| `jspdf` | dependencies | 0 Imports (pdfkit + pdf-lib werden genutzt) | **LOESCHEN** |

**Hinweis:** Alle anderen Backend-Dependencies werden tatsaechlich importiert (`ioredis`, `playwright`, `imap`, `node-pty`, `tiktoken`, etc.).

---

## 10. Backend: Ungelesene ENV-Variablen

| ENV-Variable | In .env | process.env Referenz | Empfehlung |
|--------------|---------|---------------------|------------|
| `IMAP_PASSWORD` | Zeile 35 (Duplikat von IMAP_PASS) | Nur in 2 Scripts (backfillEmailAttachments, emailIngest Worker) | **PRUEFEN** - Eventuell konsistent auf IMAP_PASS umstellen |
| `SENTRY_DSN` | Leer (`""`) | Wird gelesen aber DSN ist leer | **BEHALTEN** - Sentry ist konfiguriert, nur DSN fehlt noch |
| `S3_BACKUP_*` (4 Variablen) | Alle leer, `ENABLED=false` | Werden gelesen von backup/s3Backup.ts | **BEHALTEN** - Feature vorbereitet, noch nicht aktiviert |
| `OPENAI_API_KEY` | Doppelt definiert (Zeile 78 + 120) | Wird aktiv genutzt | **DEDUPLIZIEREN** - Zweite Zeile 120 entfernen |

---

## 11. Verwaiste CSS-Dateien

| CSS-Datei | Importiert von | Empfehlung |
|-----------|---------------|------------|
| `src/pages/WorkflowPage.css` | `WorkflowPage.tsx` (verwaist) | **LOESCHEN** (mit Page) |
| `src/pages/WorkflowV2Page.css` | `WorkflowV2Page.tsx` (verwaist) | **LOESCHEN** (mit Page) |
| `src/pages/StammdatenPage.css` | `StammdatenPage.tsx` (verwaist) | **LOESCHEN** (mit Page) |
| `src/pages/nb-response.css` | `NbResponsePage.tsx` (verwaist) | **LOESCHEN** (mit Page) |
| `src/pages/EmailCenterPage.css` | Pruefen ob noch importiert | **PRUEFEN** |

---

## 12. Empfehlungen nach Prioritaet

### Prioritaet 1: Sofort loeschbar (Null Risiko)

Diese Dateien werden garantiert nirgends genutzt:

1. **React-Native-Altlasten** (~20 Dateien in `screens/`, `navigation/`, `theme/`, .js-Services)
2. **Verwaiste Feature-Verzeichnisse**: `agent-center/`, `brain-admin/`, `claude-ai-dashboard/`, `rag-admin/`
3. **finanzen-module/** (komplett durch `features/finanzen/` ersetzt)
4. **Backend-Services**: `anomalyDetection`, `predictionEngine`, `funnelAnalysis`, `productEnrichment`
5. **Frontend-Packages entfernen**: `sharp`, `node-cron`, `cors`, `pdf-parse`, `pdfkit`, `xstate`, `react-icons`, `cmdk`, `ical-generator`, `exceljs`, `@dnd-kit/*`, `qrcode`, `@anthropic-ai/sdk`
6. **Backend-Packages entfernen**: `@anthropic-ai/claude-code`, `fuse.js`, `jspdf`

### Prioritaet 2: Nach kurzem Check loeschbar

1. **Deaktivierte Pages**: AlertsPage, AufgabenPage, WhatsAppIntegrationPage, NbResponsePage, EmailLearningCenter
2. **Ersetzte Pages**: InstallationsPage, StammdatenPage, PasswordCenterPage, BenutzerPage, UsersPage, AnlagenPage, AbrechnungPage, Netzbetreiber.tsx, DashboardPage.legacy.tsx, admin/Dashboard.tsx
3. **App.tsx** (main.tsx nutzt es nicht)
4. **WorkflowRouter + Workflow-Komponenten** (aus Router entfernt)
5. **Backend-Routes**: `featureBuilder.routes.ts`, `openaiTest.routes.ts`
6. **Verwaiste Module**: `modules/abrechnung`, `modules/anlagen`, `modules/benutzer`, `modules/performance`, `modules/layout`

### Prioritaet 3: Mit Sorgfalt pruefen

1. **StatusPill konsolidieren** (4 Versionen → 1)
2. **API-Client konsolidieren** (api.ts Axios-Version entfernen)
3. **CommandPalette aufraeuemen** (tote Version in finanzen-module loeschen)
4. **dsgvo.routes.ts** und **zerez.routes.ts** pruefen (evtl. geplante Features)
5. **ENV deduplizieren** (OPENAI_API_KEY, IMAP_PASS/IMAP_PASSWORD)
6. **modules/emails** vs. **modules/admin/emails** pruefen

---

## Geschaetzte Einsparungen nach Cleanup

| Metrik | Vorher | Nachher |
|--------|--------|---------|
| Frontend-Dateien | ~450 | ~380 (-70) |
| Frontend-LoC | ~120.000 | ~87.000 (-33.000) |
| Frontend node_modules | ~800 MB | ~750 MB (-50 MB) |
| Backend-Services | ~80 | ~76 (-4) |
| Backend-Routes | ~50 | ~47 (-3) |
| Build-Zeit (Frontend) | ~25s | ~20s (geschaetzt) |
| TypeScript-Compile-Check | ~40s | ~30s (geschaetzt) |
